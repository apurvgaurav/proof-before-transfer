# Proof Before Transfer

Research artifacts for my paper, **Proof Before Transfer: Leakage-Resistant Qualification for Post-Quantum TLS Intrusion-Detection Studies**.

I examined the checks needed before interpreting an intrusion detector's performance across classical and post-quantum TLS. The study evaluated classical-regime qualification checks on synthetic traffic. Later diagnostics examined whether simple traffic properties and repeated record-length patterns explained the near-perfect classification result. The X25519-to-X25519MLKEM768 transfer experiment was not run.

## What this release contains

This version preserves the available study inputs, five fitted CatBoost models, Platt parameter records, saved qualification predictions, the independent numerical adjudication, and the completed retrospective baseline diagnostics. The retained partitions contain 512 training units, 64 stopping-validation units, 64 calibration units, and 256 qualification units. Each qualification unit contains four requests.

The 24-feature representation used 13 scalar fields and 11 categorical fields. Sequence-valued fields were serialized as complete canonical JSON values and treated as categories. They were not processed by a sequential model. The source and saved diagnostics make that representation available for inspection.

| Directory or file | Contents |
| --- | --- |
| `data/` | Retained semantic units, frozen feature rows, qualification schedule and reconciliation indexes |
| `models/r3/` | Five original model files, their hashes, and exact Platt coefficients and intercepts |
| `results/qualification/` | Saved predictions, labels, family assignments, scores and adjudication records |
| `diagnostics/baselines/` | Original analysis source, a public protocol derivative, stored coefficients and predictions for the completed baseline diagnostics |
| `scientific_source/` | Retained feature, training and runtime source, the R3 adapter and extractor, their historical bindings, and exact R5 feature-materialization, P7 and P8 scientific code blocks |
| `historical_audits/` | Earlier audit source and saved findings, including a retrospective DEV-CAL margin check |
| `figures/` | Figure source and exports |
| `provenance/` and `PROVENANCE.json` | Source identities, exact-copy records, documented transformations and availability limits |

## Verify the preserved results

Use Python 3.11 or newer with NumPy. From the extracted release directory:

```bash
python -m pip install -r requirements-verification.txt
python verify.py --report ../verification-v1.0.1.json
```

The supported verifier checks checksums, stored data roles and feature schemas, saved qualification arithmetic and the original 10,000-replicate bootstrap. It also replays the previously fitted baselines from their saved coefficients, thresholds and lookup tables. It does not refit the models or rerun the main detector on qualification data. The baseline and calibration checks use stored coefficients. It does not load CatBoost models or pickle/joblib objects. See [VERIFICATION.md](VERIFICATION.md) for the exact scope.

The historical source is retained for inspection. It depends on the original environment and includes procedures that fit models or collect traffic. It is not called by `verify.py` and is not the supported verification entry point. Some unchanged historical files retain generic workstation paths and private testbed addresses; those values document the original environment.

## Changes in version 1.0.1

I added the retained PCAP adapter, 24-feature extractor, historical R3 dependency lock and representation contract. I also included the exact Python body used for R5 feature materialization, with an extraction record. These additions make the feature path easier to inspect. The scientific data, fitted models, saved predictions and verifier are unchanged from version 1.0.0.

The historical P7 script loaded a preparation record containing labels before main-model prediction. The prediction calls received only feature columns, and qualification labels were used for scoring afterward. This supports feature-input separation, not process-wide label isolation or proof of the complete historical tuning chronology.

## Limits

Agreement with saved predictions establishes numerical consistency of those records. It does not establish that the synthetic task was difficult, prove the original label-access chronology, or demonstrate transfer to post-quantum TLS or production traffic. The baseline diagnostics expose a limitation of the qualification task; they do not constitute a fresh independent qualification experiment.

The release does not contain a complete capture-to-result reproduction. The exact frozen nuisance evaluator, full reconciliation archive, underlying qualification capture archives, and complete final runtime binding are among the missing records. The original calibration-time margin log is also unavailable; the included margin file is a later DEV-CAL audit. [MISSING_EVIDENCE.md](MISSING_EVIDENCE.md) lists the available and missing evidence explicitly.

The public reconciliation locator index replaces absolute local archive paths with archive basenames. A second documented derivative removes one administrative field from the diagnostic protocol. Scientific data values, model bytes and saved results are preserved. Full original artifact identifiers are in [original_artifact_hashes.json](provenance/original_artifact_hashes.json); a listed digest does not imply that the corresponding original archive is included.

Author: Apurv Gaurav, The Pennsylvania State University, USA.

Repository: <https://github.com/apurvgaurav/proof-before-transfer>

Version: 1.0.1. See [LICENSE_STATUS.md](LICENSE_STATUS.md) for the current reuse status.
