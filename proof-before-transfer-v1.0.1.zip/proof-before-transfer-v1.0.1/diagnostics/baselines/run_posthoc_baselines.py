#!/usr/bin/env python3
"""New retrospective diagnostics; never executes historical study code or inference.

The protocol is fixed before these numeric fits, but existing qualification and
record-token descriptive findings were already known. Results are POST HOC.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
import platform
import warnings

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, roc_auc_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier


PARTITIONS = ("TRAIN", "DEV_STOP", "DEV_CAL", "QUAL")


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False,
                                    allow_nan=False) + "\n")


def read_jsonl(path):
    with Path(path).open() as stream:
        return [json.loads(line) for line in stream if line.strip()]


def checked_sequence(features, name, positive=False, integral=False):
    value = features[name]
    if not isinstance(value, list) or not value:
        raise ValueError(f"Missing or empty archived list: {name}")
    array = np.asarray(value, dtype=np.float64)
    if array.ndim != 1 or not np.all(np.isfinite(array)):
        raise ValueError(f"Invalid numeric sequence: {name}")
    if positive and not np.all(array > 0):
        raise ValueError(f"Nonpositive length in {name}")
    if integral and not np.all(array == np.floor(array)):
        raise ValueError(f"Noninteger byte length in {name}")
    return array


def derive_numeric(features):
    packet_count = float(features["packet_count"])
    if not math.isfinite(packet_count) or packet_count < 2 or not packet_count.is_integer():
        raise ValueError("Invalid packet count or insufficient timing observations")
    payload = checked_sequence(features, "residual_packetization_sequence", True, True)
    records = checked_sequence(features, "residual_record_sizing_sequence", True, True)
    timing = checked_sequence(features, "residual_timing_sequence")
    if len(timing) != int(packet_count) - 1:
        raise ValueError("Timing list length does not match packet count minus one")
    return {
        "packet_count": packet_count,
        "tcp_payload_bytes_exact_range_dedup": float(sum(int(v) for v in payload)),
        "tls_record_count": float(len(records)),
        "tls_record_min_bytes": float(np.min(records)),
        "tls_record_max_bytes": float(np.max(records)),
        "tls_record_mean_bytes": float(np.mean(records)),
        "tls_record_sd_bytes": float(np.std(records, ddof=0)),
        "capture_duration_seconds": float(np.sum(timing)),
        "interarrival_min_seconds": float(np.min(timing)),
        "interarrival_max_seconds": float(np.max(timing)),
        "interarrival_mean_seconds": float(np.mean(timing)),
        "interarrival_sd_seconds": float(np.std(timing, ddof=0)),
    }


def record_token(features):
    values = checked_sequence(features, "residual_record_sizing_sequence", True, True)
    return json.dumps([int(v) for v in values], separators=(",", ":"))


def train_dev_rows(feature_path, semantic_path):
    features = read_jsonl(feature_path)
    semantics = read_jsonl(semantic_path)
    key = lambda row: (row["U_ID"], row["logical_slot_id"])
    f_by_key = {key(row): row for row in features}
    s_by_key = {key(row): row for row in semantics}
    if len(f_by_key) != len(features) or len(s_by_key) != len(semantics):
        raise ValueError("Duplicate TRAIN/DEV join identity")
    if set(f_by_key) != set(s_by_key):
        raise ValueError("TRAIN/DEV feature and semantic identities disagree")
    output = defaultdict(list)
    for item in sorted(features, key=lambda row: int(row["row"])):
        semantic = s_by_key[key(item)]
        if semantic["partition"] == "R3-TRAIN" and semantic["dev_role"] == "":
            partition = "TRAIN"
        elif semantic["partition"] == "R3-DEV" and semantic["dev_role"] in ("DEV-STOP", "DEV-CAL"):
            partition = semantic["dev_role"].replace("-", "_")
        else:
            raise ValueError("Unexpected archived TRAIN/DEV role")
        output[partition].append({
            "ordinal": int(item["row"]), "unit_id": item["U_ID"],
            "logical_slot_id": item["logical_slot_id"],
            "pcap_sha256": item["pcap_sha256"],
            "label": int(semantic["label"]), "family": semantic["family"],
            "numeric": derive_numeric(item["features"]),
            "record_token": record_token(item["features"]),
        })
    return dict(output)


def qualification_rows_without_labels(path):
    raw = sorted(read_jsonl(path), key=lambda row: int(row["execution_ordinal"]))
    ordinals = [int(row["execution_ordinal"]) for row in raw]
    if ordinals != list(range(1, 257)):
        raise ValueError("Qualification ordinals are not exactly 1 through 256")
    return [{
        "ordinal": int(row["execution_ordinal"]),
        "pcap_sha256": row["pcap_sha256"],
        "numeric": derive_numeric(row["features"]),
        "record_token": record_token(row["features"]),
    } for row in raw]


def attach_qualification_labels(rows, schedule_path, arrays_path):
    with Path(schedule_path).open() as stream:
        schedule = list(csv.DictReader(stream, delimiter="\t"))
    schedule = sorted(schedule, key=lambda row: int(row["r5_elig_execution_ordinal"]))
    if [int(row["r5_elig_execution_ordinal"]) for row in schedule] != list(range(1, 257)):
        raise ValueError("Qualification schedule ordinals are not exactly 1 through 256")
    y = np.asarray([int(row["label"]) for row in schedule], dtype=np.int64)
    family = np.asarray([row["family"] for row in schedule])
    with np.load(arrays_path, allow_pickle=False) as archive:
        if not np.array_equal(y, archive["y"]) or not np.array_equal(family, archive["family"]):
            raise ValueError("Qualification schedule labels/families disagree with saved arrays")
    for features, semantic in zip(rows, schedule):
        if features["ordinal"] != int(semantic["r5_elig_execution_ordinal"]):
            raise ValueError("Qualification row-order discrepancy")
        if semantic["treatment_arm"] != "C0" or semantic["negotiated_group"] != "X25519":
            raise ValueError("Unexpected qualification treatment regime")
        features.update({"unit_id": "", "logical_slot_id": semantic["logical_slot_id"],
                         "label": int(semantic["label"]), "family": semantic["family"]})


def score(y, probabilities):
    y = np.asarray(y, dtype=np.int64)
    probabilities = np.asarray(probabilities, dtype=np.float64)
    if probabilities.shape != y.shape or not np.all(np.isfinite(probabilities)):
        raise ValueError("Prediction shape or finite-value failure")
    if not np.all((probabilities >= 0) & (probabilities <= 1)):
        raise ValueError("Prediction outside probability bounds")
    brier = float(np.mean(np.square(probabilities - y)))
    independent_brier = math.fsum((float(p) - int(label)) ** 2
                                  for p, label in zip(probabilities, y)) / len(y)
    if not math.isclose(brier, independent_brier, rel_tol=1e-13, abs_tol=1e-16):
        raise ValueError("Independent direct Brier summation disagrees")
    return {"n": len(y), "class_counts": {str(k): int(v) for k, v in sorted(Counter(y).items())},
            "brier": brier, "gain": 0.25 - brier,
            "auroc": float(roc_auc_score(y, probabilities)),
            "accuracy_at_ge_0p5": float(accuracy_score(y, probabilities >= 0.5)),
            "probability_min": float(probabilities.min()),
            "probability_max": float(probabilities.max()),
            "probability_unique_count": len(np.unique(probabilities))}


def fit_numeric(kind, parameters, x, y):
    parameters = {k: v for k, v in parameters.items() if k not in ("class", "preprocessing")}
    if kind == "decision_stump":
        estimator = DecisionTreeClassifier(**parameters)
    elif kind == "logistic_regression":
        estimator = Pipeline([("scaler", StandardScaler(with_mean=True, with_std=True)),
                              ("model", LogisticRegression(**parameters))])
    else:
        raise ValueError("Unspecified model")
    with warnings.catch_warnings(record=True) as recorded:
        warnings.simplefilter("always")
        estimator.fit(x, y)
    fit_warnings = [{"category": warning.category.__name__, "message": str(warning.message)}
                    for warning in recorded]
    if any(item["category"] == "ConvergenceWarning" for item in fit_warnings):
        raise RuntimeError("Fixed logistic fit did not converge; no adaptive retuning permitted")
    return estimator, fit_warnings


def model_description(kind, estimator, names):
    if kind == "decision_stump":
        tree = estimator.tree_
        feature = int(tree.feature[0])
        return {"feature_names": names, "node_count": int(tree.node_count),
                "root_split_feature": names[feature] if feature >= 0 else None,
                "root_threshold": float(tree.threshold[0]) if feature >= 0 else None,
                "children_left": tree.children_left.tolist(),
                "children_right": tree.children_right.tolist(),
                "node_sample_counts": tree.n_node_samples.tolist(),
                "node_class_distributions": tree.value[:, 0, :].tolist()}
    scaler = estimator.named_steps["scaler"]
    model = estimator.named_steps["model"]
    return {"feature_names": names, "train_scaler_mean": scaler.mean_.tolist(),
            "train_scaler_scale": scaler.scale_.tolist(),
            "train_scaler_n_samples": int(scaler.n_samples_seen_),
            "standardized_coefficients": model.coef_[0].tolist(),
            "intercept": float(model.intercept_[0]), "iterations": model.n_iter_.tolist()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent / "results")
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    protocol_path = here / "protocol.json"
    protocol_sha = (here / "protocol.sha256").read_text().split()[0]
    if digest(protocol_path) != protocol_sha:
        raise ValueError("Protocol content changed after its recorded specification")
    protocol = json.loads(protocol_path.read_text())
    inputs = {name: args.source_root / relative for name, relative in protocol["inputs"].items()}
    source_hashes = {name: {"path": str(path), "sha256": digest(path), "bytes": path.stat().st_size}
                     for name, path in inputs.items()}
    source_hashes["protocol"] = {"path": str(protocol_path), "sha256": protocol_sha}
    source_hashes["new_analysis_script"] = {"path": str(Path(__file__).resolve()),
                                            "sha256": digest(__file__)}
    output = args.output_dir
    if output.exists() and any(output.iterdir()):
        raise ValueError("Refuse to overwrite existing diagnostic outputs; choose a new output directory")
    output.mkdir(parents=True, exist_ok=True)
    write_json(output / "source_hashes_before.json", source_hashes)
    started = utc_now()
    data = train_dev_rows(inputs["train_dev_features"], inputs["train_dev_semantics"])
    data["QUAL"] = qualification_rows_without_labels(inputs["qualification_features"])
    if {name: len(data[name]) for name in PARTITIONS} != protocol["split_counts"]:
        raise ValueError("Archived split counts do not match fixed protocol")
    names_all = protocol["groups"]["joint"]
    if len(names_all) != 12 or set(data["TRAIN"][0]["numeric"]) != set(names_all):
        raise ValueError("Unexpected numeric feature specification")
    y_train = np.asarray([row["label"] for row in data["TRAIN"]], dtype=np.int64)
    if set(y_train) != {0, 1}:
        raise ValueError("Unexpected TRAIN labels")
    train_prior = float(y_train.mean())
    predictions, descriptions, warning_log = {}, {}, {}
    for group, names in protocol["groups"].items():
        matrices = {part: np.asarray([[row["numeric"][name] for name in names]
                                     for row in data[part]], dtype=np.float64)
                    for part in PARTITIONS}
        for kind, parameters in protocol["numeric_models"].items():
            identifier = f"{group}__{kind}"
            estimator, fit_warnings = fit_numeric(kind, parameters, matrices["TRAIN"], y_train)
            if list(estimator.classes_) != [0, 1]:
                raise ValueError("Unexpected fitted class ordering")
            predictions[identifier] = {part: estimator.predict_proba(matrices[part])[:, 1]
                                       for part in PARTITIONS}
            descriptions[identifier] = model_description(kind, estimator, names)
            descriptions[identifier].update({"model_kind": kind, "feature_group": group,
                                             "fit_n": len(y_train), "calibrated": False})
            warning_log[identifier] = fit_warnings
    predictions["train_prior"] = {part: np.full(len(data[part]), train_prior) for part in PARTITIONS}
    descriptions["train_prior"] = {"probability": train_prior, "fit_n": len(y_train)}
    token_counts = defaultdict(lambda: [0, 0])
    for row in data["TRAIN"]:
        token_counts[row["record_token"]][row["label"]] += 1
    lookup = {token: counts[1] / sum(counts) for token, counts in token_counts.items()}
    predictions["record_token_lookup"] = {
        part: np.asarray([lookup.get(row["record_token"], train_prior) for row in data[part]])
        for part in PARTITIONS}
    descriptions["record_token_lookup"] = {
        "interpretation": "POST HOC frequency lookup confirming a previously reported descriptive pattern",
        "fit_n": len(y_train), "distinct_train_tokens": len(lookup),
        "unseen_token_probability": train_prior, "smoothing": "none",
        "train_token_table": [{"token": token, "class_counts": counts,
                                "p_positive": lookup[token]}
                               for token, counts in sorted(token_counts.items())]}
    if len(predictions) != 12:
        raise ValueError("Not all fixed models were produced")
    prediction_archive = output / "predictions_before_qualification_label_load.npz"
    np.savez(prediction_archive, **{f"{model}___{part}": values
                                  for model, by_partition in predictions.items()
                                  for part, values in by_partition.items()})
    write_json(output / "prediction_lock.json", {
        "recorded_at_utc": utc_now(), "prediction_archive_sha256": digest(prediction_archive),
        "protocol_sha256": protocol_sha, "analysis_script_sha256": digest(__file__),
        "qualification_labels_loaded_by_this_script": False,
        "scope": "Pre-scoring snapshot within a POST HOC analysis; not historical preregistration."})
    write_json(output / "models.json", descriptions)
    attach_qualification_labels(data["QUAL"], inputs["qualification_schedule"],
                               inputs["saved_qualification_labels_crosscheck"])
    labels_loaded_at = utc_now()
    if len({row["logical_slot_id"] for part in PARTITIONS for row in data[part]}) != 896:
        raise ValueError("Unexpected duplicate logical slot identity across partitions")
    metric_results = {}
    for model, by_partition in predictions.items():
        metric_results[model] = {}
        for part in PARTITIONS:
            rows = data[part]
            y = np.asarray([row["label"] for row in rows], dtype=np.int64)
            family = np.asarray([row["family"] for row in rows])
            probabilities = by_partition[part]
            results = score(y, probabilities)
            results["families"] = {name: score(y[family == name], probabilities[family == name])
                                   for name in sorted(set(family))}
            if model == "record_token_lookup":
                known = sum(row["record_token"] in lookup for row in rows)
                results["token_coverage"] = {"known_rows": known, "total_rows": len(rows),
                                             "fraction": known / len(rows),
                                             "distinct_tokens": len({row["record_token"] for row in rows})}
            metric_results[model][part] = results
    with (output / "per_unit_predictions.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["model", "partition", "ordinal", "logical_slot_id", "family", "label", "p_positive"])
        for model, by_partition in predictions.items():
            for part in PARTITIONS:
                for row, probability in zip(data[part], by_partition[part]):
                    writer.writerow([model, part, row["ordinal"], row["logical_slot_id"],
                                     row["family"], row["label"], format(float(probability), ".17g")])
    with (output / "derived_numeric_features.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["partition", "ordinal", "logical_slot_id", "pcap_sha256", "family", "label"] + names_all)
        for part in PARTITIONS:
            for row in data[part]:
                writer.writerow([part, row["ordinal"], row["logical_slot_id"], row["pcap_sha256"],
                                 row["family"], row["label"]] +
                                [format(row["numeric"][name], ".17g") for name in names_all])
    feature_summaries = {
        part: {name: {"min": min(row["numeric"][name] for row in data[part]),
                      "max": max(row["numeric"][name] for row in data[part]),
                      "distinct_values": len({row["numeric"][name] for row in data[part]})}
               for name in names_all} for part in PARTITIONS}
    unchanged = all(digest(inputs[name]) == record["sha256"]
                    for name, record in source_hashes.items() if name in inputs)
    if not unchanged or digest(protocol_path) != protocol_sha:
        raise ValueError("Input evidence or protocol changed during analysis")
    result = {"analysis_id": protocol["analysis_id"], "analysis_kind": protocol["analysis_kind"],
              "started_at_utc": started, "qualification_labels_loaded_at_utc": labels_loaded_at,
              "completed_at_utc": utc_now(), "protocol_sha256": protocol_sha,
              "analysis_script_sha256": digest(__file__), "inputs_unchanged": unchanged,
              "runtime": {"python": platform.python_version(),
                          **{name: importlib.metadata.version(name)
                             for name in ("numpy", "scipy", "scikit-learn")}},
              "numeric_estimator_fits": 10, "record_lookup_constructions": 1,
              "prior_baselines": 1, "calibration_fits": 0, "frozen_model_inference_calls": 0,
              "new_traffic_acquisitions": 0, "historical_scripts_executed": False,
              "fit_warnings": warning_log, "split_counts": protocol["split_counts"],
              "prior_information": protocol["prior_information"],
              "feature_coverage_limit": protocol["feature_coverage_limit"],
              "feature_summaries": feature_summaries, "models": metric_results,
              "limits": ["All results are post hoc and descriptive on reused archived C0 observations.",
                         "No model or parameter was selected by development or qualification scores.",
                         "Models have no additional calibration; their probability losses reflect this specified baseline procedure.",
                         "Byte count means TCP-payload bytes after exact-range deduplication, not full wire bytes.",
                         "Record-token lookup confirms known shared feature patterns. It does not establish direct label leakage or actual CatBoost attribution.",
                         "No result establishes nontrivial qualification, production generalization, or a PQ transfer effect."]}
    write_json(output / "metrics.json", result)
    write_json(output / "source_hashes_after.json", {
        name: {"path": str(path), "sha256": digest(path)} for name, path in inputs.items()})
    manifest = "".join(f"{digest(path)}  {path.name}\n" for path in sorted(output.iterdir()) if path.is_file())
    (output / "OUTPUT_SHA256SUMS.txt").write_text(manifest)
    print(json.dumps({"output_dir": str(output), "analysis_kind": result["analysis_kind"],
                      "qualification": {name: {key: values["QUAL"][key]
                                              for key in ("brier", "gain", "auroc", "accuracy_at_ge_0p5")}
                                        for name, values in metric_results.items()},
                      "inputs_unchanged": unchanged}, indent=2))


if __name__ == "__main__":
    main()
