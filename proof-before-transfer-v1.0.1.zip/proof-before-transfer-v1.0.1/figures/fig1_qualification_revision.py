#!/usr/bin/env python3
"""Editable vector source for the revised IC-SQITS Figure 1.

Run with Python and Matplotlib installed. No data, model, or network access is
required. Outputs SVG, PDF, EPS, and 600-dpi PNG beside this file.

The artboard is 122 x 78 mm. Typography is specified in points at that size.
Solid boxes show the completed qualification workflow and a separately labeled
reviewer-stage analysis; the dashed panel and arrow denote unexecuted work.
The diagram does not claim an independently repeated acquisition or experiment.
"""

from pathlib import Path
import os

HERE = Path(__file__).resolve().parent
os.environ.setdefault("MPLCONFIGDIR", str(HERE / ".matplotlib_cache"))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, Rectangle


CAPTION = 'Fig. 1. Qualification scope. ELIG denotes qualification. Solid stages are completed; the gray panel contains post hoc diagnostics; the dashed transfer comparison is unexecuted. Scoring uses saved predictions and prerequisite certificates.'


def draw() -> None:
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 7.2,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "svg.fonttype": "none",
            "axes.unicode_minus": False,
            "savefig.facecolor": "white",
            "path.simplify": False,
        }
    )
    mm_per_inch = 25.4
    fig = plt.figure(figsize=(122 / mm_per_inch, 78 / mm_per_inch))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 122)
    ax.set_ylim(0, 78)
    ax.set_axis_off()

    ink = "#202020"
    gray = "#f0f0f0"
    box_y, box_h = 36.5, 30.5
    box_w = 21.7
    starts = [1.0, 25.55, 50.1, 74.65, 99.2]

    def text(x, y, s, *, size=7.2, weight="normal", ha="center", va="center", linespacing=1.25):
        return ax.text(
            x, y, s, fontsize=size, fontweight=weight, ha=ha, va=va,
            linespacing=linespacing, color=ink,
        )

    def arrow(start, end, *, dashed=False, path=None):
        opts = dict(
            arrowstyle="-|>", mutation_scale=6.5, linewidth=0.7,
            color=ink, shrinkA=0, shrinkB=0,
            linestyle=(0, (3, 2)) if dashed else "-",
        )
        if path is not None:
            from matplotlib.path import Path as MplPath
            points = [start, *path, end]
            codes = [MplPath.MOVETO] + [MplPath.LINETO] * (len(points) - 1)
            patch = FancyArrowPatch(path=MplPath(points, codes), **opts)
        else:
            patch = FancyArrowPatch(start, end, **opts)
        ax.add_patch(patch)

    text(1.0, 73.3, "(a) Completed C0 qualification", size=8.5, weight="bold", ha="left")
    text(121.0, 73.3, "C0: X25519", size=7.2, ha="right")

    stages = [
        ("Semantic\nunits and\nsplit design", "512 TRAIN\n64 DEV-STOP\n64 DEV-CAL\n256 ELIG"),
        ("Acquisition\nand evidence\nreconciliation", "PCAPs / logs\nUnit mapping\n4 requests/unit"),
        ("Passive\nfeatures and\nfrozen models", "24 features\n5 CatBoost fits\n5 calibrators"),
        ("Predictions\nand nuisance\ncontrol", "Stored C0\nprobabilities\n9-field control"),
        ("Scores and\nprerequisite\nchecks", "Saved scores\nrecomputed\nCertificates\nchecked"),
    ]

    for x, (title, detail) in zip(starts, stages):
        ax.add_patch(Rectangle((x, box_y), box_w, box_h,
                               facecolor="white", edgecolor=ink, linewidth=0.75))
        text(x + box_w / 2, box_y + box_h - 6.4, title, size=7.2, weight="bold", linespacing=1.16)
        ax.plot([x + 1.3, x + box_w - 1.3], [box_y + box_h - 12.5] * 2,
                color="#bbbbbb", linewidth=0.45)
        text(x + box_w / 2, box_y + 8.7, detail, size=7.0, linespacing=1.26)

    for x1, x2 in zip(starts[:-1], starts[1:]):
        arrow((x1 + box_w + 0.25, box_y + box_h / 2),
              (x2 - 0.30, box_y + box_h / 2))

    # Additional reviewer-stage analysis branches from existing saved artifacts.
    # It never connects back into the frozen qualification gate.
    b_x, b_y, b_w, b_h = 1.0, 3.0, 64.8, 24.0
    ax.add_patch(Rectangle((b_x, b_y), b_w, b_h, facecolor=gray,
                           edgecolor=ink, linewidth=0.75))
    text(b_x + 2.0, b_y + b_h - 3.0, "(b) Reviewer-stage diagnostics", size=8.0,
         weight="bold", ha="left", va="top")
    text(b_x + 2.0, b_y + b_h - 7.1, "Post hoc analysis of saved artifacts", size=7.2,
         ha="left", va="top")
    text(b_x + 2.0, b_y + 10.0, "Size shortcuts and simple baselines\nStored-model feature importance\nDEV-CAL margin separation", size=7.0,
         ha="left", linespacing=1.16)
    text(b_x + 2.0, b_y + 3.3, "Additional analysis outside the original gate", size=7.0, ha="left")

    feature_mid = starts[2] + box_w / 2
    arrow((feature_mid, box_y), (b_x + b_w / 2, b_y + b_h + 0.3),
          path=[(feature_mid, 31.8), (b_x + b_w / 2, 31.8)])

    # Dashed = a planned future experiment, not an executed stage or a result.
    c_x, c_y, c_w, c_h = 70.0, 3.0, 50.9, 24.0
    ax.add_patch(Rectangle((c_x, c_y), c_w, c_h, facecolor="white",
                           edgecolor=ink, linewidth=0.75, linestyle=(0, (3, 2))))
    text(c_x + 2.0, c_y + c_h - 3.0, "(c) Future transfer test", size=8.0,
         weight="bold", ha="left", va="top")
    text(c_x + 2.0, c_y + c_h - 7.1, "Unexecuted", size=7.2, weight="bold", ha="left", va="top")
    text(c_x + c_w / 2, c_y + 9.4, "X25519 \N{RIGHTWARDS ARROW} X25519MLKEM768", size=7.2)
    text(c_x + 2.0, c_y + 3.3, "No transfer effect measured", size=7.0, ha="left")

    check_mid = starts[4] + box_w / 2
    arrow((check_mid, box_y), (c_x + c_w / 2, c_y + c_h + 0.3),
          dashed=True, path=[(check_mid, 31.8), (c_x + c_w / 2, 31.8)])

    # Preserve a fixed artboard: no tight-bbox resizing that would change point sizes.
    out = HERE / "fig1_qualification_revision"
    for fmt in ("svg", "pdf", "eps", "png"):
        kwargs = {"dpi": 600} if fmt == "png" else {}
        if fmt == "pdf":
            kwargs["metadata"] = {
                "Title": "Qualification workflow, reviewer-stage diagnostics, and future transfer scope",
                "Author": "",
                "Subject": "IC-SQITS revised Figure 1",
                "Keywords": "C0 qualification, post hoc diagnostics, unexecuted transfer comparison",
            }
        fig.savefig(out.with_suffix("." + fmt), format=fmt, **kwargs)
    (HERE / "fig1_qualification_revision_caption.txt").write_text(CAPTION + "\n", encoding="utf-8")
    plt.close(fig)


if __name__ == "__main__":
    draw()
