#!/usr/bin/env python3
"""Verify saved evidence with no fits, acquisition or main frozen-model inference.

The arithmetic and bootstrap follow the preserved audit_saved_predictions.py.
Numeric feature definitions follow run_posthoc_baselines.py. Stored-coefficient
replay follows independent_numerical_audit.py. Those original sources and their
hashes are retained. This portable adapter does not import or execute them.

Only NumPy and the Python standard library are used. NPZ loading forbids pickle.
No CatBoost model or joblib object is deserialized. Reports must be outside the
release directory. This checks preserved records, not complete experimental
provenance or the scientific difficulty of the qualification task.
"""
from __future__ import annotations

import argparse
import ast
from collections import Counter, defaultdict
import csv
import hashlib
import json
import math
from pathlib import Path
import platform
import sys

import numpy as np

PARTITIONS = ('TRAIN', 'DEV_STOP', 'DEV_CAL', 'QUAL')
COUNTS = dict(zip(PARTITIONS, (512, 64, 64, 256)))
CHECKS = []


def check(name, condition, detail=None):
    passed = bool(condition)
    item = {'name': name, 'passed': passed}
    if detail is not None:
        item['detail'] = detail
    CHECKS.append(item)
    if not passed:
        raise ValueError(name)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def jsonl(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()]


def csv_rows(path, delimiter=','):
    with Path(path).open(newline='', encoding='utf-8') as stream:
        return list(csv.DictReader(stream, delimiter=delimiter))


def verify_manifest(root):
    manifest = root/'MANIFEST.sha256'
    expected = {}
    for line in manifest.read_text().splitlines():
        digest, relative = line.split(maxsplit=1)
        relative = relative.removeprefix('*')
        target = root/relative
        check('safe manifest path '+relative,
              not Path(relative).is_absolute() and target.resolve().is_relative_to(root)
              and not target.is_symlink() and len(digest) == 64)
        check('unique manifest path '+relative, relative not in expected)
        expected[relative] = digest
        check('checksum '+relative, target.is_file() and sha(target) == digest)
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*')
              if p.is_file() and not any(part in ('.git', '__pycache__') for part in p.relative_to(root).parts)
              and p != manifest}
    check('manifest covers every released file', actual == set(expected))
    return {'files_checked': len(expected), 'manifest_sha256': sha(manifest)}


def numeric(features):
    packets = float(features['packet_count'])
    payload = np.asarray(features['residual_packetization_sequence'], dtype=np.float64)
    records = np.asarray(features['residual_record_sizing_sequence'], dtype=np.float64)
    timing = np.asarray(features['residual_timing_sequence'], dtype=np.float64)
    if not (packets.is_integer() and packets >= 2 and len(timing) == int(packets)-1):
        raise ValueError('packet/timing schema')
    for array in (payload, records, timing):
        if array.ndim != 1 or not len(array) or not np.isfinite(array).all():
            raise ValueError('sequence schema')
    if not (np.all(payload > 0) and np.all(records > 0)
            and np.all(payload == np.floor(payload)) and np.all(records == np.floor(records))):
        raise ValueError('byte-length schema')
    return {
        'packet_count': packets,
        'tcp_payload_bytes_exact_range_dedup': float(sum(int(v) for v in payload)),
        'tls_record_count': float(len(records)),
        'tls_record_min_bytes': float(records.min()),
        'tls_record_max_bytes': float(records.max()),
        'tls_record_mean_bytes': float(records.mean()),
        'tls_record_sd_bytes': float(records.std(ddof=0)),
        'capture_duration_seconds': float(timing.sum()),
        'interarrival_min_seconds': float(timing.min()),
        'interarrival_max_seconds': float(timing.max()),
        'interarrival_mean_seconds': float(timing.mean()),
        'interarrival_sd_seconds': float(timing.std(ddof=0)),
    }


def token(features):
    return json.dumps([int(x) for x in features['residual_record_sizing_sequence']], separators=(',', ':'))


def inspect_source_and_partitions(root):
    schema = read_json(root/'config/feature_schema.json')
    source = root/'scientific_source/r3/C6_R3_FEATURE_MODEL_EVAL_v1.py'
    check('schema source hash', sha(source) == schema['source_sha256'])
    assignments = {}
    for node in ast.parse(source.read_text()).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            name = node.targets[0].id
            if name in ('FEATURES', 'CATEGORICAL', 'SEEDS'):
                assignments[name] = ast.literal_eval(node.value)
    check('24 ordered features match frozen source', assignments['FEATURES'] == schema['ordered_features'] and len(assignments['FEATURES']) == 24)
    check('11 categorical and 13 scalar features', assignments['CATEGORICAL'] == schema['categorical_features'] and len(schema['categorical_features']) == 11 and len(schema['continuous_features']) == 13)
    check('five seed values match frozen source', assignments['SEEDS'] == schema['seeds'] and len(set(schema['seeds'])) == 5)
    f3 = sorted(jsonl(root/'data/r3/R3_TRAIN_DEV_640_FEATURE_ROWS_LABEL_BLIND.jsonl'), key=lambda x: int(x['row']))
    s3 = jsonl(root/'data/r3/C6_R3_TRAIN_DEV_PRIMARY_640.jsonl')
    f5 = sorted(jsonl(root/'data/r5/R5_ELIG_256_FEATURE_ROWS_LABEL_BLIND.jsonl'), key=lambda x: int(x['execution_ordinal']))
    s5 = jsonl(root/'data/r5/R5_DATASET.jsonl')
    schedule = sorted(csv_rows(root/'data/r5/R5_SCHEDULE.tsv', '\t'), key=lambda x: int(x['r5_elig_execution_ordinal']))
    key = lambda x: (x['U_ID'], x['logical_slot_id'])
    by3 = {key(x): x for x in s3}
    by5 = {x['logical_slot_id']: x for x in s5}
    check('R3 features and semantics bijection', len(f3) == len(s3) == len(by3) == 640 and {key(x) for x in f3} == set(by3))
    check('R5 semantic slots unique', len(s5) == len(by5) == 256)
    check('R3 feature ordinals complete', [int(x['row']) for x in f3] == list(range(1, 641)))
    check('R5 feature and schedule ordinals complete', [int(x['execution_ordinal']) for x in f5] == [int(x['r5_elig_execution_ordinal']) for x in schedule] == list(range(1, 257)))
    expected_features = set(schema['ordered_features'])
    forbidden = set(schema['forbidden_model_identity_keys'])
    for index, row in enumerate(f3+f5):
        values = row['features']
        if set(values) != expected_features or forbidden.intersection(values):
            raise ValueError('feature-only schema at row '+str(index))
        for name in schema['continuous_features']:
            if isinstance(values[name], bool) or not math.isfinite(float(values[name])):
                raise ValueError('nonfinite scalar '+name)
        for name in schema['categorical_features']:
            value = values[name]
            if isinstance(value, str):
                if json.dumps(json.loads(value), sort_keys=True, separators=(',', ':'), ensure_ascii=False) != value:
                    raise ValueError('noncanonical categorical string '+name)
            else:
                json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)
    check('all 896 feature dictionaries pass frozen schema', True)
    data = {p: [] for p in PARTITIONS}
    for f in f3:
        s = by3[key(f)]
        if s['partition'] == 'R3-TRAIN' and s['dev_role'] == '':
            role = 'TRAIN'
        elif s['partition'] == 'R3-DEV' and s['dev_role'] in ('DEV-STOP', 'DEV-CAL'):
            role = s['dev_role'].replace('-', '_')
        else:
            raise ValueError('unrecognized original R3 role')
        data[role].append({'ordinal': int(f['row']), 'logical_slot_id': s['logical_slot_id'], 'unit_id': s['U_ID'], 'family': s['family'], 'label': int(s['label']), 'pcap_sha256': f['pcap_sha256'], 'numeric': numeric(f['features']), 'record_token': token(f['features'])})
    for f, sc in zip(f5, schedule, strict=True):
        s = by5[sc['logical_slot_id']]
        if not (sc['treatment_arm'] == 'C0' and sc['negotiated_group'] == 'X25519'
                and s['family'] == sc['family'] and int(s['label']) == int(sc['label']) and s['partition'] == 'R5-ELIG'):
            raise ValueError('qualification semantic/schedule identity')
        data['QUAL'].append({'ordinal': int(f['execution_ordinal']), 'logical_slot_id': s['logical_slot_id'], 'unit_id': s['U_ID'], 'family': s['family'], 'label': int(s['label']), 'pcap_sha256': f['pcap_sha256'], 'numeric': numeric(f['features']), 'record_token': token(f['features'])})
    check('partition sizes', {p: len(v) for p,v in data.items()} == COUNTS)
    check('896 unique logical slots', len({x['logical_slot_id'] for rows in data.values() for x in rows}) == 896)
    check('896 unique unit IDs', len({x['unit_id'] for rows in data.values() for x in rows}) == 896)
    strata = {}
    for p, rows in data.items():
        counts = Counter((x['family'], x['label']) for x in rows)
        check(p+' family/label balance', dict(counts) == {(f,y):COUNTS[p]//4 for f in ('F1','F2') for y in (0,1)})
        strata[p] = {f'{f}/{y}': n for (f,y),n in sorted(counts.items())}
    return data, f5, {'counts': COUNTS, 'strata': strata, 'feature_count':24, 'scope': 'Stored role and feature schemas; not proof of historical label blindness or complete semantic leakage absence.'}


def verify_index(root, f5):
    info = read_json(root/'provenance/R5_INDEX_DERIVATION.json')
    path = root/info['public_path']
    check('public derivative index hash', sha(path) == info['derived_sha256'])
    raw = path.read_bytes().decode('utf-8').splitlines(keepends=True)
    column = raw[0].rstrip('\r\n').split('\t').index('source_row_archive_path')
    projected = [raw[0]]
    for line in raw[1:]:
        if not line.strip():
            projected.append(line); continue
        ending = '\r\n' if line.endswith('\r\n') else '\n' if line.endswith('\n') else ''
        fields = line[:-len(ending)].split('\t') if ending else line.split('\t')
        if not fields[column] or '/' in fields[column] or '\\' in fields[column]:
            raise ValueError('public locator is not a basename')
        fields[column] = '<ARCHIVE_BASENAME_ONLY>'
        projected.append('\t'.join(fields)+ending)
    check('unchanged nonlocator projection commitment', hashlib.sha256(''.join(projected).encode()).hexdigest() == info['nonlocator_projection_sha256'])
    rows = sorted(csv_rows(path, '\t'), key=lambda x:int(x['execution_ordinal']))
    recon = sorted(csv_rows(root/'data/r5/indexes/R5_RECONCILIATION_INDEX_AUTHORITY', '\t'), key=lambda x:int(x['execution_ordinal']))
    check('256 public and reconciliation index rows', len(rows) == len(recon) == len(f5) == 256)
    for index, (a,b,c) in enumerate(zip(rows, f5, recon, strict=True),1):
        if not (int(a['execution_ordinal']) == int(b['execution_ordinal']) == int(c['execution_ordinal']) == index
                and a['pcap_sha256'] == b['pcap_sha256']
                and a['reconciled_row_archive_sha256'] == b['reconciled_row_archive_sha256'] == c['row_archive_sha256']):
            raise ValueError('index/feature binding at row '+str(index))
    check('256 public-index scientific bindings', True)
    return {'derivative_sha256': info['derived_sha256'], 'original_index_sha256_record_only': info['source']['original_sha256'], 'rows':256, 'original_index_bytes_verified_by_this_public_script':False, 'underlying_row_archives_verified':False}


def verify_qualification(root, data):
    q = root/'results/qualification'
    with np.load(q/'P7_SCIENTIFIC_ARRAYS.npz', allow_pickle=False) as archive:
        arrays = {k: np.array(archive[k], copy=True) for k in archive.files}
    expected = {'ensemble','y','family','nuisance'} | {f'seed{i}' for i in range(5)}
    check('qualification array schema', set(arrays)==expected and all(x.shape==(256,) for x in arrays.values()))
    y = arrays['y']; family=arrays['family']
    check('qualification labels agree with frozen schedule', np.array_equal(y,[x['label'] for x in data['QUAL']]) and np.array_equal(family,[x['family'] for x in data['QUAL']]))
    for k in expected-{'y','family'}:
        check('finite probabilities '+k, np.isfinite(arrays[k]).all() and np.all((arrays[k]>=0)&(arrays[k]<=1)))
    check('ensemble is arithmetic mean of five seeds', np.array_equal(arrays['ensemble'], np.mean(np.vstack([arrays[f'seed{i}'] for i in range(5)]),axis=0,dtype=np.float64)))
    brier = {k:float(np.mean(np.square(arrays[k]-y),dtype=np.float64)) for k in ('ensemble','nuisance',*[f'seed{i}' for i in range(5)])}
    errors=np.square(arrays['ensemble']-y)
    strata=[errors[(family==f)&(y==label)] for f in ('F1','F2') for label in (0.,1.)]
    check('64 semantic units per bootstrap stratum', all(len(x)==64 for x in strata))
    literal=b'C6-R3-COMPETENCE-BOOTSTRAP-V1'
    seed=int.from_bytes(hashlib.sha256(literal).digest()[:8],'big')%2147483647
    check('recorded bootstrap seed', seed==1447780860)
    rng=np.random.Generator(np.random.PCG64(seed))
    gains=np.empty(10000,dtype=np.float64)
    for i in range(len(gains)):
        samples=[v[rng.integers(0,64,size=64,endpoint=False,dtype=np.int64)] for v in strata]
        gains[i]=.25-np.mean(np.concatenate(samples),dtype=np.float64)
    seed_g=[.25-brier[f'seed{i}'] for i in range(5)]
    metrics={'G_POOL':.25-brier['ensemble'],'G_LB95':float(np.quantile(gains,.05,method='linear')),
             'G_F1':float(.25-np.mean(errors[family=='F1'],dtype=np.float64)),
             'G_F2':float(.25-np.mean(errors[family=='F2'],dtype=np.float64)),
             'SEED_G':seed_g,'POSITIVE_SEEDS':sum(x>0 for x in seed_g),
             'MEDIAN_SEED_G':float(np.median(seed_g)),'G_NUISANCE':.25-brier['nuisance']}
    p7=read_json(q/'P7_RESULT.json');p8=read_json(q/'P8_INDEPENDENT_ADJUDICATION.json')
    for name,value in metrics.items():
        check('P7/P8 saved metric '+name, value==p7[name] and value==p8['metrics'][name])
    cert=(q/'05_PREEXEC_CERT.txt').read_text()
    conditions={'01_exact_256':len(y)==256,'02_64_each':all(len(x)==64 for x in strata),
        '03_zero_cross_partition_overlap':'ZERO_FORBIDDEN_CROSS_PARTITION_OVERLAP=PASS' in cert,
        '04_model_freeze':'MODEL_CALIBRATION_ARTIFACTS_FROZEN_BEFORE_R5_ELIG=PASS' in cert,
        '05_G_POOL_ge_0p01':metrics['G_POOL']>=.01,'06_G_LB95_gt_0':metrics['G_LB95']>0,
        '07_G_F1_gt_0':metrics['G_F1']>0,'08_G_F2_gt_0':metrics['G_F2']>0,
        '09_positive_seeds_ge_4':metrics['POSITIVE_SEEDS']>=4,'10_median_seed_G_gt_0':metrics['MEDIAN_SEED_G']>0,
        '11_G_NUISANCE_lt_0p01':metrics['G_NUISANCE']<.01}
    check('recorded eleven-condition adjudication agreement', conditions==p8['conditions'])
    prep=read_json(q/'05_P7_PREP.json')
    check('preparation labels/families agree with arrays', np.array_equal(prep['r5_y'],y) and np.array_equal(prep['r5_family'],family))
    nuisance={}
    for role,rows,labels in [('TRAIN',prep['train_nuisance'],prep['train_y']),('QUAL',prep['r5_nuisance'],prep['r5_y'])]:
        groups=defaultdict(Counter)
        fields=set(rows[0])
        for row,label in zip(rows,labels,strict=True):
            if set(row)!=fields:raise ValueError('inconsistent nuisance schema')
            groups[json.dumps(row,sort_keys=True,separators=(',',':'))][int(label)]+=1
        check(role+' nine nuisance fields and paired labels',len(fields)==9 and all(v[0]==v[1] for v in groups.values()))
        nuisance[role]={'rows':len(rows),'fields':sorted(fields),'joint_vectors':len(groups),'all_joint_vectors_label_balanced':True}
    historical=read_json(root/'historical_audits/saved_prediction_findings.json')
    check('bootstrap replicate byte commitment', hashlib.sha256(gains.tobytes()).hexdigest()==historical['bootstrap']['replicate_float64_bytes_sha256'])
    return {'direct_brier_losses':brier,'metrics':metrics,'bootstrap':{'replicates':10000,'generator':'PCG64','seed':seed,'resampling_unit':'complete semantic unit','strata_order':['F1/0','F1/1','F2/0','F2/1'],'lower_quantile':.05,'quantile_method':'linear'},'certificate_only_conditions':['03_zero_cross_partition_overlap','04_model_freeze'],'nuisance_design':nuisance,'nuisance_evaluator_or_fit_replayed':False}


def verify_models_and_calibration_records(root,data):
    hashes=read_json(root/'results/qualification/P7_MODEL_HASHES.json')
    seeds=read_json(root/'results/qualification/P7_SEEDS.json')
    check('five models declared',len(seeds)==5 and set(map(str,seeds))==set(hashes))
    freezes={}
    for seed in seeds:
        f=read_json(root/f'models/r3/seed-{seed}-freeze.json')
        check('stored model hash '+str(seed),sha(root/f'models/r3/seed-{seed}.cbm')==f['model_sha256']==hashes[str(seed)]['model'])
        check('declared calibrator hash agreement '+str(seed),f['calibrator_sha256']==hashes[str(seed)]['platt'])
        check('stored Platt coefficients schema '+str(seed),f['classes']==[0,1] and len(f['platt_coef'])==len(f['platt_intercept'])==1 and all(math.isfinite(v) for v in f['platt_coef']+f['platt_intercept']))
        freezes[seed]=f
    rows=csv_rows(root/'historical_audits/dev_cal_retrospective_margins.csv')
    lookup={r['logical_slot_id']:r for r in data['DEV_CAL']}
    counts=Counter();max_error=0.
    for row in rows:
        seed=int(row['seed']);f=freezes[seed];unit=lookup[row['logical_slot_id']]
        if unit['unit_id']!=row['unit_id'] or unit['label']!=int(row['label']) or unit['family']!=row['family']:
            raise ValueError('retrospective DEV-CAL identity')
        z=f['platt_coef'][0]*float(row['raw_margin'])+f['platt_intercept'][0]
        p=1/(1+math.exp(-z))
        max_error=max(max_error,abs(p-float(row['manual_sigmoid_probability'])))
        counts[seed]+=1
    check('320 retrospective DEV-CAL rows',len(rows)==320 and dict(counts)=={s:64 for s in seeds})
    check('stored-coefficient DEV-CAL sigmoid arithmetic',max_error<2e-14)
    return {'model_files_hashed':5,'model_objects_loaded':0,'joblib_files_loaded':0,'joblib_files_included':False,'calibrator_hashes_status':'Declared historical hash agreement only; original joblib byte streams are intentionally omitted. Exact coefficient/intercept JSON records are included.','retrospective_DEV_CAL_rows':320,'maximum_probability_arithmetic_error':max_error,'historical_training_time_per_unit_margin_log_recovered':False}


def score(y,p):
    y=np.asarray(y,dtype=np.int64);p=np.asarray(p,dtype=np.float64)
    positive=p[y==1];negative=p[y==0]
    delta=positive[:,None]-negative[None,:]
    loss=math.fsum((float(v)-int(label))**2 for v,label in zip(p,y,strict=True))/len(y)
    return {'brier':loss,'gain':.25-loss,'auroc':float(np.mean((delta>0)+.5*(delta==0))),'accuracy_at_ge_0p5':float(np.mean((p>=.5)==y))}


def verify_baselines(root,data):
    base=root/'diagnostics/baselines';models=read_json(base/'results/models.json')
    metrics=read_json(base/'results/metrics.json');lock=read_json(base/'results/prediction_lock.json')
    protocol=read_json(base/'protocol_public.json')
    pd=read_json(root/'provenance/BASELINE_PROTOCOL_DERIVATION.json')
    check('public protocol derivative hash',sha(base/'protocol_public.json')==pd['derived_sha256'])
    check('recorded original protocol digest',lock['protocol_sha256']==metrics['protocol_sha256']==pd['original_sha256'])
    check('scientific protocol projection preserved',hashlib.sha256(json.dumps(protocol,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()==pd['scientific_projection_sha256'])
    check('archived baseline source bound by prediction lock',sha(base/'run_posthoc_baselines.py')==lock['analysis_script_sha256'])
    check('prediction lock digest',sha(base/'results/predictions_before_qualification_label_load.npz')==lock['prediction_archive_sha256'])
    check('post hoc split specification',protocol['split_counts']==COUNTS and not protocol['confirmatory_study'])
    with np.load(base/'results/predictions_before_qualification_label_load.npz',allow_pickle=False) as loaded:
        saved={k:np.array(loaded[k],copy=True) for k in loaded.files}
    check('12 stored diagnostic models and 48 arrays',len(models)==12 and set(saved)=={m+'___'+p for m in models for p in PARTITIONS})
    derived=csv_rows(base/'results/derived_numeric_features.csv')
    mapping={(p,r['ordinal']):r for p,rows in data.items() for r in rows}
    check('896 saved derived-feature rows',len(derived)==len(mapping)==896)
    max_numeric_error=0.
    for row in derived:
        r=mapping[(row['partition'],int(row['ordinal']))]
        if not(row['logical_slot_id']==r['logical_slot_id'] and row['pcap_sha256']==r['pcap_sha256'] and row['family']==r['family'] and int(row['label'])==r['label']):raise ValueError('derived feature identity')
        for name,value in r['numeric'].items():
            error=abs(float(row[name])-value);max_numeric_error=max(max_numeric_error,error)
            if not math.isclose(float(row[name]),value,rel_tol=1e-14,abs_tol=1e-12):raise ValueError('derived numeric feature '+name)
    check('derived numeric definitions agree',True)
    token_counts=defaultdict(lambda:[0,0])
    for r in data['TRAIN']:token_counts[r['record_token']][r['label']]+=1
    stored_tokens={x['token']:x for x in models['record_token_lookup']['train_token_table']}
    check('stored lookup tokens and class counts match TRAIN',set(stored_tokens)==set(token_counts) and all(stored_tokens[t]['class_counts']==v for t,v in token_counts.items()))
    max_error=0.;groups=0;score_checks=0
    for name,model in models.items():
        names=model.get('feature_names',[])
        if model.get('model_kind')=='logistic_regression':
            train=np.asarray([[r['numeric'][n] for n in names] for r in data['TRAIN']],dtype=np.float64)
            scale=train.std(axis=0);scale[scale==0]=1
            check('TRAIN scaler statistics '+name,np.allclose(train.mean(axis=0),model['train_scaler_mean'],rtol=0,atol=1e-10) and np.allclose(scale,model['train_scaler_scale'],rtol=0,atol=1e-10))
        for part in PARTITIONS:
            rows=data[part];stored=saved[name+'___'+part]
            check('baseline probability bounds '+name+'/'+part,stored.shape==(len(rows),) and np.isfinite(stored).all() and np.all((stored>=0)&(stored<=1)))
            if name=='train_prior':
                prediction=np.full(len(rows),model['probability'],dtype=np.float64)
            elif name=='record_token_lookup':
                prediction=np.asarray([stored_tokens[r['record_token']]['p_positive'] if r['record_token'] in stored_tokens else model['unseen_token_probability'] for r in rows])
            else:
                x=np.asarray([[r['numeric'][n] for n in names] for r in rows],dtype=np.float64)
                if model['model_kind']=='logistic_regression':
                    z=((x-np.asarray(model['train_scaler_mean']))/np.asarray(model['train_scaler_scale']))@np.asarray(model['standardized_coefficients'])+model['intercept']
                    prediction=1/(1+np.exp(-z))
                elif model['model_kind']=='decision_stump':
                    if model['node_count']==1:
                        prediction=np.full(len(rows),model['node_class_distributions'][0][1])
                    else:
                        j=names.index(model['root_split_feature'])
                        left=x[:,j].astype(np.float32)<=model['root_threshold']
                        prediction=np.where(left,model['node_class_distributions'][1][1],model['node_class_distributions'][2][1])
                else:raise ValueError('unknown stored baseline kind')
            error=float(np.max(np.abs(prediction-stored)));max_error=max(max_error,error)
            check('stored-coefficient replay '+name+'/'+part,error<2e-14)
            y=np.asarray([r['label'] for r in rows]);family=np.asarray([r['family'] for r in rows])
            for family_name,mask in [(None,np.ones(len(rows),dtype=bool)),('F1',family=='F1'),('F2',family=='F2')]:
                actual=score(y[mask],stored[mask])
                expected=metrics['models'][name][part] if family_name is None else metrics['models'][name][part]['families'][family_name]
                check('saved metric replay '+name+'/'+part+'/'+str(family_name),all(math.isclose(v,float(expected[k]),rel_tol=1e-12,abs_tol=1e-15) for k,v in actual.items()))
                score_checks+=1
            groups+=1
    predictions=csv_rows(base/'results/per_unit_predictions.csv')
    check('10752 per-unit probability records',len(predictions)==12*896)
    position={(part,r['ordinal']):i for part,rows in data.items() for i,r in enumerate(rows)}
    seen=set()
    for row in predictions:
        part=row['partition'];ordinal=int(row['ordinal']);model=row['model'];key=(model,part,ordinal)
        if key in seen:raise ValueError('duplicate prediction row')
        seen.add(key);r=mapping[(part,ordinal)]
        if not(row['logical_slot_id']==r['logical_slot_id'] and row['family']==r['family'] and int(row['label'])==r['label'] and float(row['p_positive'])==float(saved[model+'___'+part][position[(part,ordinal)]])):
            raise ValueError('CSV-to-locked-array probability binding')
    check('all per-unit CSV probabilities bind to frozen data and locked arrays',True)
    return {'stored_model_partition_groups':groups,'pooled_and_family_metric_groups':score_checks,'prediction_rows':len(predictions),'maximum_stored_coefficient_probability_error':max_error,'maximum_derived_numeric_difference':max_numeric_error,'estimator_fits':0,'calibration_fits':0,'lookup_reconstructions_or_new_models':0,'interpretation':'Replay of previously fitted post hoc diagnostics using preserved coefficients and lookup tables.'}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument('--report',type=Path)
    args=parser.parse_args();root=args.root.resolve()
    if args.report and args.report.resolve().is_relative_to(root):
        parser.error('--report must be outside the release directory')
    report={'schema':'proof-before-transfer-public-verification-v1','runtime':{'python':platform.python_version(),'numpy':np.__version__},'training_calls':0,'calibration_fit_calls':0,'main_model_inference_calls':0,'acquisitions':0,'historical_scripts_executed':False,'pickle_deserializations':0,'complete_pipeline_reproduction_claimed':False}
    status=0
    try:
        report['integrity']=verify_manifest(root)
        data,f5,report['stored_roles_and_schema']=inspect_source_and_partitions(root)
        report['index_derivative']=verify_index(root,f5)
        report['qualification_saved_array_replay']=verify_qualification(root,data)
        report['model_and_calibration_records']=verify_models_and_calibration_records(root,data)
        report['baseline_stored_coefficient_replay']=verify_baselines(root,data)
        after=verify_manifest(root)
        check('release bytes unchanged during verification',after==report['integrity'])
        report['passed']=True
    except Exception as exc:
        report['passed']=False;report['error']=str(exc);status=1
    report['checks']=CHECKS
    report['check_counts']={'total':len(CHECKS),'passed':sum(x['passed'] for x in CHECKS),'failed':sum(not x['passed'] for x in CHECKS)}
    report['limits']=['Saved-array arithmetic does not establish that the task was difficult or free of shortcuts.','Historical acquisition, source-to-binary binding, label-access chronology and absent capture bytes are not reconstructed.','Two historical gate conditions are checked only against saved certificate markers.','The exact frozen nuisance evaluator and fitted nuisance artifact are missing; stored nuisance probabilities and metadata balance are checked without a nuisance fit.','No post-quantum transfer effect is measured.']
    if args.report:
        args.report.resolve().parent.mkdir(parents=True,exist_ok=True)
        args.report.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='checks'},indent=2,allow_nan=False))
    return status


if __name__=='__main__':
    sys.exit(main())
