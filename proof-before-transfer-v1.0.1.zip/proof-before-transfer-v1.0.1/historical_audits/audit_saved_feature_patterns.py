#!/usr/bin/env python3
"""Retrospective descriptive inspection of already evaluated saved features.

No training, fitted classifier, new capture, feature materialization or model
inference occurs. Qualification labels have previously been inspected; results
are diagnostic associations rather than fresh confirmatory evidence.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import numpy as np


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", type=Path, required=True)
    parser.add_argument("--p5", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    package, p5, destination = args.package.resolve(), args.p5.resolve(), args.output.resolve()
    if destination.is_relative_to(package) or destination.is_relative_to(p5):
        raise ValueError("Write report outside original evidence")
    features_path = package / "stage/R5_ELIG_256_FEATURE_ROWS_LABEL_BLIND.jsonl"
    feature_bytes = features_path.read_bytes()
    feature_hash = hashlib.sha256(feature_bytes).hexdigest()
    if feature_hash != "94bee4412fb4a53a0dfbf556a1900ba22adc98b8da9bb041e4ffc208a5736f60":
        raise ValueError("Unexpected feature artifact")
    rows = [json.loads(line) for line in feature_bytes.splitlines() if line.strip()]
    if [row["execution_ordinal"] for row in rows] != list(range(1, 257)):
        raise ValueError("Saved features not in expected execution ordinal order")
    original_output = package / "result/unpacked/output"
    prep = json.loads((original_output / "05_P7_PREP.json").read_text())
    with np.load(original_output / "P7_SCIENTIFIC_ARRAYS.npz", allow_pickle=False) as arrays:
        labels, family = arrays["y"].copy(), arrays["family"].copy()
    if not np.array_equal(labels, prep["r5_y"]) or not np.array_equal(family, prep["r5_family"]):
        raise ValueError("Preparation and saved array labels/families differ")

    train_features_path = p5 / "output/R3_TRAIN_DEV_640_FEATURE_ROWS_LABEL_BLIND.jsonl"
    train_semantics_path = p5 / "input/C6_R3_TRAIN_DEV_PRIMARY_640.jsonl"
    training_features = [json.loads(line) for line in train_features_path.read_text().splitlines() if line.strip()]
    training_semantics = [json.loads(line) for line in train_semantics_path.read_text().splitlines() if line.strip()]
    semantic_index = {(row["U_ID"], row["logical_slot_id"]): row for row in training_semantics}
    if len(training_features) != 640 or len(semantic_index) != 640:
        raise ValueError("Unexpected training/development count")
    split_rows = defaultdict(list)
    seen = set()
    for row in training_features:
        key = (row["U_ID"], row["logical_slot_id"])
        if key in seen or key not in semantic_index:
            raise ValueError("Invalid feature/semantic identity join")
        seen.add(key)
        semantic = semantic_index[key]
        if semantic["partition"] == "R3-TRAIN":
            split = "TRAIN"
        elif semantic["partition"] == "R3-DEV" and semantic["dev_role"] in ("DEV-STOP", "DEV-CAL"):
            split = semantic["dev_role"]
        else:
            raise ValueError("Unexpected historical partition")
        split_rows[split].append((row["features"], int(semantic["label"]), semantic["family"]))
    if {key: len(value) for key, value in split_rows.items()} != {"TRAIN": 512, "DEV-STOP": 64, "DEV-CAL": 64}:
        raise ValueError("Incorrect historical split counts")
    split_rows["QUAL"] = [(row["features"], int(label), str(fam))
                          for row, label, fam in zip(rows, labels, family, strict=True)]
    cross_split = {}
    for feature in ("residual_record_sizing_sequence", "residual_packetization_sequence"):
        tokens = {}
        for split, split_values in split_rows.items():
            by_token = defaultdict(Counter)
            for feat, lab, fam in split_values:
                by_token[canonical(feat[feature])][lab] += 1
            tokens[split] = by_token
        counts = {}
        for split, token_map in tokens.items():
            counts[split] = {
                "units": len(split_rows[split]), "distinct_tokens": len(token_map),
                "tokens_observed_with_both_labels": sum(bool(c[0] and c[1]) for c in token_map.values()),
                "rows_in_tokens_observed_with_both_labels": sum(sum(c.values()) for c in token_map.values() if c[0] and c[1]),
                "tokens_observed_in_TRAIN": len(set(token_map) & set(tokens["TRAIN"])),
                "rows_with_tokens_observed_in_TRAIN": sum(sum(c.values()) for key, c in token_map.items() if key in tokens["TRAIN"]),
                "token_label_conflicts_with_TRAIN": sum(bool((c[0] and tokens["TRAIN"].get(key, {}).get(1, 0))
                                                              or (c[1] and tokens["TRAIN"].get(key, {}).get(0, 0)))
                                                       for key, c in token_map.items())}
        cross_split[feature] = counts

    summaries = {}
    for feature in ("packet_count", "ack_count", "residual_record_sizing_sequence",
                    "residual_packetization_sequence"):
        grouped = defaultdict(Counter)
        for row, label in zip(rows, labels, strict=True):
            grouped[canonical(row["features"][feature])][int(label)] += 1
        summaries[feature] = {
            "distinct_values": len(grouped),
            "values_observed_with_both_labels": sum(bool(v[0] and v[1]) for v in grouped.values()),
            "rows_in_values_observed_with_both_labels": sum(sum(v.values()) for v in grouped.values() if v[0] and v[1]),
            "contingencies": [{"value": json.loads(k), "benign_count": v[0], "malicious_count": v[1]}
                              for k, v in sorted(grouped.items())]}

    positions = [10, 12, 14, 16]
    patterns = defaultdict(Counter)
    for index, (row, label) in enumerate(zip(rows, labels, strict=True)):
        sequence = row["features"]["residual_record_sizing_sequence"]
        if not isinstance(sequence, list) or len(sequence) != 19:
            raise ValueError("Stored record-sizing sequence differs from inspected shape")
        profile = prep["r5_nuisance"][index]["response_volume_bin"]
        values = tuple(sequence[position] for position in positions)
        patterns[(str(family[index]), profile, int(label))][values] += 1
    pattern_rows = [{"family": key[0], "size_bin": key[1], "label": key[2],
                     "record_length_patterns": [{"lengths": list(pattern), "units": count}
                                                for pattern, count in sorted(values.items())]}
                    for key, values in sorted(patterns.items())]
    paired_deltas = []
    for fam in ("F1", "F2"):
        for profile in range(4):
            benign = patterns[(fam, profile, 0)]
            malicious = patterns[(fam, profile, 1)]
            if len(benign) != 1 or len(malicious) != 1:
                raise ValueError("More than one response pattern per family/profile/label")
            lengths0, lengths1 = next(iter(benign)), next(iter(malicious))
            paired_deltas.append({"family": fam, "size_bin": profile,
                                  "benign_units": sum(benign.values()),
                                  "malicious_units": sum(malicious.values()),
                                  "malicious_minus_benign": [b-a for a, b in zip(lengths0, lengths1, strict=True)]})
    result = {"analysis_kind": "retrospective_saved_feature_label_contingency",
              "fresh_confirmatory_evidence": False, "trained_models": 0,
              "new_model_inference_calls": 0, "new_captures": 0,
              "feature_artifact": str(features_path), "feature_sha256": feature_hash,
              "qualification_units": 256,
              "training_feature_artifact": str(train_features_path),
              "training_feature_sha256": hashlib.sha256(train_features_path.read_bytes()).hexdigest(),
              "training_semantic_artifact": str(train_semantics_path),
              "training_semantic_sha256": hashlib.sha256(train_semantics_path.read_bytes()).hexdigest(),
              "training_semantic_join": "640 unique pairs of (U_ID, logical_slot_id), matching historical runner join",
              "split_counts_by_family_and_label": {
                  split: dict(Counter(f"{fam}/label_{lab}" for feat, lab, fam in values))
                  for split, values in split_rows.items()},
              "cross_split_sequence_token_contingencies": cross_split,
              "alignment": "Execution ordinals 1..256; saved P7 y/family match saved preparation arrays.",
              "feature_contingencies": summaries,
              "record_sequence_zero_based_positions_inspected": positions,
              "record_sequence_lengths": {"19": 256},
              "size_profile_label_patterns": pattern_rows,
              "paired_deltas": paired_deltas,
              "all_eight_family_size_groups_have_seven_byte_delta_in_each_of_four_records":
                  all(row["malicious_minus_benign"] == [7, 7, 7, 7] for row in paired_deltas),
              "limitations": [
                  "Describes already inspected qualification data and does not constitute a new baseline evaluation.",
                  "Class-pure repeated feature values demonstrate an easy label association in this saved task; they do not establish which features the fitted detector relied on.",
                  "Identification of the four positions as application response records and attribution of the offset to HTTP status text require independent extractor/server-source verification."]}
    if hashlib.sha256(features_path.read_bytes()).hexdigest() != feature_hash:
        raise RuntimeError("Original feature input changed")
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"report": str(destination), "feature_summaries": {
        key: {k: v for k, v in val.items() if k != "contingencies"} for key, val in summaries.items()},
        "paired_deltas": paired_deltas,
        "cross_split_sequence_tokens": cross_split}, indent=2))


if __name__ == "__main__":
    main()
