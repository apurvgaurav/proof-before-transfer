#!/usr/bin/env python3
"""Static source and deterministic identity audit without training or inference."""
from pathlib import Path
from collections import defaultdict, Counter
import hashlib,json,ast,os

ROOT=Path(os.environ.get('ICSQITS_AUDIT_ROOT',Path.cwd())).expanduser().resolve()
DEST=Path(os.environ.get('ICSQITS_AUDIT_OUTPUT',ROOT/'tmp/icsqits_comprehensive_audit/numerical')).expanduser().resolve()
DEST.mkdir(parents=True,exist_ok=True)
P5=ROOT/'tmp/icsqits_audit_stats/extracted/P3P5/20260911T184357Z'
P7=ROOT/'tmp/icsqits_evidence/p7p8_v2/C6_R5_P7_P8_ONE_TIME_EVALUATION_V2_20260913T053326Z'
tracked={};checks=[]
def read(p):
    b=p.read_bytes();tracked[str(p)]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)};return b.decode()
def jl(p):return [json.loads(x) for x in read(p).splitlines() if x.strip()]
def J(p):return json.loads(read(p))
def c(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def h(v):return hashlib.sha256(v.encode()).hexdigest()
def check(k,v,d=None):checks.append({'check':k,'pass':bool(v),'detail':d})
r3=jl(P5/'input/C6_R3_TRAIN_DEV_PRIMARY_640.jsonl')
r5=jl(P7/'stage/R5_DATASET.jsonl')
prep=J(P7/'result/unpacked/output/05_P7_PREP.json')
runner=read(P5/'src/C6_R3_P3_P4_P5_SCIENTIFIC_RUNNER_V1.py')
eval_source=read(P5/'frozen/C6_R3_FEATURE_MODEL_EVAL_v1.py')
partition_source=read(P5/'frozen/C6_R3_SEMANTIC_AND_PARTITION_v1.py')
materializer=read(P5/'frozen/C6_RAW24_VALUE_MATERIALIZER_STATIC_QUALIFICATION_v4.py')
p7source=read(ROOT/'tmp/icsqits_sources/ICSQITS/C6_R5_P7_P8_ONE_TIME_EVALUATION_V2_20260913.sh')

def objective(f,l):
    return {('F1',0):'authorized nested-path retrieval',('F1',1):'attempted traversal to protected logical object',('F2',0):'public-only lookup',('F2',1):'attempted protected-scope query'}[(f,int(l))]
def normalized(s):
    request=s['request_sequence'];response=s['expected_response_sequence']
    base={k:s[k] for k in ['family','surface_id','target_identifiers','parameter_tokens','parser_branch_sequence','canonical_request_sha256_sequence','canonical_response_body_sha256_sequence','expected_security_disposition','expected_state_transition','security_action_sequence','wire_format_version']}
    base.update({'label':int(s['label']),'objective':objective(s['family'],s['label']),'lambda_policy':'MATCHED_REQUEST_RESPONSE_SIZE_V1','surface_variant_sequence':[int(r['variant']) for r in request], 'request_sequence':[r['request_target'] for r in request],'expected_response_sequence':[int(r['response_class']) for r in response],'request_target_bytes':[int(r['request_target_bytes']) for r in request],'response_body_target_bytes':[int(r['response_body_target_bytes']) for r in response]})
    return base
def ids(s):
    n=normalized(s)
    # Comparing canonical values is equivalent to comparing domain-separated
    # digests for identity collisions, without reusing the original digest code.
    return {'U_ID_IDENTITY':{s['U_ID']},'SEMANTIC_GENERATION_SEED_IDENTITY':{s['semantic_seed_sha256']},'DETERMINISTIC_SEMANTIC_RECORD_IDENTITY':{c(n)},'TEMPLATE_INSTANCE_IDENTITY':{c({'surface_id':n['surface_id'],'surface_variant_sequence':n['surface_variant_sequence']})},'TARGET_COMBINATION_IDENTITY':{c(n['target_identifiers'])},'TARGET_MEMBER_IDENTITY':set(n['target_identifiers']),'PARAMETER_COMBINATION_IDENTITY':{c(n['parameter_tokens'])},'PARAMETER_TOKEN_MEMBER_IDENTITY':set(n['parameter_tokens']),'PARSER_BRANCH_IDENTITY':{c(n['parser_branch_sequence'])},'PAYLOAD_IDENTITY':{c({'canonical_request_sha256_sequence':n['canonical_request_sha256_sequence'],'canonical_response_body_sha256_sequence':n['canonical_response_body_sha256_sequence']})}}
sets=[]
for rows in (r3,r5):
    z=defaultdict(set)
    for s in rows:
        for k,v in ids(s).items():z[k]|=v
    sets.append(z)
overlap={k:len(sets[0][k]&sets[1][k]) for k in sets[0]}
for k,v in overlap.items():check('forbidden identity overlap '+k,v==0 and prep['overlap_checks'][k]==v)
shared_atoms={x for s in r3 for x in s['canonical_response_body_sha256_sequence']}&{x for s in r5 for x in s['canonical_response_body_sha256_sequence']}
check('32 shared response body hash atoms',len(shared_atoms)==32==prep['v1_response_hash_atom_overlap'])

# Reconstruct the candidate ranking from its published deterministic formula,
# not by importing or executing the original generation module.
def candidate(f,l,k):
    cid=f'C6-R3-CAND-{f}-'+('B' if l==0 else 'M')+f'-{k:03d}'
    seed=h(f'C6|R3|SEMGEN|v1|{f}|{l}|{cid}')
    derive=lambda tag:h(f'C6|R3|MAT|v1|{seed}|{tag}')
    vb=int(derive('variant')[:8],16)
    result={'schema_version':'C6-R3-CAND-v1','candidate_id':cid,'family':f,'label':l,'candidate_ordinal':k,'semantic_seed_sha256':seed,'surface_nonce':derive('surface')[:16],'variant_sequence':[(vb+j)%4 for j in range(4)],'objective':objective(f,l),'security_action_sequence':['ALLOW' if l==0 else 'DENY']*4,'partition_assignment_version':'C6-R3-PARTITION-V1'}
    for field,prefix in [('account','r3a_'),('public','r3pub_'),('secure','r3sec_'),('value','r3v_'),('tag','r3t_'),('record','r3r_')]:result[field+'_token']=prefix+derive(field)[:16]
    return result
ranks={};candidate_by_id={}
for fam in ('F1','F2'):
    for label in (0,1):
        generated=[candidate(fam,label,k) for k in range(1,253)]
        ordered=sorted(generated,key=lambda s:(h('C6-R3-PARTITION-V1'+f'{fam}|{label}'+c(s)),s['candidate_id']))
        for rank,s in enumerate(ordered,1):ranks[s['candidate_id']]=rank;candidate_by_id[s['candidate_id']]=s
rank_summary=defaultdict(list);rank_mismatches=[];record_mismatches=[]
for s in r3:
    role=s['partition']; expected=int(s['logical_slot_ordinal'])+(144 if role=='R3-DEV' else 0)
    rank=ranks[s['candidate_id']];rank_summary[role+'/'+s.get('dev_role','')].append(rank)
    if rank!=expected:rank_mismatches.append({'id':s['candidate_id'],'rank':rank,'expected':expected})
    if h(c(candidate_by_id[s['candidate_id']]))!=s['candidate_record_sha256']:record_mismatches.append(s['candidate_id'])
check('all640 R3 rows match deterministic assigned ranks',not rank_mismatches,rank_mismatches)
check('all640 candidate record hashes reconstructed',not record_mismatches,record_mismatches)
check('DEV roles map first/second16 slots',all(s['dev_role']==('DEV-STOP' if s['logical_slot_ordinal']<=16 else 'DEV-CAL') for s in r3 if s['partition']=='R3-DEV'))

# Explicitly inspect source dependencies and chronology; these checks do not
# infer historical proof from the current source itself.
check('R3 schedule read precedes feature loop',runner.index('sched=list(csv.DictReader')<runner.index('# P3: label-blind feature materialization'))
check('R3 semantic records opened after feature materialization',runner.index('semrows=[json.loads')>runner.index('P3_LABEL_UNOPENED_MATERIALIZATION=PASS'))
check('training uses TRAIN rows only',"train=[r for r in joined if r[\"partition\"]==\"R3-TRAIN\"]" in runner)
check('calibration uses DEV-CAL Xc and yc',"margin=np.asarray(m.predict(Xc" in runner and 'e=fm.fit_platt(margin,yc)' in runner)
check('calibrator uses unpenalized logistic regression', 'LogisticRegression(penalty=None,solver="lbfgs",fit_intercept=True,max_iter=1000,tol=1e-8' in eval_source)
check('calibration source has no target smoothing', 'e.fit(X,yy)' in eval_source and 'len(yy)!=64' in eval_source)
check('finite validation applies only to scalar feature list','for k in CONTINUOUS:' in eval_source and 'not math.isfinite(float(r[k]))' in eval_source)
check('gap flag is forward sequence gap','if exp is not None and seq > exp:' in materializer)
check('payload dedup exact direction/sequence range', 'key = (direction, int(p["seq"]), int(p["seq"]) + ln)' in materializer)
check('P8 overlap and freeze rely on certificate markers',"'ZERO_FORBIDDEN_CROSS_PARTITION_OVERLAP=PASS' in (out/'05_PREEXEC_CERT.txt').read_text()" in p7source and "'MODEL_CALIBRATION_ARTIFACTS_FROZEN_BEFORE_R5_ELIG=PASS' in (out/'05_PREEXEC_CERT.txt').read_text()" in p7source)

original_manifest=read(P5/'output/P5_ARTIFACT_MANIFEST.sha256')
calibration_retention={'saved_per_unit_DEV_CAL_main_model_margin_or_probability_arrays_found':False,'source_computes_cal_probs_in_memory':True,'only_recorded_ensemble_minimum':5.680566259384579e-10,'only_recorded_ensemble_maximum':.9999999991758995,'proof_of_complete_DEV_CAL_separation_from_original_saved_vectors':'NOT_ESTABLISHED','basis':'P4 runner, complete P5 output manifest, freeze JSONs and training summary. Baseline DEV-CAL arrays belong to different models.','new_retrospective_audit':'dev_cal_retrospective_report.json establishes complete separation after re-evaluating unchanged models on DEV-CAL only; the original per-unit vectors remain unavailable.'}
server=ROOT/'tmp/icsqits_audit_methods/G6A/C6_R4_G6A_STATIC_RUNTIME_KIT_V1_20260911/go/cmd/c6-r4-server/main.go'
runtime=ROOT/'tmp/icsqits_audit_methods/G6A/C6_R4_G6A_STATIC_RUNTIME_KIT_V1_20260911/go/internal/c6r4/runtime.go'
server_text=read(server);runtime_text=read(runtime)
check('recovered R4 server writes OK and Forbidden','phrase := "OK"' in server_text and 'phrase = "Forbidden"' in server_text)
check('recovered R4 server writes decimal Content-Length','Content-Length: %d' in server_text)
check('recovered F2 runtime uses parsed in-memory Boolean DSL','func evalF2' in runtime_text and 'newParser(dsl)' in runtime_text and 'pub := row{' in runtime_text and 'prot := row{' in runtime_text)

report={'check_counts':{'total':len(checks),'passed':sum(x['pass'] for x in checks),'failed':sum(not x['pass'] for x in checks)},'checks':checks,'declared_overlap_counts':overlap,'shared_response_hash_atoms':len(shared_atoms),'R3_rank_summary':{k:{'n':len(v),'minimum':min(v),'maximum':max(v)} for k,v in rank_summary.items()},'calibration_retention':calibration_retention,
'findings':[{'severity':'precision correction','topic':'response size example','finding':'The quoted768/800/832/864 bodies and880/912/944/976 benign records describe profile0 only. All four profiles have different absolute sizes, while seven-byte malicious-minus-benign differences hold throughout.','recommended_wording':'For profile0, ...; the seven-byte difference holds across all four profiles.'},{'severity':'precision correction','topic':'feature14','finding':'The historical out_of_order_indicator is a forward sequence-gap flag, not a complete generic TCP out-of-order detector. All896 stored values are0.','recommended_wording':'Sequence-gap flag (historical model key unchanged).'}, {'severity':'precision correction','topic':'nonfinite validation','finding':'Finite-value enforcement applies to13 scalar inputs; categorical JSON serialization can represent null and nonstandard NaN. No null/nonfinite values occur in the retained896 feature rows.','recommended_wording':'Nonfinite numeric scalar inputs fail.'},{'severity':'precision correction','topic':'F2 terminology','finding':'The recovered runtime parses Boolean DSL expressions against public/protected in-memory rows; it is not evidence of prepared or parameterized SQL.','recommended_wording':'Public-only versus protected-scope queries in an in-memory DSL.'},{'severity':'limitation','topic':'bootstrap interpretation','finding':'The reproduced percentile bound conditions on the fitted models and observed unit distribution. Repeated categorical patterns and structured profiles/blocks do not establish independence across semantic templates or environments.'},{'severity':'limitation','topic':'TLS reconstruction','finding':'The recovered parser removes exact duplicate intervals and concatenates remaining segments sorted by sequence. It lacks general partial-overlap/gap/wrap handling. All saved retransmission/gap indicators are0, but this is not a universal reconstruction validation.'},{'severity':'evidence gap','topic':'DEV-CAL separability','finding':'Only ensemble extrema and calibrator coefficients are retained; no label-paired per-unit main-model DEV-CAL probabilities/margins were found. Complete separation and solver-tolerance sensitivity must not be asserted as observed results.'},{'severity':'evidence gap','topic':'Table6 reconciliation archive','finding':'The recorded full digest is available, but exact reconciliation archive bytes are not among inspected originals;5 of6 Table6 artifact hashes are directly recomputable.'}], 'scope':'Static source and retained-record audit only; no new acquisition, model fit, main-model prediction, calibration deserialization or transfer experiment.', 'sources':tracked}
for finding in report['findings']:
    if finding['topic']=='DEV-CAL separability':
        finding['finding']='Only ensemble extrema and calibrator coefficients were retained; no label-paired per-unit main-model DEV-CAL probabilities/margins were found. The separately authorized retrospective audit in dev_cal_retrospective_report.json evaluates unchanged models on DEV-CAL only, establishes complete separation, and reports the unpenalized-likelihood implication. These new audit vectors are not recovered historical vectors.'
(DEST/'independent_source_identity_report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'check_counts':report['check_counts'],'failed':[x for x in checks if not x['pass']],'R3_rank_summary':report['R3_rank_summary'],'declared_overlap':overlap},indent=2))
