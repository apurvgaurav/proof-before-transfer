#!/usr/bin/env python3
"""Post hoc model inspection using stored leaf weights only.

Reads five hash-verified CBM files and their documented feature order. Calls
PredictionValuesChange with data=None. Does not load qualification features,
labels, or probabilities; does not fit, predict, or deserialize Platt joblibs.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
from pathlib import Path
import platform
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--p5", type=Path, required=True)
    parser.add_argument("--p7-output", type=Path, required=True)
    parser.add_argument("--dependencies", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    p5, p7, dependencies, destination = (p.resolve() for p in (
        args.p5, args.p7_output, args.dependencies, args.output))
    if destination.is_relative_to(p5) or destination.is_relative_to(p7):
        raise ValueError("Output must be separate from original evidence")
    sys.path.insert(0, str(dependencies))
    import catboost
    from catboost import CatBoostClassifier
    import numpy as np
    import pandas as pd
    import scipy

    archived_runtime = json.loads((p5 / "output/00_RUNTIME.json").read_text())
    if catboost.__version__ != archived_runtime["catboost"]:
        raise ValueError("CatBoost version differs from archived runtime")
    evaluator_path = p5 / "frozen/C6_R3_FEATURE_MODEL_EVAL_v1.py"
    evaluator_ast = ast.parse(evaluator_path.read_text())
    expected_order = None
    for node in evaluator_ast.body:
        if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "FEATURES"
                                                for target in node.targets):
            expected_order = ast.literal_eval(node.value)
    if expected_order is None or len(expected_order) != 24:
        raise ValueError("Expected literal 24-feature order unavailable")
    model_hash_path, seed_path = p7 / "P7_MODEL_HASHES.json", p7 / "P7_SEEDS.json"
    hashes = json.loads(model_hash_path.read_text())
    seeds = json.loads(seed_path.read_text())
    tracked_inputs = [p5 / "output/00_RUNTIME.json", evaluator_path, model_hash_path, seed_path]
    tracked_inputs += [p5 / f"output/models/seed-{seed}.cbm" for seed in seeds]
    original_hashes = {str(path): digest(path) for path in tracked_inputs}
    per_seed = []
    importance_arrays = []
    for seed in seeds:
        model_path = p5 / f"output/models/seed-{seed}.cbm"
        sha = original_hashes[str(model_path)]
        if sha != hashes[str(seed)]["model"]:
            raise ValueError(f"Model digest mismatch: {seed}")
        model = CatBoostClassifier()
        model.load_model(str(model_path))
        if list(model.feature_names_) != expected_order:
            raise ValueError(f"Stored model feature order mismatch: {seed}")
        leaf_weights = np.asarray(model.get_leaf_weights(), dtype=float)
        leaf_counts = np.asarray(model.get_tree_leaf_counts(), dtype=np.int64)
        if leaf_weights.size == 0 or leaf_weights.size != int(leaf_counts.sum()):
            raise ValueError("Stored leaf weights unavailable; stopping without any dataset")
        values = np.asarray(model.get_feature_importance(data=None,
                            type="PredictionValuesChange", thread_count=1, verbose=False), dtype=np.float64)
        if values.shape != (24,) or not np.isfinite(values).all() or np.any(values < 0):
            raise ValueError("Unexpected importance result")
        if not np.isclose(values.sum(), 100., rtol=0, atol=1e-8):
            raise ValueError("Importance normalization is not approximately 100")
        importance_arrays.append(values)
        per_seed.append({"seed": seed, "model_path": str(model_path), "model_sha256": sha,
                         "feature_order": expected_order, "tree_count": int(model.tree_count_),
                         "stored_leaf_weight_count": int(leaf_weights.size),
                         "stored_leaf_weights_sum_over_all_trees": float(leaf_weights.sum()),
                         "normalization_sum": float(values.sum()),
                         "importance_percent_by_feature": dict(zip(expected_order, values.tolist(), strict=True))})
    matrix = np.vstack(importance_arrays)
    mean = np.mean(matrix, axis=0)
    std = np.std(matrix, axis=0, ddof=0)
    order = np.argsort(-mean, kind="stable")
    ranked = [{"feature": expected_order[index], "mean_percent": float(mean[index]),
               "minimum_seed_percent": float(matrix[:, index].min()),
               "maximum_seed_percent": float(matrix[:, index].max()),
               "population_sd_across_five_models": float(std[index])}
              for index in order]
    if {str(path): digest(path) for path in tracked_inputs} != original_hashes:
        raise RuntimeError("An original model or metadata file changed during inspection")
    report = {
        "analysis_kind": "post_hoc_feature_importance_of_stored_models",
        "status": "COMPLETED", "type": "PredictionValuesChange", "data_argument": None,
        "weight_source": "leaf weights embedded in the saved CatBoost CBM files",
        "normalization": "CatBoost-returned per-model importances sum to approximately 100; no additional rescaling",
        "aggregate_definition": "Equal arithmetic mean of five separately normalized model importance vectors; not importance of the calibrated ensemble function",
        "archived_runtime": archived_runtime,
        "audit_runtime": {"python": platform.python_version(), "python_executable": sys.executable,
                          "catboost": catboost.__version__, "catboost_path": catboost.__file__,
                          "numpy": np.__version__, "pandas": pd.__version__, "scipy": scipy.__version__},
        "dependency_setup": {"target": str(dependencies), "source": "https://pypi.org/simple",
                             "package": f"catboost=={catboost.__version__}", "binary_wheel_only": True,
                             "global_environment_changes": False,
                             "initial_missing_dependency_resolved": True},
        "input_hashes_before_and_after_match": True, "input_sha256": original_hashes,
        "models_loaded": 5, "training_calls": 0, "model_prediction_calls": 0,
        "qualification_data_loaded": False, "joblib_deserializations": 0,
        "per_seed": per_seed, "feature_order": expected_order,
        "ranked_mean_importance": ranked,
        "scope_limitations": [
            "Model-internal importance summarizes fitted trees and stored training leaf weights, not fresh qualification evidence or causal feature effects.",
            "Platt calibrators were not loaded; these are the five uncalibrated CatBoost models' internal importance values.",
            "CatBoost version matches the archived version, but Python and supporting scientific-library versions differ and are recorded.",
            "Arithmetic averaging across seed importances is descriptive and is not the exact feature attribution of the probability ensemble."]}
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"report": str(destination), "status": report["status"],
                      "runtime": report["audit_runtime"], "top_features": ranked[:12],
                      "per_seed_normalization_sums": [r["normalization_sum"] for r in per_seed],
                      "inputs_unchanged": True}, indent=2))


if __name__ == "__main__":
    main()
