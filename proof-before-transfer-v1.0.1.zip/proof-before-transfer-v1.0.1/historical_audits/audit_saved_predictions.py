#!/usr/bin/env python3
"""Read-only IC-SQITS saved-output audit. Never imports or runs study code.

This diagnostic reads archived arrays, JSON and checksum manifests; recomputes
arithmetic and the specified bootstrap; and writes a separate report. It does
not acquire traffic, train, recalibrate, infer with a model, or execute P7/P8.
NumPy is the only third-party dependency. NPZ loading disables pickle.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import platform

import numpy as np


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def check_manifest(path: Path) -> dict:
    root = path.parent.resolve()
    members = []
    for number, line in enumerate(path.read_text().splitlines(), 1):
        if not line.strip():
            continue
        expected, relative = line.split(maxsplit=1)
        relative = relative.removeprefix("*")
        resolved = (root / relative).resolve()
        if (not resolved.is_relative_to(root) or
                len(expected) != 64 or any(c not in "0123456789abcdef" for c in expected)):
            raise ValueError(f"Unsafe or invalid manifest entry: {path}:{number}")
        exists = resolved.is_file() and not resolved.is_symlink()
        actual = sha256(resolved) if exists else None
        members.append({"line": number, "relative_path": relative,
                        "expected_sha256": expected, "actual_sha256": actual,
                        "matches": actual == expected})
    return {"path": str(path), "sha256": sha256(path), "members": members,
            "checked_count": len(members),
            "match_count": sum(m["matches"] for m in members),
            "all_match": all(m["matches"] for m in members)}


def probability_summary(probability: np.ndarray, label: np.ndarray,
                        family: np.ndarray) -> dict:
    loss = np.square(probability - label)
    strata = {}
    for name in ("F1", "F2"):
        for value in (0.0, 1.0):
            subset = (family == name) & (label == value)
            probabilities = probability[subset]
            strata[f"{name}_label_{int(value)}"] = {
                "n": int(subset.sum()),
                "probability_quantiles_0_25_50_75_100":
                    np.quantile(probabilities, [0, .25, .5, .75, 1]).tolist(),
                "brier": float(np.mean(loss[subset], dtype=np.float64)),
                "distinct_probability_count": len(np.unique(probabilities)),
            }
    families = {}
    for name in ("F1", "F2"):
        family_loss = float(np.mean(loss[family == name], dtype=np.float64))
        families[name] = {"n": int((family == name).sum()),
                          "brier": family_loss, "gain": float(.25-family_loss)}
    pooled = float(np.mean(loss, dtype=np.float64))
    return {"n": len(label), "brier": pooled, "gain": float(.25-pooled),
            "families": families, "strata": strata,
            "min_probability": float(probability.min()),
            "max_probability": float(probability.max()),
            "distinct_probability_count": len(np.unique(probability)),
            "misclassifications_at_0p5": int(((probability >= .5) != label).sum()),
            "largest_absolute_probability_error": float(np.abs(probability-label).max())}


def nuisance_design_summary(rows: list, labels: list) -> dict:
    groups = defaultdict(Counter)
    for row, label in zip(rows, labels, strict=True):
        key = json.dumps(row, sort_keys=True, separators=(",", ":"))
        groups[key][int(label)] += 1
    return {"n": len(rows), "columns": sorted(rows[0]),
            "column_cardinality": {key: len({json.dumps(row[key], sort_keys=True)
                                             for row in rows}) for key in sorted(rows[0])},
            "distinct_joint_nuisance_vectors": len(groups),
            "joint_vector_group_sizes": dict(Counter(sum(x.values()) for x in groups.values())),
            "joint_vectors_balanced_by_label": sum(x[0] == x[1] for x in groups.values()),
            "all_joint_vectors_balanced_by_label": all(x[0] == x[1] for x in groups.values())}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", type=Path, required=True)
    parser.add_argument("--p5", type=Path, required=True,
                        help="Unpacked P3/P4/P5 timestamp directory")
    parser.add_argument("--runner", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    package, p5, runner = args.package.resolve(), args.p5.resolve(), args.runner.resolve()
    destination = args.output.resolve()
    if destination.is_relative_to(package) or destination.is_relative_to(p5):
        raise ValueError("Report must be separate from original evidence")
    original_output = package / "result/unpacked/output"

    manifests = [check_manifest(path) for path in (
        package / "PACKAGE_MANIFEST.sha256",
        package / "stage/STAGE_MANIFEST.sha256",
        original_output / "PACKAGE_MANIFEST.sha256",
        p5 / "output/P5_ARTIFACT_MANIFEST.sha256")]
    if not all(report["all_match"] for report in manifests):
        raise ValueError(json.dumps({"manifest_failures": [r for r in manifests if not r["all_match"]]}))

    array_path = original_output / "P7_SCIENTIFIC_ARRAYS.npz"
    with np.load(array_path, allow_pickle=False) as loaded:
        arrays = {key: np.array(loaded[key], copy=True) for key in loaded.files}
    expected_keys = {"ensemble", "y", "family", "nuisance"} | {f"seed{i}" for i in range(5)}
    if set(arrays) != expected_keys or any(x.shape != (256,) for x in arrays.values()):
        raise ValueError("Unexpected archived array schema")
    label, family = arrays["y"], arrays["family"]
    if not np.all(np.isin(label, [0., 1.])) or not np.all(np.isin(family, ["F1", "F2"])):
        raise ValueError("Unexpected label or family")
    for key in expected_keys - {"family", "y"}:
        if not np.isfinite(arrays[key]).all() or not ((arrays[key] >= 0) & (arrays[key] <= 1)).all():
            raise ValueError(f"Invalid saved probabilities: {key}")
    strata = [(family == fam) & (label == lab)
              for fam in ("F1", "F2") for lab in (0., 1.)]
    if any(int(mask.sum()) != 64 for mask in strata):
        raise ValueError("Qualification strata are not 64/64/64/64")

    seeds = read_json(original_output / "P7_SEEDS.json")
    recomputed_ensemble = np.mean(np.vstack([arrays[f"seed{i}"] for i in range(5)]),
                                  axis=0, dtype=np.float64)
    if not np.array_equal(recomputed_ensemble, arrays["ensemble"]):
        raise ValueError("Saved ensemble differs from saved calibrated seed means")
    summaries = {key: probability_summary(arrays[key], label, family)
                 for key in ["ensemble", *[f"seed{i}" for i in range(5)], "nuisance"]}

    # Independent arithmetic implementation. Precompute per-unit squared errors;
    # sample complete semantic-unit indices in the documented stratum/RNG order.
    literal = b"C6-R3-COMPETENCE-BOOTSTRAP-V1"
    bootstrap_seed = int.from_bytes(hashlib.sha256(literal).digest()[:8], "big") % 2147483647
    if bootstrap_seed != 1447780860:
        raise ValueError("Bootstrap seed mismatch")
    random = np.random.Generator(np.random.PCG64(bootstrap_seed))
    losses = np.square(arrays["ensemble"] - label)
    grouped_losses = [losses[mask] for mask in strata]
    gains = np.empty(10000, dtype=np.float64)
    for replicate in range(len(gains)):
        sampled_losses = [values[random.integers(0, len(values), size=len(values),
                                                 endpoint=False, dtype=np.int64)]
                          for values in grouped_losses]
        gains[replicate] = .25 - np.mean(np.concatenate(sampled_losses), dtype=np.float64)
    lower_bound = float(np.quantile(gains, .05, method="linear"))
    seed_gains = [summaries[f"seed{i}"]["gain"] for i in range(5)]
    metrics = {"G_POOL": summaries["ensemble"]["gain"], "G_LB95": lower_bound,
               "G_F1": summaries["ensemble"]["families"]["F1"]["gain"],
               "G_F2": summaries["ensemble"]["families"]["F2"]["gain"],
               "SEED_G": seed_gains, "POSITIVE_SEEDS": sum(x > 0 for x in seed_gains),
               "MEDIAN_SEED_G": float(np.median(seed_gains)),
               "G_NUISANCE": summaries["nuisance"]["gain"]}
    p7 = read_json(original_output / "P7_RESULT.json")
    p8 = read_json(original_output / "P8_INDEPENDENT_ADJUDICATION.json")
    equality = {key: {"p7_exact_match": value == p7[key],
                      "p8_exact_match": value == p8["metrics"][key]}
                for key, value in metrics.items()}

    model_reports = []
    saved_model_hashes = read_json(original_output / "P7_MODEL_HASHES.json")
    for seed in seeds:
        for kind, filename in (("model", f"seed-{seed}.cbm"),
                               ("platt", f"seed-{seed}-platt.joblib")):
            path = p5 / "output/models" / filename
            actual = sha256(path)
            model_reports.append({"seed": seed, "kind": kind, "path": str(path),
                                  "expected_sha256": saved_model_hashes[str(seed)][kind],
                                  "actual_sha256": actual,
                                  "matches": actual == saved_model_hashes[str(seed)][kind]})

    prep = read_json(original_output / "05_P7_PREP.json")
    if not np.array_equal(label, prep["r5_y"]) or not np.array_equal(family, prep["r5_family"]):
        raise ValueError("Saved labels/families do not match preexecution preparation")
    certificate = (original_output / "05_PREEXEC_CERT.txt").read_text()
    conditions = {
        "01_exact_256": len(label) == 256,
        "02_64_each": all(mask.sum() == 64 for mask in strata),
        "03_zero_cross_partition_overlap": "ZERO_FORBIDDEN_CROSS_PARTITION_OVERLAP=PASS" in certificate,
        "04_model_freeze": "MODEL_CALIBRATION_ARTIFACTS_FROZEN_BEFORE_R5_ELIG=PASS" in certificate,
        "05_G_POOL_ge_0p01": metrics["G_POOL"] >= .01,
        "06_G_LB95_gt_0": lower_bound > 0,
        "07_G_F1_gt_0": metrics["G_F1"] > 0,
        "08_G_F2_gt_0": metrics["G_F2"] > 0,
        "09_positive_seeds_ge_4": metrics["POSITIVE_SEEDS"] >= 4,
        "10_median_seed_G_gt_0": metrics["MEDIAN_SEED_G"] > 0,
        "11_G_NUISANCE_lt_0p01": metrics["G_NUISANCE"] < .01}
    condition_reports = {}
    for key, value in conditions.items():
        condition_reports[key] = {
            "value": bool(value), "matches_archived_p8": bool(value) == p8["conditions"][key],
            "evidence": "preexecution_certificate_marker_only" if key.startswith(("03_", "04_"))
            else "independently_recomputed_from_saved_arrays"}

    # Recheck manifests after computation to document no input mutations.
    after = [check_manifest(Path(report["path"])) for report in manifests]
    if manifests != after:
        raise RuntimeError("Input evidence changed during audit")
    report = {
        "audit_kind": "independent_arithmetic_diagnostic_from_saved_predictions",
        "original_study_scripts_executed": False,
        "new_acquisitions": 0, "new_model_inference_calls": 0, "training_calls": 0,
        "recalibration_calls": 0, "input_evidence_unchanged": True,
        "runtime": {"python": platform.python_version(), "numpy": np.__version__},
        "package_root": str(package), "p5_root": str(p5),
        "recovered_runner": {"path": str(runner), "sha256": sha256(runner)},
        "manifests": manifests, "model_and_calibrator_bindings": model_reports,
        "array_archive": {"path": str(array_path), "sha256": sha256(array_path),
                          "arrays": {key: {"dtype": str(value.dtype), "shape": list(value.shape),
                                             "contiguous_bytes_sha256": hashlib.sha256(value.tobytes(order="C")).hexdigest()}
                                     for key, value in arrays.items()}},
        "ensemble_exactly_equals_mean_of_five_saved_seed_probabilities": True,
        "seed_index_mapping": {f"seed{i}": seed for i, seed in enumerate(seeds)},
        "probability_summaries": summaries, "recomputed_metrics": metrics,
        "archived_metric_comparisons": equality,
        "brier_reporting_correction": {
            "direct_from_saved_probabilities": summaries["ensemble"]["brier"],
            "from_subtracting_stored_float64_gain_from_0p25": float(.25 - p7["G_POOL"]),
            "explanation": "The manuscript's approximately 7.22e-16 corresponds to reverse subtraction of stored float64 gain; direct scoring gives approximately 7.14e-16. Report direct Brier loss and identify gain rounding."},
        "bootstrap": {"replicates": 10000, "seed": bootstrap_seed,
                      "literal": literal.decode(), "literal_sha256": hashlib.sha256(literal).hexdigest(),
                      "generator": "PCG64", "sample_unit": "semantic_unit",
                      "stratum_order": ["F1/0", "F1/1", "F2/0", "F2/1"],
                      "within_stratum_original_and_resampled_count": 64,
                      "lower_quantile": .05, "quantile_method": "linear",
                      "lower_bound": lower_bound, "min_gain": float(gains.min()),
                      "max_gain": float(gains.max()), "distinct_float64_gain_count": len(np.unique(gains)),
                      "replicate_float64_bytes_sha256": hashlib.sha256(gains.tobytes()).hexdigest()},
        "eleven_condition_comparison": condition_reports,
        "stored_nuisance_design": {
            "training": nuisance_design_summary(prep["train_nuisance"], prep["train_y"]),
            "qualification": nuisance_design_summary(prep["r5_nuisance"], prep["r5_y"]),
            "interpretation": "Each complete nuisance vector has equal counts of both labels. Any deterministic function of that vector has empirical Brier at least 0.25 on this paired set; constant 0.5 attains that bound. This does not test finer traffic features omitted from the nuisance representation."},
        "limits": [
            "Statistics reproduce saved probabilities; they do not independently establish the scientific validity of those probabilities.",
            "No fresh model inference was performed. Recovered runner statically calls saved CatBoost and Platt models on feature-only X (lines 829-848); labels enter scoring at 855-862.",
            "P8 independently recalculates numeric conditions from P7 arrays, but reads certificate markers for conditions 03 and 04 (runner lines 915-916).",
            "Current model/calibrator hashes are checked. Historical freeze chronology and original leakage identity calculations are not reestablished by this arithmetic audit.",
            "Main raw margins and uncalibrated qualification probabilities are not saved in this NPZ. Their investigation requires separate evidence or separately authorized offline inference."]}
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"report": str(destination),
                      "manifests": [{"path": m["path"], "matched": m["match_count"],
                                     "checked": m["checked_count"]} for m in manifests],
                      "npz_sha256": report["array_archive"]["sha256"],
                      "metrics": metrics,
                      "brier": {k: v["brier"] for k, v in summaries.items()},
                      "nuisance_design": report["stored_nuisance_design"],
                      "all_archived_metrics_match_exactly": all(all(v.values()) for v in equality.values())}, indent=2))


if __name__ == "__main__":
    main()
