#!/usr/bin/env python3
"""New retrospective DEV-CAL margin audit, not recovered historical vectors.

Authorized scope: evaluate five unchanged saved CatBoost models on the64 R3
DEV-CAL rows only; apply recorded sigmoid a/b manually. No model fitting,
selection, calibration fitting, qualification inference, or acquisition.
"""
from pathlib import Path
from collections import Counter
import ast,csv,hashlib,json,math,os,platform,sys
import numpy as np
import pandas as pd

ROOT=Path(os.environ.get('ICSQITS_AUDIT_ROOT',Path.cwd())).expanduser().resolve()
DEST=Path(os.environ.get('ICSQITS_AUDIT_OUTPUT',ROOT/'tmp/icsqits_comprehensive_audit/numerical')).expanduser().resolve()
DEST.mkdir(parents=True,exist_ok=True)
P5=ROOT/'tmp/icsqits_audit_stats/extracted/P3P5/20260911T184357Z'
tracked={};checks=[]
def rb(p):
    b=p.read_bytes();tracked[str(p)]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)};return b
def J(p):return json.loads(rb(p))
def JL(p):return [json.loads(x) for x in rb(p).decode().splitlines() if x.strip()]
def check(k,v):checks.append({'check':k,'pass':bool(v)})
source=P5/'frozen/C6_R3_FEATURE_MODEL_EVAL_v1.py'
tree=ast.parse(rb(source).decode())
lit={n.targets[0].id:ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in {'FEATURES','CATEGORICAL','SEEDS'}}
semantic=JL(P5/'input/C6_R3_TRAIN_DEV_PRIMARY_640.jsonl')
rows=JL(P5/'output/R3_TRAIN_DEV_640_FEATURE_ROWS_LABEL_BLIND.jsonl')
sem_by={(r['U_ID'],r['logical_slot_id']):r for r in semantic}
joined=[]
for r in sorted(rows,key=lambda z:z['row']):
    s=sem_by[(r['U_ID'],r['logical_slot_id'])]
    if s['partition']=='R3-DEV' and s['dev_role']=='DEV-CAL':joined.append((r,s))
check('exactly64 DEV-CAL rows',len(joined)==64)
counts=Counter(f"{s['family']}/{s['label']}" for _,s in joined)
check('four strata16 each',dict(counts)=={'F1/0':16,'F1/1':16,'F2/0':16,'F2/1':16})
assert len(joined)==64
X=pd.DataFrame([{k:json.dumps(r['features'][k],sort_keys=True,separators=(',',':'),ensure_ascii=False) if k in lit['CATEGORICAL'] else float(r['features'][k]) for k in lit['FEATURES']} for r,s in joined],columns=lit['FEATURES'])
y=np.array([s['label'] for r,s in joined],dtype=int)
PYDEPS=Path(os.environ.get('ICSQITS_AUDIT_PYDEPS',ROOT/'tmp/icsqits_pydeps')).expanduser().resolve()
if PYDEPS.is_dir():sys.path.insert(0,str(PYDEPS))
import catboost
from catboost import CatBoostClassifier
check('CatBoost1.2.10 matches recorded model runtime',catboost.__version__=='1.2.10')
assert catboost.__version__=='1.2.10'
summary=J(P5/'output/04_P4_TRAINING_SUMMARY.json')
results=[];probabilities=[];perunit=[]
def sigmoid(z):
    z=np.asarray(z,float);out=np.empty(z.shape); positive=z>=0
    out[positive]=1/(1+np.exp(-z[positive]));ez=np.exp(z[~positive]);out[~positive]=ez/(1+ez);return out
for seed in lit['SEEDS']:
    mp=P5/f'output/models/seed-{seed}.cbm';rb(mp)
    freeze=J(P5/f'output/models/seed-{seed}-freeze.json')
    check('frozen model digest '+str(seed),tracked[str(mp)]['sha256']==freeze['model_sha256'])
    model=CatBoostClassifier();model.load_model(str(mp))
    assert list(model.feature_names_)==lit['FEATURES']
    margin=np.asarray(model.predict(X,prediction_type='RawFormulaVal',thread_count=1),dtype=np.float64)
    slope=float(freeze['platt_coef'][0]);intercept=float(freeze['platt_intercept'][0])
    z=slope*margin+intercept;prob=sigmoid(z);probabilities.append(prob)
    max_negative=float(margin[y==0].max()); min_positive=float(margin[y==1].min());gap=min_positive-max_negative
    signed=(2*y-1)*z
    loss=float(np.logaddexp(0,-signed).mean())
    scaled2_loss=float(np.logaddexp(0,-2*signed).mean())
    residual=prob-y
    gradients={'slope_mean':float(np.mean(residual*margin)),'intercept_mean':float(np.mean(residual)), 'slope_sum':float(np.sum(residual*margin)), 'intercept_sum':float(np.sum(residual))}
    mean_norm=max(abs(gradients['slope_mean']),abs(gradients['intercept_mean']))
    row={'seed':seed,'n':64,'maximum_benign_margin':max_negative,'minimum_malicious_margin':min_positive,'separation_gap':gap,'strictly_separable_with_positive_slope':gap>0,'calibrated_correct_at_0p5':int(np.sum((prob>=.5)==y)),'a':slope,'b':intercept,'calibrated_probability_min':float(prob.min()),'calibrated_probability_max':float(prob.max()),'calibrated_brier_on_DEV_CAL':float(np.mean((prob-y)**2)),'mean_log_loss_at_recorded_coefficients':loss,'mean_log_loss_at_2x_same_coefficients':scaled2_loss,'mean_log_loss_gradient':gradients,'mean_gradient_infinity_norm':mean_norm,'recorded_tol':1e-8,'mean_gradient_norm_below_recorded_tol':mean_norm<=1e-8,'all_signed_logits_positive':bool(np.all(signed>0))}
    check('all64 calibration classes separated '+str(seed),gap>0)
    check('doubling coefficients lowers unpenalized loss '+str(seed),scaled2_loss<loss)
    results.append(row)
    for i,(r,s) in enumerate(joined):perunit.append({'seed':seed,'row':r['row'],'unit_id':r['U_ID'],'logical_slot_id':r['logical_slot_id'],'family':s['family'],'label':s['label'],'raw_margin':format(margin[i],'.17g'),'manual_sigmoid_probability':format(prob[i],'.17g')})
ensemble=np.stack(probabilities).mean(axis=0)
ensemble_check={'minimum':float(ensemble.min()),'maximum':float(ensemble.max()),'recorded_minimum':summary['dev_cal_ensemble_min'],'recorded_maximum':summary['dev_cal_ensemble_max'],'minimum_absolute_difference':abs(float(ensemble.min())-summary['dev_cal_ensemble_min']),'maximum_absolute_difference':abs(float(ensemble.max())-summary['dev_cal_ensemble_max']),'brier_on_DEV_CAL':float(np.mean((ensemble-y)**2))}
check('reconstructed ensemble extrema match archived summary',ensemble_check['minimum_absolute_difference']<1e-20 and ensemble_check['maximum_absolute_difference']<1e-14)
check('all audited input hashes unchanged',all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==v['sha256'] for p,v in tracked.items()))
report={'analysis_kind':'new_retrospective_DEV_CAL_margin_audit','historical_per_unit_vectors_recovered':False,'role':'R3 DEV-CAL only','role_n':64,'stratum_counts':dict(counts),'frozen_models_loaded':5,'DEV_CAL_prediction_calls':5,'qualification_prediction_calls':0,'training_or_calibration_fit_calls':0,'hyperparameter_selection_calls':0,'new_acquisition_calls':0,'qualification_outcomes_changed':False,'runtime':{'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'catboost':catboost.__version__},'per_seed':results,'ensemble_extrema_comparison':ensemble_check,'checks':checks,'check_counts':{'total':len(checks),'passed':sum(x['pass'] for x in checks),'failed':sum(not x['pass'] for x in checks)},'interpretation':{'strict_separation':all(x['strictly_separable_with_positive_slope'] for x in results),'finite_unpenalized_MLE_exists':False,'reason':'All64 reconstructed calibration margins are strictly separable for each seed. Scaling a separating slope/intercept together can decrease logistic loss toward0 indefinitely; no finite unpenalized logistic maximum-likelihood coefficient attains the supremum.','numerical_stopping':'Finite saved a/b reflect a numerical stopping rule on this separable calibration task. The independently computed average gradient is compared with the recorded tolerance; this is a diagnostic of tolerance sensitivity, not a recovered solver trace.','qualification_claim_limit':'This explains a mechanism for extreme probabilities; it does not alone prove calibration leakage or quantify transfer performance. The reported qualification Brier remains an arithmetic property of the original saved predictions.'},'sources':tracked}
DEST.mkdir(parents=True,exist_ok=True)
(DEST/'dev_cal_retrospective_report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
with (DEST/'dev_cal_retrospective_margins.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(perunit[0]));writer.writeheader();writer.writerows(perunit)
print(json.dumps({'check_counts':report['check_counts'],'strata':dict(counts),'per_seed':results,'ensemble':ensemble_check},indent=2))
