#!/usr/bin/env python3
"""Independent arithmetic/source audit. No training or main-model predictions.

This script implements the calculations afresh from retained input records,
probabilities and stored baseline coefficients. It does not import prior audit
code. The CatBoost calls inspect metadata and saved leaf-weight importance only.
"""
from pathlib import Path
from collections import Counter, defaultdict
from decimal import Decimal, localcontext
import ast, csv, hashlib, json, math, os, platform, sys, zipfile
import numpy as np
from docx import Document

ROOT=Path(os.environ.get('ICSQITS_AUDIT_ROOT',Path.cwd())).expanduser().resolve()
DEST=Path(os.environ.get('ICSQITS_AUDIT_OUTPUT',ROOT/'tmp/icsqits_comprehensive_audit/numerical')).expanduser().resolve()
DEST.mkdir(parents=True,exist_ok=True)
P5=ROOT/'tmp/icsqits_audit_stats/extracted/P3P5/20260911T184357Z'
P7=ROOT/'tmp/icsqits_evidence/p7p8_v2/C6_R5_P7_P8_ONE_TIME_EVALUATION_V2_20260913T053326Z'
OUT=P7/'result/unpacked/output'
BASE=ROOT/'tmp/icsqits_posthoc_baselines/results'
MAN=ROOT/'outputs/icsqits_revision/ICSQITS_Integrated_Manuscript_Draft.docx'
sources={}
checks=[]
def tracked(path):
    path=Path(path); b=path.read_bytes()
    sources[str(path)]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
    return b
def J(path): return json.loads(tracked(path))
def JL(path): return [json.loads(line) for line in tracked(path).decode().splitlines() if line.strip()]
def check(name,ok,detail=None):
    checks.append({'check':name,'pass':bool(ok),'detail':detail})
def c(v): return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def B(p,y): return math.fsum((float(a)-float(b))**2 for a,b in zip(p,y))/len(y)
def score(p,y):
    p=np.asarray(p,dtype=float); y=np.asarray(y,dtype=int)
    # Pair-comparison AUROC is independent of the original sklearn metric call.
    pos=p[y==1,None]; neg=p[y==0][None,:]
    return {'n':len(y),'brier':B(p,y),'gain':.25-B(p,y),
            'auroc':float(((pos>neg)+.5*(pos==neg)).mean()),
            'accuracy':float(np.mean((p>=.5)==y))}

tracked(MAN)
doc=Document(MAN)
tables=[[[cell.text for cell in row.cells] for row in table.rows] for table in doc.tables]
arrays_path=OUT/'P7_SCIENTIFIC_ARRAYS.npz'
tracked(arrays_path)
a=np.load(arrays_path,allow_pickle=False)
y=a['y']; family=a['family']; p=a['ensemble']
seeds=J(OUT/'P7_SEEDS.json'); reported=J(OUT/'P7_RESULT.json')
check('P7 array schema',set(a.files)=={'ensemble','y','family','nuisance',*[f'seed{i}' for i in range(5)]})
for key in a.files:
    check('array shape '+key,a[key].shape==(256,))
    if key!='family': check('finite '+key,np.isfinite(a[key]).all())
    if key not in ('family','y'): check('probability range '+key,np.all((a[key]>=0)&(a[key]<=1)))
check('ensemble is equal mean of all five saved seed probabilities',np.array_equal(p,np.stack([a[f'seed{i}'] for i in range(5)]).mean(axis=0)))
ensemble=score(p,y)
ensemble['numpy_brier']=float(np.mean((p-y)**2))
with localcontext() as ctx:
    ctx.prec=70
    ensemble['decimal_brier_from_exact_float_inputs']=str(sum((Decimal.from_float(float(v))-Decimal(int(z)))**2 for v,z in zip(p,y))/Decimal(len(y)))
ensemble['maximum_probability_error']=float(np.max(np.abs(p-y)))
check('pooled Brier full manuscript value',ensemble['numpy_brier']==7.138437351572796e-16)
check('stored pooled gain matches direct score',reported['G_POOL']==ensemble['gain'])
strata={}; families={}; seedrows=[]
for f in ('F1','F2'):
    mask=family==f; families[f]=score(p[mask],y[mask])
    check('saved family gain '+f,reported['G_'+f]==families[f]['gain'])
    for label in (0,1):
        mask=(family==f)&(y==label); pp=p[mask]
        strata[f'{f}/{label}']={'n':int(mask.sum()),'minimum':float(pp.min()),'median':float(np.median(pp)),'maximum':float(pp.max())}
        check('64 units in '+f+'/'+str(label),mask.sum()==64)
for i,s in enumerate(seeds):
    row=score(a[f'seed{i}'],y); row['seed']=s; seedrows.append(row)
    check('seed gain '+str(s),row['gain']==reported['SEED_G'][i])
    check('Table3 displayed seed loss '+str(s),format(row['brier'],'.4e')==tables[2][i+1][3].replace('e-0','e-'))
seedgains=[x['gain'] for x in seedrows]
check('five positive seed gains',sum(g>0 for g in seedgains)==5)
check('median seed gain',float(np.median(seedgains))==reported['MEDIAN_SEED_G'])
for row,(key,s) in zip(tables[3][1:],strata.items()):
    fmt='.4e' if key.endswith('/0') else '.10f'
    for j,k in enumerate(('minimum','median','maximum'),1):
        check('Table4 '+key+' '+k,format(s[k],fmt)==row[j])

# Regenerate the prescribed whole-unit bootstrap using a different arrangement:
# fixed 4x64 error matrix, row-wise independently drawn integer indices.
stratum_errors=np.stack([(p[(family==f)&(y==z)]-y[(family==f)&(y==z)])**2 for f in ('F1','F2') for z in (0,1)])
boot_seed=int.from_bytes(hashlib.sha256(b'C6-R3-COMPETENCE-BOOTSTRAP-V1').digest()[:8],'big')%2147483647
rng=np.random.Generator(np.random.PCG64(boot_seed))
gains=np.empty(10000)
for n in range(10000):
    indices=rng.integers(0,64,size=(4,64),dtype=np.int64)
    gains[n]=.25-np.take_along_axis(stratum_errors,indices,axis=1).mean()
ordered=np.sort(gains); h=(len(ordered)-1)*.05; low=int(math.floor(h)); frac=h-low
manual_percentile=float(ordered[low]+frac*(ordered[low+1]-ordered[low]))
bootstrap={'seed':boot_seed,'replicates':10000,'whole_units_per_stratum':64,'manual_linear_05_quantile':manual_percentile,
           'numpy_linear_05_quantile':float(np.quantile(gains,.05,method='linear')),
           'gain_min':float(gains.min()),'gain_max':float(gains.max()),'distinct_float64_gains':int(len(np.unique(gains)))}
check('bootstrap lower bound exact stored match',manual_percentile==reported['G_LB95'])
check('manual and NumPy bootstrap quantiles',manual_percentile==bootstrap['numpy_linear_05_quantile'])

# Join the original semantic rows to feature rows, independently of audit output.
r3=JL(P5/'input/C6_R3_TRAIN_DEV_PRIMARY_640.jsonl')
f3=JL(P5/'output/R3_TRAIN_DEV_640_FEATURE_ROWS_LABEL_BLIND.jsonl')
r5=JL(P7/'stage/R5_DATASET.jsonl')
f5=JL(P7/'stage/R5_ELIG_256_FEATURE_ROWS_LABEL_BLIND.jsonl')
schedule=list(csv.DictReader(tracked(P7/'stage/R5_SCHEDULE.tsv').decode().splitlines(),delimiter='\t'))
s3={(r['U_ID'],r['logical_slot_id']):r for r in r3}
s5={r['logical_slot_id']:r for r in r5}
check('R3 one-to-one joins',len(s3)==len(r3)==len(f3)==640 and set(s3)=={(x['U_ID'],x['logical_slot_id']) for x in f3})
parts=defaultdict(list)
for feature in sorted(f3,key=lambda r:int(r['row'])):
    sem=s3[(feature['U_ID'],feature['logical_slot_id'])]
    role='TRAIN' if sem['partition']=='R3-TRAIN' else sem['dev_role'].replace('-','_')
    parts[role].append({'sem':sem,'features':feature['features'],'pcap_sha256':feature['pcap_sha256']})
for feature,sched in zip(sorted(f5,key=lambda r:int(r['execution_ordinal'])),sorted(schedule,key=lambda r:int(r['r5_elig_execution_ordinal']))):
    sem=s5[sched['logical_slot_id']]
    assert feature['execution_ordinal']==int(sched['r5_elig_execution_ordinal'])
    parts['QUAL'].append({'sem':sem,'features':feature['features'],'pcap_sha256':feature['pcap_sha256']})
check('qualification label and family alignment',np.array_equal([x['sem']['label'] for x in parts['QUAL']],y) and np.array_equal([x['sem']['family'] for x in parts['QUAL']],family))
partition_counts={}
for role,n in [('TRAIN',512),('DEV_STOP',64),('DEV_CAL',64),('QUAL',256)]:
    counts=Counter(f"{r['sem']['family']}/{r['sem']['label']}" for r in parts[role])
    partition_counts[role]={'units':len(parts[role]),'strata':dict(counts),'requests':sum(len(r['sem']['request_sequence']) for r in parts[role])}
    check('partition count '+role,len(parts[role])==n and set(counts.values())=={n//4})
    check('four requests per unit '+role,all(len(r['sem']['request_sequence'])==4 for r in parts[role]))
uids={role:{r['sem']['U_ID'] for r in rows} for role,rows in parts.items()}
for i,role in enumerate(uids):
    for other in list(uids)[i+1:]: check('disjoint unit IDs '+role+' '+other,not(uids[role]&uids[other]))

# Parse literal feature lists without importing executable study code.
evalpath=P5/'frozen/C6_R3_FEATURE_MODEL_EVAL_v1.py'
tree=ast.parse(tracked(evalpath).decode())
literals={node.targets[0].id:ast.literal_eval(node.value) for node in tree.body if isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name) and node.targets[0].id in {'FEATURES','CATEGORICAL','SEEDS'}}
features=literals['FEATURES']; cats=literals['CATEGORICAL']; nums=[k for k in features if k not in cats]
shape_counts={k:Counter() for k in cats}; flags=Counter(); nulls=0; nonfinite=0
def contains_null(v):
    if v is None:return 1
    if isinstance(v,list):return sum(contains_null(x) for x in v)
    if isinstance(v,dict):return sum(contains_null(x) for x in v.values())
    return 0
for rows in parts.values():
    for r in rows:
        f=r['features']; assert set(f)==set(features)
        nulls+=contains_null(f)
        for k in nums: nonfinite+=int(not math.isfinite(float(f[k])))
        for k in cats: shape_counts[k][len(f[k])]+=1
        flags.update({k:int(f[k]) for k in ['retransmission_indicator','out_of_order_indicator']})
feature_audit={'count':len(features),'categorical_count':len(cats),'numeric_count':len(nums),'null_count':nulls,'nonfinite_numeric_count':nonfinite,'sequence_length_distributions':{k:dict(v) for k,v in shape_counts.items()},'positive_flag_counts':dict(flags)}
check('24 features with 11 categorical and 13 numeric',len(features)==24 and len(cats)==11 and len(nums)==13)
check('no missing/null or nonfinite numeric values',nulls==0 and nonfinite==0)

# Nuisance balance: exactly nine input fields, training/evaluation separately.
prep=J(OUT/'05_P7_PREP.json')
nuisance={}
for label,rows,yy in [('TRAIN',prep['train_nuisance'],prep['train_y']),('QUAL',prep['r5_nuisance'],prep['r5_y'])]:
    counts=defaultdict(Counter)
    for row,z in zip(rows,yy):counts[c(row)][int(z)]+=1
    nuisance[label]={'rows':len(rows),'distinct_vectors':len(counts),'fields':sorted(rows[0]),'class_multiplicity_patterns':dict(Counter(str(sorted(x.items())) for x in counts.values())),'every_vector_one_of_each_label':all(v=={0:1,1:1} for v in counts.values())}
    check('nuisance balanced label pairs '+label,nuisance[label]['every_vector_one_of_each_label'])
    check('nine nuisance fields '+label,len(rows[0])==9 and all(set(row)==set(rows[0]) for row in rows))
nuisance['qualification_predictions']=score(a['nuisance'],y)
check('all 256 nuisance probabilities exactly .5',np.array_equal(a['nuisance'],np.full(256,.5)))
check('nuisance gain exactly zero',nuisance['qualification_predictions']['gain']==0)
check('TRAIN nuisance labels align semantic training rows',prep['train_y']==[r['sem']['label'] for r in parts['TRAIN']])

# Pattern occurrence and label homogeneity, including cross-role recurrence.
pattern_audit={}
for key in ['residual_record_sizing_sequence','residual_packetization_sequence']:
    grouped={}
    for role,rows in parts.items():
        g=defaultdict(Counter)
        for r in rows:g[c(r['features'][key])][int(r['sem']['label'])]+=1
        grouped[role]=g
    res={}
    for role,g in grouped.items():
        res[role]={'distinct_tokens':len(g),'label_mixed_tokens':sum(len(v)>1 for v in g.values()),'unseen_in_TRAIN':len(set(g)-set(grouped['TRAIN'])),'tokens_with_different_label_than_TRAIN':sum(set(v)!=set(grouped['TRAIN'][k]) for k,v in g.items() if k in grouped['TRAIN'])}
    pattern_audit[key]=res
    check('no label mixed tokens '+key,all(v['label_mixed_tokens']==0 for v in res.values()))
    check('all later tokens seen with same label '+key,all(v['unseen_in_TRAIN']==0 and v['tokens_with_different_label_than_TRAIN']==0 for v in res.values()))
check('record token counts 24/23/23/24',[pattern_audit['residual_record_sizing_sequence'][r]['distinct_tokens'] for r in ('TRAIN','DEV_STOP','DEV_CAL','QUAL')]==[24,23,23,24])
response_groups=defaultdict(list)
for r in parts['QUAL']:
    s=r['sem']; f=r['features']; response_groups[(s['family'],s['size_profile'],s['label'])].append({'bodies':[int(x['response_body_target_bytes']) for x in s['expected_response_sequence']], 'records':[f['residual_record_sizing_sequence'][j] for j in (10,12,14,16)], 'response_codes':[int(x['response_class']) for x in s['expected_response_sequence']]})
offsets=[]
for fam in ('F1','F2'):
    for profile in range(4):
        benign=response_groups[(fam,profile,0)]; malicious=response_groups[(fam,profile,1)]
        check('16/16 in family/profile '+fam+'/'+str(profile),len(benign)==len(malicious)==16)
        check('identical body profiles in '+fam+'/'+str(profile),len({c(z['bodies']) for z in benign+malicious})==1)
        check('single response pattern per label '+fam+'/'+str(profile),len({c(z['records']) for z in benign})==len({c(z['records']) for z in malicious})==1)
        delta=[a-b for a,b in zip(malicious[0]['records'],benign[0]['records'])]
        check('seven-byte difference in four responses '+fam+'/'+str(profile),delta==[7]*4)
        offsets.append({'family':fam,'profile':profile,'per_label_n':16,'bodies':benign[0]['bodies'],'benign_records':benign[0]['records'],'malicious_records':malicious[0]['records'],'delta':delta})

# Independently derive numeric baseline feature vectors and reconstruct the
# saved prediction function, without model fitting or invoking old scripts.
numeric_names=['packet_count','tcp_payload_bytes_exact_range_dedup','tls_record_count','tls_record_min_bytes','tls_record_max_bytes','tls_record_mean_bytes','tls_record_sd_bytes','capture_duration_seconds','interarrival_min_seconds','interarrival_max_seconds','interarrival_mean_seconds','interarrival_sd_seconds']
def numeric(f):
    records=np.asarray(f['residual_record_sizing_sequence'],float); timing=np.asarray(f['residual_timing_sequence'],float)
    return [float(f['packet_count']),float(sum(f['residual_packetization_sequence'])),float(len(records)),float(min(records)),float(max(records)),float(np.mean(records)),float(np.std(records)),float(np.sum(timing)),float(min(timing)),float(max(timing)),float(np.mean(timing)),float(np.std(timing))]
X={role:np.array([numeric(r['features']) for r in rows]) for role,rows in parts.items()}
Y={role:np.array([r['sem']['label'] for r in rows]) for role,rows in parts.items()}
models=J(BASE/'models.json'); bp=BASE/'predictions_before_qualification_label_load.npz';tracked(bp); saved=np.load(bp,allow_pickle=False)
baseline_results=[]
baseline_names=['packet_count__decision_stump','packet_count__logistic_regression','payload_bytes__decision_stump','payload_bytes__logistic_regression','record_size__decision_stump','record_size__logistic_regression','timing__decision_stump','timing__logistic_regression','joint__decision_stump','joint__logistic_regression','train_prior','record_token_lookup']
for idx,name in enumerate(baseline_names):
    item={'name':name,'qualification_metrics':score(saved[name+'___QUAL'],Y['QUAL'])}
    if name in models and name not in ('train_prior','record_token_lookup'):
        m=models[name];cols=[numeric_names.index(f) for f in m['feature_names']]
        xx=X['TRAIN'][:,cols]
        if m['model_kind']=='logistic_regression':
            means=xx.mean(axis=0);scale=xx.std(axis=0);scale[scale==0]=1
            check('TRAIN fitted mean '+name,np.allclose(means,m['train_scaler_mean'],rtol=0,atol=1e-10))
            check('TRAIN fitted scale '+name,np.allclose(scale,m['train_scaler_scale'],rtol=0,atol=1e-10))
        for role in parts:
            xx=X[role][:,cols]
            if m['model_kind']=='logistic_regression':
                z=((xx-np.array(m['train_scaler_mean']))/np.array(m['train_scaler_scale']))@np.array(m['standardized_coefficients'])+m['intercept']
                reconstructed=1/(1+np.exp(-z))
            else:
                j=m['feature_names'].index(m['root_split_feature']); left=xx[:,j].astype(np.float32)<=m['root_threshold']; values=m['node_class_distributions']
                reconstructed=np.where(left,float(values[1][1]),float(values[2][1]))
                if role=='TRAIN':
                    check('stump TRAIN leaf counts '+name,[int(left.sum()),int((~left).sum())]==m['node_sample_counts'][1:])
                    check('stump TRAIN class frequencies '+name,np.allclose([Y[role][left].mean(),Y[role][~left].mean()],[values[1][1],values[2][1]],rtol=0,atol=1e-15))
            difference=float(np.max(np.abs(reconstructed-saved[name+'___'+role])))
            item.setdefault('prediction_reconstruction_max_abs_errors',{})[role]=difference
            check('baseline probability reconstruction '+name+'/'+role,difference<2e-14)
    elif name=='train_prior':
        for role in parts: check('prior probability '+role,np.array_equal(saved[name+'___'+role],np.full(len(parts[role]),Y['TRAIN'].mean())))
    else:
        train_lookup=defaultdict(list)
        for r in parts['TRAIN']:train_lookup[c(r['features']['residual_record_sizing_sequence'])].append(r['sem']['label'])
        for role,rows in parts.items():
            reconstructed=np.array([np.mean(train_lookup[t]) if (t:=c(r['features']['residual_record_sizing_sequence'])) in train_lookup else Y['TRAIN'].mean() for r in rows])
            check('lookup probability '+role,np.array_equal(reconstructed,saved[name+'___'+role]))
    met=item['qualification_metrics']; row=tables[4][idx+1]
    check('Table5 metrics '+name,[format(met['brier'],'.6f'),format(met['auroc'],'.6f'),format(100*met['accuracy'],'.2f')+'%']==row[1:])
    baseline_results.append(item)

# Hash-verified frozen model metadata and data-free feature importance.
PYDEPS=Path(os.environ.get('ICSQITS_AUDIT_PYDEPS',ROOT/'tmp/icsqits_pydeps')).expanduser().resolve()
if PYDEPS.is_dir():sys.path.insert(0,str(PYDEPS))
import catboost
from catboost import CatBoostClassifier
frozen_hashes=J(OUT/'P7_MODEL_HASHES.json'); summary=J(P5/'output/04_P4_TRAINING_SUMMARY.json')
stored_models=[]; importance=[]
for i,seed in enumerate(seeds):
    mp=P5/f'output/models/seed-{seed}.cbm'; tracked(mp)
    cp=P5/f'output/models/seed-{seed}-platt.joblib';tracked(cp)
    fz=J(P5/f'output/models/seed-{seed}-freeze.json')
    check('CBM hash matches P7 '+str(seed),sources[str(mp)]['sha256']==frozen_hashes[str(seed)]['model']==fz['model_sha256'])
    check('calibrator hash matches freeze '+str(seed),sources[str(cp)]['sha256']==fz['calibrator_sha256'])
    check('Table3 calibrator display '+str(seed),[str(seed),format(fz['platt_coef'][0],'.6f'),format(fz['platt_intercept'][0],'.6f')]==tables[2][i+1][:3])
    model=CatBoostClassifier();model.load_model(str(mp))
    params=model.get_all_params(); meta=dict(model.get_metadata());weights=np.array(model.get_leaf_weights())
    expected_params={'iterations':800,'loss_function':'Logloss','boosting_type':'Ordered','depth':4,'l2_leaf_reg':10,'random_strength':0,'bootstrap_type':'No','rsm':1,'max_ctr_complexity':1,'one_hot_max_size':2,'leaf_estimation_iterations':1,'auto_class_weights':'None','task_type':'CPU','class_weights':[1,1],'random_seed':seed}
    for k,v in expected_params.items():check('saved model parameter '+str(seed)+'/'+k,params.get(k)==v)
    check('saved learning rate agrees at float32 precision '+str(seed),abs(params['learning_rate']-.03)<1e-9)
    fullparams=json.loads(meta['params'])
    values=np.asarray(model.get_feature_importance(type='PredictionValuesChange',data=None,thread_count=1),float)
    check('stored model 800 trees '+str(seed),model.tree_count_==800)
    check('stored model feature names/order '+str(seed),list(model.feature_names_)==features)
    check('importance sums to 100 '+str(seed),abs(float(values.sum())-100)<1e-10)
    importance.append(values)
    stored_models.append({'seed':seed,'tree_count':int(model.tree_count_),'params':params,'metadata_flat_params':fullparams.get('flat_params',{}),'leaf_weights_count':len(weights),'leaf_weights_sum':float(weights.sum()),'importance_sum':float(values.sum()),'model_metadata_keys':sorted(meta)})
matrix=np.stack(importance); impmean=matrix.mean(axis=0)
importance_report=[{'feature':features[j],'mean':float(impmean[j]),'minimum_seed':float(matrix[:,j].min()),'maximum_seed':float(matrix[:,j].max())} for j in np.argsort(-impmean,kind='stable')]
expected_importance={'residual_record_sizing_sequence':94.389875,'tcp_window_sequence':3.227715,'ttl_sequence':2.056352,'packet_count':.319091,'ack_count':.003639,'tcp_option_signature':.003328}
for row in importance_report:
    if row['feature'] in expected_importance:check('display importance '+row['feature'],float(format(row['mean'],'.6f'))==expected_importance[row['feature']])
check('18 zero importances',sum(v==0 for v in impmean)==18)

# Table6: use expected full hashes only as comparison targets, find actual bytes.
hash_manifest=J(ROOT/'tmp/icsqits_evidence_build_v3/ICSQITS_Revision_Evidence/revision/original_artifact_hashes.json')
candidates=[P7/'stage/R5_SOURCE_KIT.tar.gz',P7/'stage/R5_SCHEDULE.tsv',P7/'stage/R5_DATASET.jsonl',P7/'stage/R5_ELIG_256_FEATURE_ROWS_LABEL_BLIND.jsonl']
candidates += [p for p in (ROOT/'tmp/icsqits_sources/ICSQITS').iterdir() if p.is_file() and p.name.endswith(('.gz','.zip'))]
digest_paths=defaultdict(list)
for path in candidates:
    tracked(path);digest_paths[sources[str(path)]['sha256']].append(str(path))
table6=[]
for item,display in zip(hash_manifest['artifacts'],tables[5][1:]):
    hits=digest_paths.get(item['sha256'],[])
    row={**item,'display_prefix':display[1],'actual_files':hits}
    check('Table6 prefix '+item['artifact'],item['sha256'].startswith(display[1]) and item['artifact']==display[0])
    check('Table6 actual bytes found '+item['artifact'],bool(hits))
    table6.append(row)

unchanged=all(hashlib.sha256(Path(path).read_bytes()).hexdigest()==meta['sha256'] for path,meta in sources.items())
check('all tracked input bytes unchanged',unchanged)
report={'audit_kind':'independent_saved_evidence_arithmetic_and_source_check','runtime':{'python':platform.python_version(),'numpy':np.__version__,'catboost':catboost.__version__},
 'prohibited_work_not_performed':{'new_training':0,'main_model_inference':0,'new_acquisition':0,'PQC_transfer_experiments':0,'harder_C0_experiments':0,'joblib_deserializations':0},
 'ensemble':ensemble,'families':families,'strata':strata,'seed_results':seedrows,'bootstrap':bootstrap,'partitions':partition_counts,'features':feature_audit,
 'nuisance':nuisance,'patterns':pattern_audit,'response_record_offsets':offsets,'baseline_results':baseline_results,'stored_models':stored_models,'feature_importance':importance_report,'artifact_hashes':table6,
 'checks':checks,'check_counts':{'total':len(checks),'passed':sum(x['pass'] for x in checks),'failed':sum(not x['pass'] for x in checks)},'sources':sources,
 'limitations':['Recomputing saved probabilities does not establish original acquisition or inference correctness.','Historical feature/tuning non-use of qualification labels requires prospective authority beyond current source input separation.','The nine-field nuisance evaluator is missing; balanced vectors and saved probabilities are verifiable, its actual fitting implementation is not.','The bootstrap reproduces the specified within-family/label whole-unit procedure, but does not validate population independence or performance outside the finite synthetic cohort.','Data-free stored-model importance is descriptive and not a causal or calibrated-ensemble attribution.','These baselines remain post hoc. Manual reconstruction validates saved prediction functions and arithmetic, not preregistration.']}
DEST.mkdir(parents=True,exist_ok=True)
(DEST/'independent_numerical_report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'check_counts':report['check_counts'],'failed':[x for x in checks if not x['pass']],'pooled_brier':ensemble['numpy_brier'],'bootstrap_lower_bound':manual_percentile,'positive_flags':feature_audit['positive_flag_counts']},indent=2))
