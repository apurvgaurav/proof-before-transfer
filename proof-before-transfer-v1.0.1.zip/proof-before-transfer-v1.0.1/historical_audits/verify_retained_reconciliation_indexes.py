#!/usr/bin/env python3
"""Verify retained R5 index relationships; does not claim raw archive verification."""
from pathlib import Path
import csv,hashlib,json,os,tarfile
ROOT=Path(os.environ.get('ICSQITS_AUDIT_ROOT',Path.cwd())).expanduser().resolve()
P7=ROOT/'tmp/icsqits_evidence/p7p8_v2/C6_R5_P7_P8_ONE_TIME_EVALUATION_V2_20260913T053326Z'
DEST=Path(os.environ.get('ICSQITS_AUDIT_OUTPUT',ROOT/'tmp/icsqits_comprehensive_audit/numerical')).expanduser().resolve()
DEST.mkdir(parents=True,exist_ok=True)
archive=P7/'stage/R5_FEATURE_EVIDENCE.tar.gz'
checks=[];members={}
def check(name,ok):checks.append({'check':name,'pass':bool(ok)})
with tarfile.open(archive) as t:
    for name in ['R5_RECONCILIATION_INDEX_AUTHORITY','R5_ROW_PCAP_LABEL_BLIND_INDEX.tsv','01_LOCAL_AUTHORITY_ARCHIVES.txt']:
        entry=next(m for m in t.getmembers() if m.isfile() and m.name.rsplit('/',1)[-1]==name)
        b=t.extractfile(entry).read();members[name]={'member':entry.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'text':b.decode()}
recon=list(csv.DictReader(members['R5_RECONCILIATION_INDEX_AUTHORITY']['text'].splitlines(),delimiter='\t'))
pcap=list(csv.DictReader(members['R5_ROW_PCAP_LABEL_BLIND_INDEX.tsv']['text'].splitlines(),delimiter='\t'))
features=[json.loads(x) for x in (P7/'stage/R5_ELIG_256_FEATURE_ROWS_LABEL_BLIND.jsonl').read_text().splitlines() if x.strip()]
check('retained reconciliation index full SHA matches authority',members['R5_RECONCILIATION_INDEX_AUTHORITY']['sha256']=='188841f2b5d9bf474839bbea80a575d09ab128cb9c7bba02cbe6cfe392c570c2')
check('exact256 reconciliation rows',len(recon)==256)
check('all reconciliation outcomes recorded PASS',all(r['outcome']=='PASS' for r in recon))
check('exact256 PCAP index rows',len(pcap)==256)
check('ordinals1through256 in both indexes',sorted(int(r['execution_ordinal']) for r in recon)==list(range(1,257))==sorted(int(r['execution_ordinal']) for r in pcap))
rd={int(r['execution_ordinal']):r for r in recon};pd={int(r['execution_ordinal']):r for r in pcap}
check('every frozen feature row points to same row archive digest',all(r['reconciled_row_archive_sha256']==rd[int(r['execution_ordinal'])]['row_archive_sha256']==pd[int(r['execution_ordinal'])]['reconciled_row_archive_sha256'] for r in features))
check('every frozen feature row points to same PCAP digest',all(r['pcap_sha256']==pd[int(r['execution_ordinal'])]['pcap_sha256'] for r in features))
report={'checks':checks,'check_counts':{'total':len(checks),'passed':sum(r['pass'] for r in checks),'failed':sum(not r['pass'] for r in checks)},'outer_feature_evidence_archive':{'path':str(archive),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'retained_members':{k:{a:b for a,b in v.items() if a!='text'} for k,v in members.items()},'missing_reconciliation_archive':{'filename':'C6_R5_G6_INDEPENDENT_RECONCILIATION_OUTPUT_V2_20260913.tar.gz','sha256':'9ca63c903fb1c46d5e71e443f11595a6578ff1f4ec098af9469beaf55477af03','actual_bytes_reverified':False},'scope':'Index byte hashes, recorded256 PASS outcomes, and per-ordinal row-archive/PCAP digest consistency are verified. This does not recompute raw R5 capture/reconciliation outcomes or hash the unavailable outer reconciliation archive.'}
(DEST/'retained_reconciliation_index_report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report['check_counts']))
