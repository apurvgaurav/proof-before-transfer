#!/usr/bin/env python3
from __future__ import annotations

class NuisanceMaterializationHold(ValueError):
    pass


def _exact_int(name, value, *, minimum=None):
    if isinstance(value, bool) or not isinstance(value, int):
        raise NuisanceMaterializationHold(f"{name}=NOT_EXACT_INT")
    if minimum is not None and value < minimum:
        raise NuisanceMaterializationHold(f"{name}=OUT_OF_DOMAIN")
    return value


def _exact_int_list(name, value, n):
    if not isinstance(value, (list, tuple)) or len(value) != n:
        raise NuisanceMaterializationHold(f"{name}=BAD_LENGTH")
    out=[]
    for i,v in enumerate(value):
        out.append(_exact_int(f"{name}[{i}]", v, minimum=0))
    return out


def expected_size_profile(logical_slot_ordinal: int) -> int:
    i=_exact_int("logical_slot_ordinal", logical_slot_ordinal, minimum=1)
    return (i-1) % 4


def expected_request_target_bytes(size_profile: int):
    s=_exact_int("size_profile", size_profile, minimum=0)
    if s not in (0,1,2,3):
        raise NuisanceMaterializationHold("size_profile=OUT_OF_DOMAIN")
    return [512 + 128*s + 32*k for k in range(4)]


def expected_response_body_target_bytes(size_profile: int):
    s=_exact_int("size_profile", size_profile, minimum=0)
    if s not in (0,1,2,3):
        raise NuisanceMaterializationHold("size_profile=OUT_OF_DOMAIN")
    return [768 + 128*s + 32*k for k in range(4)]


def materialize_size_bins(*, logical_slot_ordinal, size_profile,
                          request_target_bytes, response_body_target_bytes):
    s_expected=expected_size_profile(logical_slot_ordinal)
    s=_exact_int("size_profile", size_profile, minimum=0)
    if s not in (0,1,2,3):
        raise NuisanceMaterializationHold("size_profile=OUT_OF_DOMAIN")
    if s != s_expected:
        raise NuisanceMaterializationHold("size_profile!=slot_owned_expected")

    req=_exact_int_list("request_target_bytes", request_target_bytes, 4)
    resp=_exact_int_list("response_body_target_bytes", response_body_target_bytes, 4)
    if req != expected_request_target_bytes(s):
        raise NuisanceMaterializationHold("request_target_bytes!=frozen_formula")
    if resp != expected_response_body_target_bytes(s):
        raise NuisanceMaterializationHold("response_body_target_bytes!=frozen_formula")

    return {
        "request_size_bin": s,
        "response_volume_bin": s,
    }


def materialize_run_order_quartile(*, partition_execution_ordinal,
                                   partition_expected_count):
    o=_exact_int("partition_execution_ordinal", partition_execution_ordinal, minimum=1)
    n=_exact_int("partition_expected_count", partition_expected_count, minimum=1)
    if n % 4 != 0:
        raise NuisanceMaterializationHold("partition_expected_count=NOT_DIVISIBLE_BY_4")
    if o > n:
        raise NuisanceMaterializationHold("partition_execution_ordinal>count")
    q=((o-1)*4)//n + 1
    if q not in (1,2,3,4):
        raise NuisanceMaterializationHold("run_order_quartile=INTERNAL_DOMAIN_ERROR")
    return q


def materialize_nuisance_row(source: dict) -> dict:
    required=(
        "semantic_family","environment_id","implementation_id","treatment_arm",
        "request_count","collection_block_index","logical_slot_ordinal","size_profile",
        "request_target_bytes","response_body_target_bytes",
        "partition_execution_ordinal","partition_expected_count",
    )
    if not isinstance(source, dict):
        raise NuisanceMaterializationHold("source=NOT_DICT")
    missing=[k for k in required if k not in source]
    if missing:
        raise NuisanceMaterializationHold("missing="+",".join(missing))

    semantic_family=source["semantic_family"]
    if semantic_family not in ("F1","F2"):
        raise NuisanceMaterializationHold("semantic_family=OUT_OF_DOMAIN")

    for c in ("environment_id","implementation_id","treatment_arm"):
        if not isinstance(source[c], str) or not source[c]:
            raise NuisanceMaterializationHold(f"{c}=INVALID")

    request_count=_exact_int("request_count", source["request_count"], minimum=1)
    if request_count != 4:
        raise NuisanceMaterializationHold("request_count!=4")

    block=_exact_int("collection_block_index", source["collection_block_index"], minimum=1)

    bins=materialize_size_bins(
        logical_slot_ordinal=source["logical_slot_ordinal"],
        size_profile=source["size_profile"],
        request_target_bytes=source["request_target_bytes"],
        response_body_target_bytes=source["response_body_target_bytes"],
    )
    q=materialize_run_order_quartile(
        partition_execution_ordinal=source["partition_execution_ordinal"],
        partition_expected_count=source["partition_expected_count"],
    )

    return {
        "semantic_family": semantic_family,
        "environment_id": source["environment_id"],
        "implementation_id": source["implementation_id"],
        "treatment_arm": source["treatment_arm"],
        "request_count": request_count,
        "request_size_bin": bins["request_size_bin"],
        "response_volume_bin": bins["response_volume_bin"],
        "collection_block_index": block,
        "run_order_quartile": q,
    }
