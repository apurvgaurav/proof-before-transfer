package c6r4

import (
	"bufio"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"sync"
)

type RequestSpec struct {
	Ordinal                int    `json:"ordinal"`
	Variant                int    `json:"variant"`
	ParserBranchID         string `json:"parser_branch_id"`
	Method                 string `json:"method"`
	RequestTarget          string `json:"request_target"`
	DSLExpression          string `json:"dsl_expression"`
	RequestTargetBytes     int    `json:"request_target_bytes"`
	CanonicalRequestSHA256 string `json:"canonical_request_sha256"`
}

type ExpectedResponse struct {
	Ordinal                     int    `json:"ordinal"`
	ResponseBodyTargetBytes     int    `json:"response_body_target_bytes"`
	CanonicalResponseBodySHA256 string `json:"canonical_response_body_sha256"`
	ResponseClass               int    `json:"response_class"`
	SecurityDisposition         string `json:"security_disposition"`
	ApplicationStateTransition  string `json:"application_state_transition"`
}

type SemanticUnit struct {
	SchemaVersion                   string             `json:"schema_version"`
	WireFormatVersion               string             `json:"wire_format_version"`
	CandidateID                     string             `json:"candidate_id"`
	CandidateRecordSHA256           string             `json:"candidate_record_sha256"`
	UID                             string             `json:"U_ID"`
	LogicalSlotID                   string             `json:"logical_slot_id"`
	Partition                       string             `json:"partition"`
	Family                          string             `json:"family"`
	Label                           int                `json:"label"`
	CandidateOrdinal                int                `json:"candidate_ordinal"`
	LogicalSlotOrdinal              int                `json:"logical_slot_ordinal"`
	SizeProfile                     int                `json:"size_profile"`
	BlockID                         string             `json:"block_id"`
	DevRole                         string             `json:"dev_role"`
	SemanticSeedSHA256              string             `json:"semantic_seed_sha256"`
	SurfaceID                       string             `json:"surface_id"`
	SurfaceNonce                    string             `json:"surface_nonce"`
	RequestSequence                 []RequestSpec      `json:"request_sequence"`
	ExpectedResponseSequence        []ExpectedResponse `json:"expected_response_sequence"`
	SecurityActionSequence          []string           `json:"security_action_sequence"`
	ParserBranchSequence            []string           `json:"parser_branch_sequence"`
	ParameterTokens                 []string           `json:"parameter_tokens"`
	TargetIdentifiers               []string           `json:"target_identifiers"`
	CanonicalRequestSHA256Sequence  []string           `json:"canonical_request_sha256_sequence"`
	CanonicalResponseSHA256Sequence []string           `json:"canonical_response_body_sha256_sequence"`
	PayloadHashSequence             []string           `json:"payload_hash_sequence"`
	ExpectedStateTransition         string             `json:"expected_state_transition"`
	ExpectedSecurityDisposition     string             `json:"expected_security_disposition"`
}

type Store struct {
	units map[string]SemanticUnit
}

func SHAHex(b []byte) string {
	s := sha256.Sum256(b)
	return hex.EncodeToString(s[:])
}

func derive(seed, label string) string {
	return SHAHex([]byte("C6|R4|MAT|v1|" + seed + "|" + label))
}

func canonicalRequest(u SemanticUnit, r RequestSpec) ([]byte, int, error) {
	if u.Family == "F1" {
		prefix := []byte("GET " + r.RequestTarget + " HTTP/1.1\r\n" +
			"Host: c6-lab\r\n" +
			"Connection: keep-alive\r\n" +
			"Content-Length: 0\r\n" +
			"X-C6-Pad: ")
		suffix := []byte("\r\n\r\n")
		pad := r.RequestTargetBytes - len(prefix) - len(suffix)
		if pad < 0 {
			return nil, 0, errors.New("F1 negative request pad")
		}
		out := append([]byte{}, prefix...)
		out = append(out, []byte(strings.Repeat("x", pad))...)
		out = append(out, suffix...)
		return out, pad, nil
	}
	body := []byte(r.DSLExpression)
	prefix := []byte("POST " + r.RequestTarget + " HTTP/1.1\r\n" +
		"Host: c6-lab\r\n" +
		"Connection: keep-alive\r\n" +
		"Content-Type: text/x-c6-query\r\n" +
		"Content-Length: " + strconv.Itoa(len(body)) + "\r\n" +
		"X-C6-Pad: ")
	suffix := []byte("\r\n\r\n")
	pad := r.RequestTargetBytes - len(prefix) - len(suffix) - len(body)
	if pad < 0 {
		return nil, 0, errors.New("F2 negative request pad")
	}
	out := append([]byte{}, prefix...)
	out = append(out, []byte(strings.Repeat("x", pad))...)
	out = append(out, suffix...)
	out = append(out, body...)
	return out, pad, nil
}

func CanonicalRequest(u SemanticUnit, ordinal int) ([]byte, error) {
	if ordinal < 1 || ordinal > len(u.RequestSequence) {
		return nil, errors.New("ordinal")
	}
	b, _, err := canonicalRequest(u, u.RequestSequence[ordinal-1])
	return b, err
}

func responseBody(u SemanticUnit, target int) ([]byte, error) {
	var base string
	switch {
	case u.Family == "F1" && u.Label == 0:
		if len(u.ParameterTokens) != 6 {
			return nil, errors.New("F1 token count")
		}
		base = "family=F1\nresult=ALLOW\nobject=" + u.ParameterTokens[1] +
			"\nbody=" + derive(u.SemanticSeedSHA256, "public-body") +
			"\nstate=NO_MUTATION\npad="
	case u.Family == "F1":
		base = "family=F1\nresult=DENY\nobject=NONE\nbody=DENIED\nstate=NO_MUTATION\npad="
	case u.Family == "F2" && u.Label == 0:
		if len(u.ParameterTokens) != 6 {
			return nil, errors.New("F2 token count")
		}
		base = "family=F2\nresult=ALLOW\nrecord=" + u.ParameterTokens[5] + "\nstate=NO_MUTATION\npad="
	default:
		base = "family=F2\nresult=DENY\nrecord=NONE\nstate=NO_MUTATION\npad="
	}
	b := []byte(base)
	pad := target - len(b)
	if pad < 0 {
		return nil, errors.New("negative response pad")
	}
	b = append(b, []byte(strings.Repeat("x", pad))...)
	if len(b) != target {
		return nil, errors.New("response size mismatch")
	}
	return b, nil
}

func validateUnit(u SemanticUnit) error {
	if u.SchemaVersion != "C6-R4-SEM-v1" || u.WireFormatVersion != "C6-R4-WIRE-v1" {
		return fmt.Errorf("schema/wire mismatch uid=%s", u.UID)
	}
	if u.Partition != "R4-ELIG" {
		return fmt.Errorf("runtime rejects non TRAIN/DEV unit: %s", u.UID)
	}
	if u.Family != "F1" && u.Family != "F2" {
		return errors.New("family")
	}
	if u.Label != 0 && u.Label != 1 {
		return errors.New("label")
	}
	if len(u.ParameterTokens) != 6 ||
		len(u.RequestSequence) != 4 ||
		len(u.ExpectedResponseSequence) != 4 ||
		len(u.SecurityActionSequence) != 4 ||
		len(u.ParserBranchSequence) != 4 ||
		len(u.CanonicalRequestSHA256Sequence) != 4 ||
		len(u.CanonicalResponseSHA256Sequence) != 4 {
		return fmt.Errorf("cardinality uid=%s", u.UID)
	}
	expectedStatus := 200
	expectedDisposition := "ALLOW"
	if u.Label == 1 {
		expectedStatus = 403
		expectedDisposition = "DENY"
	}
	if u.ExpectedStateTransition != "NO_MUTATION" || u.ExpectedSecurityDisposition != expectedDisposition {
		return fmt.Errorf("frozen semantics uid=%s", u.UID)
	}
	for i := 0; i < 4; i++ {
		r := u.RequestSequence[i]
		e := u.ExpectedResponseSequence[i]
		if r.Ordinal != i+1 || e.Ordinal != i+1 {
			return fmt.Errorf("ordinal uid=%s", u.UID)
		}
		wantMethod := "GET"
		if u.Family == "F2" {
			wantMethod = "POST"
		}
		if r.Method != wantMethod {
			return fmt.Errorf("method uid=%s ordinal=%d", u.UID, i+1)
		}
		if r.Variant < 0 || r.Variant > 3 || e.ResponseClass != expectedStatus ||
			e.SecurityDisposition != expectedDisposition || e.ApplicationStateTransition != "NO_MUTATION" {
			return fmt.Errorf("request/response semantics uid=%s ordinal=%d", u.UID, i+1)
		}
		wire, _, err := canonicalRequest(u, r)
		if err != nil {
			return err
		}
		if len(wire) != r.RequestTargetBytes || SHAHex(wire) != r.CanonicalRequestSHA256 ||
			r.CanonicalRequestSHA256 != u.CanonicalRequestSHA256Sequence[i] {
			return fmt.Errorf("request provenance uid=%s ordinal=%d", u.UID, i+1)
		}
		body, err := responseBody(u, e.ResponseBodyTargetBytes)
		if err != nil {
			return err
		}
		if SHAHex(body) != e.CanonicalResponseBodySHA256 ||
			e.CanonicalResponseBodySHA256 != u.CanonicalResponseSHA256Sequence[i] {
			return fmt.Errorf("response provenance uid=%s ordinal=%d", u.UID, i+1)
		}
	}
	return nil
}

func LoadStore(path string) (*Store, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	s := &Store{units: map[string]SemanticUnit{}}
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 64*1024), 4*1024*1024)
	for sc.Scan() {
		var u SemanticUnit
		if err := json.Unmarshal(sc.Bytes(), &u); err != nil {
			return nil, fmt.Errorf("json: %w", err)
		}
		if err := validateUnit(u); err != nil {
			return nil, err
		}
		if _, ok := s.units[u.UID]; ok {
			return nil, fmt.Errorf("duplicate uid=%s", u.UID)
		}
		s.units[u.UID] = u
	}
	if err := sc.Err(); err != nil {
		return nil, err
	}
	if len(s.units) != 256 {
		return nil, fmt.Errorf("expected 256 R4 ELIG units got=%d", len(s.units))
	}
	return s, nil
}

func LoadSingleUnit(path string) (SemanticUnit, error) {
	f, err := os.Open(path)
	if err != nil {
		return SemanticUnit{}, err
	}
	defer f.Close()
	b, err := io.ReadAll(io.LimitReader(f, 4*1024*1024))
	if err != nil {
		return SemanticUnit{}, err
	}
	var u SemanticUnit
	if err := json.Unmarshal(b, &u); err != nil {
		return SemanticUnit{}, err
	}
	if err := validateUnit(u); err != nil {
		return SemanticUnit{}, err
	}
	return u, nil
}

func (s *Store) Unit(uid string) (SemanticUnit, bool) {
	u, ok := s.units[uid]
	return u, ok
}

type token struct {
	kind string
	val  string
}
type lexer struct {
	s string
	i int
}

func (l *lexer) skip() {
	for l.i < len(l.s) && (l.s[l.i] == ' ' || l.s[l.i] == '\t') {
		l.i++
	}
}
func (l *lexer) next() (token, error) {
	l.skip()
	if l.i >= len(l.s) {
		return token{kind: "EOF"}, nil
	}
	if strings.HasPrefix(l.s[l.i:], "==") {
		l.i += 2
		return token{kind: "EQ", val: "=="}, nil
	}
	if l.s[l.i] == '(' {
		l.i++
		return token{kind: "LP", val: "("}, nil
	}
	if l.s[l.i] == ')' {
		l.i++
		return token{kind: "RP", val: ")"}, nil
	}
	if l.s[l.i] == '"' {
		l.i++
		start := l.i
		for l.i < len(l.s) && l.s[l.i] != '"' {
			l.i++
		}
		if l.i >= len(l.s) {
			return token{}, errors.New("unterminated string")
		}
		v := l.s[start:l.i]
		l.i++
		return token{kind: "STR", val: v}, nil
	}
	if (l.s[l.i] >= 'A' && l.s[l.i] <= 'Z') || (l.s[l.i] >= 'a' && l.s[l.i] <= 'z') || l.s[l.i] == '_' {
		start := l.i
		for l.i < len(l.s) {
			c := l.s[l.i]
			if !((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
				(c >= '0' && c <= '9') || c == '_') {
				break
			}
			l.i++
		}
		v := l.s[start:l.i]
		switch v {
		case "AND", "OR":
			return token{kind: v, val: v}, nil
		case "true":
			return token{kind: "TRUE", val: v}, nil
		default:
			return token{kind: "ID", val: v}, nil
		}
	}
	return token{}, fmt.Errorf("unexpected DSL character at %d", l.i)
}

type node struct {
	op    string
	field string
	sval  string
	bval  bool
	left  *node
	right *node
}
type parser struct {
	l   lexer
	cur token
}

func newParser(s string) (*parser, error) {
	p := &parser{l: lexer{s: s}}
	t, err := p.l.next()
	if err != nil {
		return nil, err
	}
	p.cur = t
	return p, nil
}
func (p *parser) advance() error {
	t, err := p.l.next()
	if err != nil {
		return err
	}
	p.cur = t
	return nil
}
func (p *parser) take(k string) (string, error) {
	if p.cur.kind != k {
		return "", fmt.Errorf("expected %s got %s", k, p.cur.kind)
	}
	v := p.cur.val
	return v, p.advance()
}
func (p *parser) parse() (*node, error) {
	n, err := p.parseOr()
	if err != nil {
		return nil, err
	}
	if p.cur.kind != "EOF" {
		return nil, fmt.Errorf("trailing token %s", p.cur.kind)
	}
	return n, nil
}
func (p *parser) parseOr() (*node, error) {
	n, err := p.parseAnd()
	if err != nil {
		return nil, err
	}
	for p.cur.kind == "OR" {
		if _, err := p.take("OR"); err != nil {
			return nil, err
		}
		r, err := p.parseAnd()
		if err != nil {
			return nil, err
		}
		n = &node{op: "OR", left: n, right: r}
	}
	return n, nil
}
func (p *parser) parseAnd() (*node, error) {
	n, err := p.parsePrimary()
	if err != nil {
		return nil, err
	}
	for p.cur.kind == "AND" {
		if _, err := p.take("AND"); err != nil {
			return nil, err
		}
		r, err := p.parsePrimary()
		if err != nil {
			return nil, err
		}
		n = &node{op: "AND", left: n, right: r}
	}
	return n, nil
}
func (p *parser) parsePrimary() (*node, error) {
	if p.cur.kind == "LP" {
		if _, err := p.take("LP"); err != nil {
			return nil, err
		}
		n, err := p.parseOr()
		if err != nil {
			return nil, err
		}
		if _, err := p.take("RP"); err != nil {
			return nil, err
		}
		return n, nil
	}
	field, err := p.take("ID")
	if err != nil {
		return nil, err
	}
	if _, err := p.take("EQ"); err != nil {
		return nil, err
	}
	if p.cur.kind == "STR" {
		v, err := p.take("STR")
		if err != nil {
			return nil, err
		}
		return &node{op: "EQ_S", field: field, sval: v}, nil
	}
	if p.cur.kind == "TRUE" {
		if _, err := p.take("TRUE"); err != nil {
			return nil, err
		}
		return &node{op: "EQ_B", field: field, bval: true}, nil
	}
	return nil, errors.New("expected DSL value")
}

type row struct {
	Owner     string
	Tag       string
	ID        string
	Class     string
	Protected bool
}

func evalNode(n *node, r row) (bool, error) {
	switch n.op {
	case "AND":
		a, e := evalNode(n.left, r)
		if e != nil {
			return false, e
		}
		b, e := evalNode(n.right, r)
		return a && b, e
	case "OR":
		a, e := evalNode(n.left, r)
		if e != nil {
			return false, e
		}
		b, e := evalNode(n.right, r)
		return a || b, e
	case "EQ_S":
		var v string
		switch n.field {
		case "owner":
			v = r.Owner
		case "tag":
			v = r.Tag
		case "id":
			v = r.ID
		case "class":
			v = r.Class
		default:
			return false, fmt.Errorf("unknown field %s", n.field)
		}
		return v == n.sval, nil
	case "EQ_B":
		if n.field != "protected" {
			return false, fmt.Errorf("boolean field %s", n.field)
		}
		return r.Protected == n.bval, nil
	default:
		return false, errors.New("node")
	}
}
func astCanonical(n *node) string {
	switch n.op {
	case "AND", "OR":
		return n.op + "(" + astCanonical(n.left) + "," + astCanonical(n.right) + ")"
	case "EQ_S":
		return "EQ(" + n.field + ",S:" + n.sval + ")"
	case "EQ_B":
		return "EQ(" + n.field + ",B:true)"
	}
	return ""
}

func evalF2(u SemanticUnit, dsl string) (string, string, string, error) {
	if len(u.ParameterTokens) != 6 {
		return "", "", "", errors.New("F2 token count")
	}
	value := u.ParameterTokens[3]
	tag := u.ParameterTokens[4]
	record := u.ParameterTokens[5]
	secure := u.ParameterTokens[2]
	p, err := newParser(dsl)
	if err != nil {
		return "", "", "", err
	}
	ast, err := p.parse()
	if err != nil {
		return "", "", "", err
	}
	pub := row{Owner: value, Tag: tag, ID: record, Class: "public", Protected: false}
	prot := row{Owner: value, Tag: tag, ID: secure, Class: "protected", Protected: true}
	pm, err := evalNode(ast, pub)
	if err != nil {
		return "", "", "", err
	}
	sm, err := evalNode(ast, prot)
	if err != nil {
		return "", "", "", err
	}
	astHash := SHAHex([]byte("C6-R4-AST-v1|" + astCanonical(ast)))
	if sm {
		return "DENY", "INCLUDES_PROTECTED", astHash, nil
	}
	if !pm {
		return "", "", "", errors.New("no public row")
	}
	return "ALLOW", "PUBLIC_ONLY", astHash, nil
}

var dotEscape = regexp.MustCompile(`(?i)%2e`)

func normalizeF1Target(raw string) (string, error) {
	i := strings.Index(raw, "/f1/")
	if i < 0 {
		return "", errors.New("missing f1 marker")
	}
	logical := dotEscape.ReplaceAllString(raw[i+4:], ".")
	slash := strings.Index(logical, "/")
	if slash < 0 {
		return "", errors.New("missing nonce separator")
	}
	logical = logical[slash+1:]
	var parts []string
	for _, seg := range strings.Split(logical, "/") {
		switch seg {
		case "", ".":
			continue
		case "..":
			if len(parts) == 0 {
				return "", errors.New("underflow")
			}
			parts = parts[:len(parts)-1]
		default:
			parts = append(parts, seg)
		}
	}
	return "/" + strings.Join(parts, "/"), nil
}
func f1Tokens(u SemanticUnit) (string, string, string, error) {
	var a, p, s string
	for _, t := range u.ParameterTokens {
		switch {
		case strings.HasPrefix(t, "r4a_"):
			if a != "" {
				return "", "", "", errors.New("dup a")
			}
			a = t
		case strings.HasPrefix(t, "r4pub_"):
			if p != "" {
				return "", "", "", errors.New("dup pub")
			}
			p = t
		case strings.HasPrefix(t, "r4sec_"):
			if s != "" {
				return "", "", "", errors.New("dup sec")
			}
			s = t
		}
	}
	if a == "" || p == "" || s == "" {
		return "", "", "", errors.New("missing logical tokens")
	}
	return a, p, s, nil
}
func evalF1(u SemanticUnit, raw string) (string, string, string, error) {
	n, err := normalizeF1Target(raw)
	if err != nil {
		return "", "", "", err
	}
	a, p, s, err := f1Tokens(u)
	if err != nil {
		return "", "", "", err
	}
	allow := "/home/" + a + "/docs/" + p
	deny := "/home/" + a + "/protected/" + s
	if n == allow {
		return "ALLOW", "authorized object", n, nil
	}
	if n == deny {
		return "DENY", "protected logical object", n, nil
	}
	return "", "", "", errors.New("unexpected normalized target")
}

type ObservedRequest struct {
	Method        string
	RawURI        string
	Host          string
	ContentLength int
	XC6Pad        string
	Body          []byte
}
type TraceRecord struct {
	ExecutionID                string `json:"execution_id"`
	UID                        string `json:"U_ID"`
	LogicalSlotID              string `json:"logical_slot_id"`
	Ordinal                    int    `json:"ordinal"`
	ParserBranchID             string `json:"parser_branch_id"`
	ObservedMethod             string `json:"observed_method"`
	ObservedRawURI             string `json:"observed_raw_uri"`
	ObservedBodySHA256         string `json:"observed_body_sha256"`
	ExpectedRequestSHA256      string `json:"expected_canonical_request_sha256"`
	NormalizedPath             string `json:"normalized_path,omitempty"`
	LogicalScope               string `json:"logical_scope,omitempty"`
	SyntaxTreeSHA256           string `json:"syntax_tree_sha256,omitempty"`
	ResponseClass              int    `json:"response_class"`
	ResponseBodySHA256         string `json:"response_body_sha256"`
	BeforeStateSHA256          string `json:"before_state_sha256"`
	AfterStateSHA256           string `json:"after_state_sha256"`
	SecurityDisposition        string `json:"security_disposition"`
	ApplicationStateTransition string `json:"application_state_transition"`
}
type Evaluation struct {
	Status int
	Body   []byte
	Trace  TraceRecord
}

type Session struct {
	mu     sync.Mutex
	store  *Store
	active *SemanticUnit
	execID string
	pos    int
}

func NewSession(s *Store) *Session { return &Session{store: s} }
func (s *Session) Reset(uid, execID string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	u, ok := s.store.Unit(uid)
	if !ok {
		return fmt.Errorf("unknown uid=%s", uid)
	}
	if execID == "" {
		return errors.New("exec id")
	}
	c := u
	s.active = &c
	s.execID = execID
	s.pos = 0
	return nil
}
func (s *Session) Abort() { s.mu.Lock(); defer s.mu.Unlock(); s.active = nil; s.execID = ""; s.pos = 0 }
func (s *Session) Status() (string, string, int, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.active == nil {
		return "", "", 0, true
	}
	return s.active.UID, s.execID, s.pos, s.pos == 4
}
func stateHash(u SemanticUnit) string {
	return SHAHex([]byte("C6-R4-STATE-V1|" + u.UID + "|NO_MUTATION"))
}

func (s *Session) Evaluate(obs ObservedRequest) (Evaluation, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.active == nil {
		return Evaluation{}, errors.New("not reset")
	}
	if s.pos >= 4 {
		return Evaluation{}, errors.New("already complete")
	}
	u := *s.active
	idx := s.pos
	spec := u.RequestSequence[idx]
	exp := u.ExpectedResponseSequence[idx]
	if obs.Method != spec.Method {
		return Evaluation{}, fmt.Errorf("method mismatch")
	}
	if obs.RawURI != spec.RequestTarget {
		return Evaluation{}, fmt.Errorf("raw URI mismatch")
	}
	if obs.Host != "c6-lab" {
		return Evaluation{}, fmt.Errorf("host mismatch %q", obs.Host)
	}
	wire, pad, err := canonicalRequest(u, spec)
	if err != nil {
		return Evaluation{}, err
	}
	if len(obs.XC6Pad) != pad || strings.Trim(obs.XC6Pad, "x") != "" {
		return Evaluation{}, errors.New("pad mismatch")
	}
	if u.Family == "F1" {
		if obs.ContentLength != 0 || len(obs.Body) != 0 {
			return Evaluation{}, errors.New("F1 body")
		}
	} else {
		if obs.ContentLength != len([]byte(spec.DSLExpression)) || string(obs.Body) != spec.DSLExpression {
			return Evaluation{}, errors.New("F2 body")
		}
	}
	if len(wire) != spec.RequestTargetBytes || SHAHex(wire) != spec.CanonicalRequestSHA256 {
		return Evaluation{}, errors.New("canonical request provenance")
	}
	var disposition, scope, norm, ast string
	if u.Family == "F1" {
		disposition, scope, norm, err = evalF1(u, obs.RawURI)
	} else {
		disposition, scope, ast, err = evalF2(u, string(obs.Body))
	}
	if err != nil {
		return Evaluation{}, err
	}
	if disposition != exp.SecurityDisposition {
		return Evaluation{}, errors.New("semantic disposition")
	}
	body, err := responseBody(u, exp.ResponseBodyTargetBytes)
	if err != nil {
		return Evaluation{}, err
	}
	if SHAHex(body) != exp.CanonicalResponseBodySHA256 {
		return Evaluation{}, errors.New("response provenance")
	}
	before := stateHash(u)
	after := stateHash(u)
	tr := TraceRecord{ExecutionID: s.execID, UID: u.UID, LogicalSlotID: u.LogicalSlotID, Ordinal: spec.Ordinal,
		ParserBranchID: spec.ParserBranchID, ObservedMethod: obs.Method, ObservedRawURI: obs.RawURI,
		ObservedBodySHA256: SHAHex(obs.Body), ExpectedRequestSHA256: spec.CanonicalRequestSHA256,
		NormalizedPath: norm, LogicalScope: scope, SyntaxTreeSHA256: ast, ResponseClass: exp.ResponseClass,
		ResponseBodySHA256: SHAHex(body), BeforeStateSHA256: before, AfterStateSHA256: after,
		SecurityDisposition: disposition, ApplicationStateTransition: "NO_MUTATION"}
	s.pos++
	return Evaluation{Status: exp.ResponseClass, Body: body, Trace: tr}, nil
}

func BuildObserved(u SemanticUnit, ordinal int) (ObservedRequest, error) {
	if ordinal < 1 || ordinal > 4 {
		return ObservedRequest{}, errors.New("ordinal")
	}
	r := u.RequestSequence[ordinal-1]
	_, pad, err := canonicalRequest(u, r)
	if err != nil {
		return ObservedRequest{}, err
	}
	body := []byte(nil)
	cl := 0
	if u.Family == "F2" {
		body = []byte(r.DSLExpression)
		cl = len(body)
	}
	return ObservedRequest{Method: r.Method, RawURI: r.RequestTarget, Host: "c6-lab", ContentLength: cl, XC6Pad: strings.Repeat("x", pad), Body: body}, nil
}

func SortedUIDs(s *Store) []string {
	out := make([]string, 0, len(s.units))
	for k := range s.units {
		out = append(out, k)
	}
	sort.Strings(out)
	return out
}
