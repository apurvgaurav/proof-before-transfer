package c6r4

import (
	"os"
	"testing"
)

func TestExhaustiveR4EligDataset(t *testing.T) {
	p := os.Getenv("C6_R4_ELIG_DATASET")
	if p == "" {
		t.Skip("dataset env absent")
	}
	s, e := LoadStore(p)
	if e != nil {
		t.Fatal(e)
	}
	uids := SortedUIDs(s)
	if len(uids) != 256 {
		t.Fatalf("uids=%d", len(uids))
	}
	evals := 0
	for _, uid := range uids {
		u, _ := s.Unit(uid)
		sess := NewSession(s)
		if e := sess.Reset(uid, "C6-R4-OFFLINE-"+uid); e != nil {
			t.Fatal(e)
		}
		for i := 1; i <= 4; i++ {
			obs, e := BuildObserved(u, i)
			if e != nil {
				t.Fatal(e)
			}
			ev, e := sess.Evaluate(obs)
			if e != nil {
				t.Fatalf("%s/%d: %v", uid, i, e)
			}
			if ev.Status != u.ExpectedResponseSequence[i-1].ResponseClass {
				t.Fatal("status")
			}
			evals++
		}
		_, _, pos, done := sess.Status()
		if pos != 4 || !done {
			t.Fatal("session completion")
		}
	}
	if evals != 1024 {
		t.Fatalf("evals=%d", evals)
	}
}
