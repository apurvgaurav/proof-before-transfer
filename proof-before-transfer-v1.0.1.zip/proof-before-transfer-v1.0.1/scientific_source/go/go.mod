module c6.invalid/r4runtime

go 1.23
