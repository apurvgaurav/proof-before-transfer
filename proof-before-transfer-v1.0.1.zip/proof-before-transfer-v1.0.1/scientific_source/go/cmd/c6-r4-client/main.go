package main

import (
	"bufio"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"net"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"c6.invalid/r4runtime/internal/c6r4"
)

type ledgerEvent struct {
	Schema                 string `json:"schema_version"`
	Sequence               int    `json:"sequence"`
	ExecutionID            string `json:"execution_id"`
	UID                    string `json:"U_ID"`
	LogicalSlotID          string `json:"logical_slot_id"`
	RequestOrdinal         int    `json:"request_ordinal"`
	CanonicalRequestSHA256 string `json:"canonical_request_sha256"`
	LiveCommit             string `json:"LIVE_COMMIT"`
	DispatchCommit         string `json:"REQUEST_DISPATCH_COMMIT"`
	MonotonicUnixLikeNS    int64  `json:"process_monotonic_elapsed_ns"`
	UTCNS                  int64  `json:"utc_ns"`
}
type ledger struct {
	root  string
	start time.Time
	seq   int
	u     c6r4.SemanticUnit
	exec  string
}

func newLedger(root, exec string, u c6r4.SemanticUnit) (*ledger, error) {
	if err := os.Mkdir(root, 0700); err != nil {
		return nil, err
	}
	return &ledger{root: root, start: time.Now(), u: u, exec: exec}, nil
}
func syncDir(p string) error {
	d, e := os.Open(p)
	if e != nil {
		return e
	}
	defer d.Close()
	return d.Sync()
}
func (l *ledger) write(ord int, sha, live, disp string) error {
	l.seq++
	e := ledgerEvent{Schema: "C6-R4-DISPATCH-LEDGER-v1", Sequence: l.seq, ExecutionID: l.exec, UID: l.u.UID, LogicalSlotID: l.u.LogicalSlotID,
		RequestOrdinal: ord, CanonicalRequestSHA256: sha, LiveCommit: live, DispatchCommit: disp,
		MonotonicUnixLikeNS: time.Since(l.start).Nanoseconds(), UTCNS: time.Now().UnixNano()}
	b, er := json.Marshal(e)
	if er != nil {
		return er
	}
	b = append(b, '\n')
	p := filepath.Join(l.root, fmt.Sprintf("%03d.json", l.seq))
	f, er := os.OpenFile(p, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if er != nil {
		return er
	}
	if _, er = f.Write(b); er == nil {
		er = f.Sync()
	}
	ce := f.Close()
	if er == nil {
		er = ce
	}
	if er != nil {
		return er
	}
	return syncDir(l.root)
}
func curve(name string) (tls.CurveID, error) {
	if name == "X25519" {
		return tls.X25519, nil
	}
	if name == "X25519MLKEM768" {
		return tls.CurveID(4588), nil
	}
	return 0, errors.New("group")
}
func shaFile(p string) (string, error) {
	b, e := os.ReadFile(p)
	if e != nil {
		return "", e
	}
	s := sha256.Sum256(b)
	return hex.EncodeToString(s[:]), nil
}
func main() {
	var unitPath, dest, source, group, caPath, serverName, evidence, consumed, execID, release, releaseSHA string
	var self bool
	flag.StringVar(&unitPath, "unit", "", "unit")
	flag.StringVar(&dest, "dest", "10.66.0.20:10443", "dest")
	flag.StringVar(&source, "source", "10.66.0.10", "source")
	flag.StringVar(&group, "group", "X25519", "group")
	flag.StringVar(&caPath, "ca", "", "ca")
	flag.StringVar(&serverName, "server-name", "c6-phase0.invalid", "servername")
	flag.StringVar(&evidence, "evidence-dir", "", "evidence")
	flag.StringVar(&consumed, "consumed-marker", "", "consumed")
	flag.StringVar(&execID, "execution-id", "", "exec")
	flag.StringVar(&release, "release-token", "", "release")
	flag.StringVar(&releaseSHA, "release-token-sha256", "", "release sha")
	flag.BoolVar(&self, "self-test", false, "self")
	flag.Parse()
	if self {
		fmt.Println("C6_R4_CLIENT_SELF_TEST=PASS")
		fmt.Println("X25519_ID=29")
		fmt.Println("X25519MLKEM768_ID=4588")
		return
	}
	if unitPath == "" || caPath == "" || evidence == "" || consumed == "" || execID == "" || release == "" || releaseSHA == "" {
		fatal("required flags")
	}
	if _, e := os.Stat(consumed); e == nil {
		fatal("consumed marker already exists")
	}
	if _, e := os.Stat(evidence); e == nil {
		fatal("evidence dir already exists")
	}
	rh, e := shaFile(release)
	if e != nil || rh != releaseSHA {
		fatal("release token")
	}
	u, e := c6r4.LoadSingleUnit(unitPath)
	if e != nil {
		fatal("unit:" + e.Error())
	}
	if u.Partition != "R4-ELIG" {
		fatal("partition")
	}
	cv, e := curve(group)
	if e != nil {
		fatal("group")
	}
	rootPEM, e := os.ReadFile(caPath)
	if e != nil {
		fatal("ca")
	}
	pool := x509.NewCertPool()
	if !pool.AppendCertsFromPEM(rootPEM) {
		fatal("ca parse")
	}
	if e := os.Mkdir(evidence, 0700); e != nil {
		fatal("evidence mkdir")
	}
	led, e := newLedger(filepath.Join(evidence, "dispatch-ledger"), execID, u)
	if e != nil {
		fatal("ledger")
	}
	// All offline validation is complete. Durable authority consumption + LIVE_COMMIT happens immediately before TLS dial.
	marker := fmt.Sprintf("STUDY=C6-IC-SQITS\nREALIZATION=C6-R4\nU_ID=%s\nLOGICAL_SLOT_ID=%s\nEXECUTION_ID=%s\nLIVE_COMMIT=YES\nAUTOMATIC_RETRY=0\n", u.UID, u.LogicalSlotID, execID)
	mf, e := os.OpenFile(consumed, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		fatal("consumed create")
	}
	if _, e = mf.WriteString(marker); e == nil {
		e = mf.Sync()
	}
	ce := mf.Close()
	if e == nil {
		e = ce
	}
	if e != nil {
		fatal("consumed sync")
	}
	if e := syncDir(filepath.Dir(consumed)); e != nil {
		fatal("consumed dir sync")
	}
	if e := led.write(0, "", "YES", "NO"); e != nil {
		fatal("live ledger")
	}
	dialer := &net.Dialer{Timeout: 4 * time.Second, LocalAddr: &net.TCPAddr{IP: net.ParseIP(source)}}
	cfg := &tls.Config{RootCAs: pool, ServerName: serverName, MinVersion: tls.VersionTLS13, MaxVersion: tls.VersionTLS13,
		CurvePreferences: []tls.CurveID{cv}, SessionTicketsDisabled: true, DynamicRecordSizingDisabled: true}
	conn, e := tls.DialWithDialer(dialer, "tcp", dest, cfg)
	if e != nil {
		fatal("tls dial:" + e.Error())
	}
	defer conn.Close()
	_ = conn.SetDeadline(time.Now().Add(8 * time.Second))
	br := bufio.NewReaderSize(conn, 128*1024)
	for i := 1; i <= 4; i++ {
		req, e := c6r4.CanonicalRequest(u, i)
		if e != nil {
			fatal("request build")
		}
		want := u.RequestSequence[i-1].CanonicalRequestSHA256
		s := sha256.Sum256(req)
		if hex.EncodeToString(s[:]) != want {
			fatal("request hash")
		}
		// Durable REQUEST_DISPATCH_COMMIT immediately before first write capable of submitting request bytes.
		if e := led.write(i, want, "YES", "YES"); e != nil {
			fatal("dispatch ledger")
		}
		n, e := conn.Write(req)
		if e != nil || n != len(req) {
			fatal("request write")
		}
		status, headers, body, e := readResponse(br)
		if e != nil {
			fatal("response")
		}
		exp := u.ExpectedResponseSequence[i-1]
		if status != exp.ResponseClass {
			fatal("status")
		}
		if len(body) != exp.ResponseBodyTargetBytes {
			fatal("body length")
		}
		bh := sha256.Sum256(body)
		bhs := hex.EncodeToString(bh[:])
		if bhs != exp.CanonicalResponseBodySHA256 {
			fatal("body hash")
		}
		bp := filepath.Join(evidence, fmt.Sprintf("response-%d.body", i))
		if e := os.WriteFile(bp, body, 0600); e != nil {
			fatal("body write")
		}
		fmt.Printf("REQUEST_%d=PASS status=%d body_sha256=%s content_length=%s\n", i, status, bhs, headers["content-length"])
	}
	st := conn.ConnectionState()
	fmt.Printf("TLS_VERSION=%d\n", st.Version)
	fmt.Printf("TLS_CIPHER=%d\n", st.CipherSuite)
	fmt.Printf("DID_RESUME=%t\n", st.DidResume)
	fmt.Printf("CLIENT_DECISION=PASS\n")
}
func fatal(s string) {
	fmt.Fprintln(os.Stderr, "CLIENT_DECISION=HOLD")
	fmt.Fprintln(os.Stderr, "REASON="+s)
	os.Exit(2)
}
func readResponse(br *bufio.Reader) (int, map[string]string, []byte, error) {
	line, e := br.ReadString('\n')
	if e != nil {
		return 0, nil, nil, e
	}
	p := strings.Split(strings.TrimSuffix(line, "\r\n"), " ")
	if len(p) < 2 {
		return 0, nil, nil, errors.New("status line")
	}
	status, e := strconv.Atoi(p[1])
	if e != nil {
		return 0, nil, nil, e
	}
	h := map[string]string{}
	for {
		x, e := br.ReadString('\n')
		if e != nil {
			return 0, nil, nil, e
		}
		if x == "\r\n" {
			break
		}
		q := strings.SplitN(strings.TrimSuffix(x, "\r\n"), ":", 2)
		if len(q) != 2 {
			return 0, nil, nil, errors.New("header")
		}
		h[strings.ToLower(strings.TrimSpace(q[0]))] = strings.TrimSpace(q[1])
	}
	cl, e := strconv.Atoi(h["content-length"])
	if e != nil || cl < 0 || cl > 65536 {
		return 0, nil, nil, errors.New("content length")
	}
	b := make([]byte, cl)
	if _, e := io.ReadFull(br, b); e != nil {
		return 0, nil, nil, e
	}
	return status, h, b, nil
}
