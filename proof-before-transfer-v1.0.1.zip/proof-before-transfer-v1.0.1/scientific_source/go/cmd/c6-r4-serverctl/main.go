package main

import (
	"bufio"
	"flag"
	"fmt"
	"net"
	"os"
	"strings"
	"time"
)

func main() {
	var sock string
	flag.StringVar(&sock, "socket", "/run/c6/c6-r4-control.sock", "socket")
	flag.Parse()
	if flag.NArg() < 1 {
		fmt.Fprintln(os.Stderr, "command required")
		os.Exit(2)
	}
	c, e := net.DialTimeout("unix", sock, 2*time.Second)
	if e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
	defer c.Close()
	if _, e := fmt.Fprintln(c, strings.Join(flag.Args(), "\t")); e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
	sc := bufio.NewScanner(c)
	if !sc.Scan() {
		fmt.Fprintln(os.Stderr, "no response")
		os.Exit(1)
	}
	fmt.Println(sc.Text())
	if !strings.HasPrefix(sc.Text(), "OK\t") {
		os.Exit(1)
	}
}
