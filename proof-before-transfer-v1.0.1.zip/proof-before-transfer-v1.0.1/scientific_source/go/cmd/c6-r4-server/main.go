package main

import (
	"bufio"
	"crypto/tls"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"log"
	"net"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"

	"c6.invalid/r4runtime/internal/c6r4"
)

func curve(name string) (tls.CurveID, error) {
	switch name {
	case "X25519":
		return tls.X25519, nil
	case "X25519MLKEM768":
		return tls.CurveID(4588), nil
	default:
		return 0, fmt.Errorf("unsupported group %q", name)
	}
}
func main() {
	var data, listen, group, certPath, keyPath, ctl, traceDir string
	var self bool
	flag.StringVar(&data, "data", "", "R4 ELIG JSONL")
	flag.StringVar(&listen, "listen", "10.66.0.20:10443", "listen")
	flag.StringVar(&group, "group", "X25519", "group")
	flag.StringVar(&certPath, "cert", "", "cert chain")
	flag.StringVar(&keyPath, "key", "", "key")
	flag.StringVar(&ctl, "control-socket", "/run/c6/c6-r4-control.sock", "control")
	flag.StringVar(&traceDir, "trace-dir", "/var/lib/c6-r4/traces", "trace")
	flag.BoolVar(&self, "self-test", false, "offline self-test")
	flag.Parse()
	if self {
		fmt.Println("C6_R4_SERVER_SELF_TEST=PASS")
		fmt.Println("X25519_ID=29")
		fmt.Println("X25519MLKEM768_ID=4588")
		return
	}
	if data == "" || certPath == "" || keyPath == "" {
		log.Fatal("data/cert/key required")
	}
	cv, err := curve(group)
	if err != nil {
		log.Fatal(err)
	}
	store, err := c6r4.LoadStore(data)
	if err != nil {
		log.Fatal(err)
	}
	if err := os.MkdirAll(traceDir, 0700); err != nil {
		log.Fatal(err)
	}
	sess := c6r4.NewSession(store)
	var traceMu sync.Mutex
	var trace *os.File
	setTrace := func(exec string) error {
		traceMu.Lock()
		defer traceMu.Unlock()
		if trace != nil {
			_ = trace.Close()
			trace = nil
		}
		p := filepath.Join(traceDir, exec+".jsonl")
		f, err := os.OpenFile(p, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
		if err != nil {
			return err
		}
		trace = f
		return nil
	}
	_ = os.Remove(ctl)
	if err := os.MkdirAll(filepath.Dir(ctl), 0755); err != nil {
		log.Fatal(err)
	}
	cl, err := net.Listen("unix", ctl)
	if err != nil {
		log.Fatal(err)
	}
	if err := os.Chmod(ctl, 0660); err != nil {
		log.Fatal(err)
	}
	go func() {
		for {
			c, e := cl.Accept()
			if e != nil {
				log.Printf("ctl accept: %v", e)
				continue
			}
			go func(conn net.Conn) {
				defer conn.Close()
				sc := bufio.NewScanner(conn)
				if !sc.Scan() {
					return
				}
				f := strings.Split(sc.Text(), "\t")
				switch f[0] {
				case "RESET":
					if len(f) != 3 {
						fmt.Fprintln(conn, "ERR\tRESET_ARGS")
						return
					}
					if e := sess.Reset(f[1], f[2]); e != nil {
						fmt.Fprintf(conn, "ERR\tRESET\t%v\n", e)
						return
					}
					if e := setTrace(f[2]); e != nil {
						sess.Abort()
						fmt.Fprintf(conn, "ERR\tTRACE\t%v\n", e)
						return
					}
					fmt.Fprintln(conn, "OK\tRESET")
				case "STATUS":
					uid, ex, pos, done := sess.Status()
					fmt.Fprintf(conn, "OK\tSTATUS\t%s\t%s\t%d\t%t\n", uid, ex, pos, done)
				case "ABORT":
					sess.Abort()
					fmt.Fprintln(conn, "OK\tABORT")
				default:
					fmt.Fprintln(conn, "ERR\tUNKNOWN")
				}
			}(c)
		}
	}()
	pair, err := tls.LoadX509KeyPair(certPath, keyPath)
	if err != nil {
		log.Fatal(err)
	}
	cfg := &tls.Config{Certificates: []tls.Certificate{pair}, MinVersion: tls.VersionTLS13, MaxVersion: tls.VersionTLS13,
		CurvePreferences: []tls.CurveID{cv}, SessionTicketsDisabled: true, DynamicRecordSizingDisabled: true}
	ln, err := tls.Listen("tcp", listen, cfg)
	if err != nil {
		log.Fatal(err)
	}
	defer ln.Close()
	log.Printf("C6 R3 server ready listen=%s group=%s", listen, group)
	for {
		conn, e := ln.Accept()
		if e != nil {
			log.Printf("accept: %v", e)
			continue
		}
		if e := serveConn(conn, sess, &traceMu, &trace); e != nil {
			log.Printf("connection hold: %v", e)
		}
	}
}

func serveConn(conn net.Conn, sess *c6r4.Session, traceMu *sync.Mutex, trace **os.File) error {
	defer conn.Close()
	if tc, ok := conn.(*tls.Conn); ok {
		_ = tc.SetDeadline(time.Now().Add(15 * time.Second))
		if err := tc.Handshake(); err != nil {
			return err
		}
		_ = tc.SetDeadline(time.Time{})
	}
	br := bufio.NewReaderSize(conn, 128*1024)
	bw := bufio.NewWriterSize(conn, 128*1024)
	for n := 0; n < 4; n++ {
		obs, err := readRequest(br)
		if err != nil {
			return err
		}
		ev, err := sess.Evaluate(obs)
		if err != nil {
			return err
		}
		traceMu.Lock()
		if *trace != nil {
			raw, _ := json.Marshal(ev.Trace)
			if _, e := (*trace).Write(append(raw, '\n')); e != nil {
				traceMu.Unlock()
				return e
			}
			if e := (*trace).Sync(); e != nil {
				traceMu.Unlock()
				return e
			}
		}
		traceMu.Unlock()
		phrase := "OK"
		if ev.Status == 403 {
			phrase = "Forbidden"
		}
		header := fmt.Sprintf("HTTP/1.1 %d %s\r\nContent-Type: text/plain\r\nContent-Length: %d\r\nConnection: keep-alive\r\n\r\n", ev.Status, phrase, len(ev.Body))
		if _, err := bw.WriteString(header); err != nil {
			return err
		}
		if _, err := bw.Write(ev.Body); err != nil {
			return err
		}
		if err := bw.Flush(); err != nil {
			return err
		}
	}
	return nil
}

func readRequest(br *bufio.Reader) (c6r4.ObservedRequest, error) {
	line, err := br.ReadString('\n')
	if err != nil {
		return c6r4.ObservedRequest{}, err
	}
	if len(line) > 8192 || !strings.HasSuffix(line, "\r\n") {
		return c6r4.ObservedRequest{}, fmt.Errorf("request line")
	}
	parts := strings.Split(strings.TrimSuffix(line, "\r\n"), " ")
	if len(parts) != 3 || parts[2] != "HTTP/1.1" {
		return c6r4.ObservedRequest{}, fmt.Errorf("request line fields")
	}
	headers := map[string]string{}
	total := len(line)
	for {
		h, err := br.ReadString('\n')
		if err != nil {
			return c6r4.ObservedRequest{}, err
		}
		total += len(h)
		if total > 128*1024 {
			return c6r4.ObservedRequest{}, fmt.Errorf("headers too large")
		}
		if h == "\r\n" {
			break
		}
		if !strings.HasSuffix(h, "\r\n") {
			return c6r4.ObservedRequest{}, fmt.Errorf("header ending")
		}
		p := strings.SplitN(strings.TrimSuffix(h, "\r\n"), ":", 2)
		if len(p) != 2 {
			return c6r4.ObservedRequest{}, fmt.Errorf("header parse")
		}
		k := strings.ToLower(strings.TrimSpace(p[0]))
		if _, exists := headers[k]; exists {
			return c6r4.ObservedRequest{}, fmt.Errorf("duplicate header %s", k)
		}
		headers[k] = strings.TrimSpace(p[1])
	}
	cl := 0
	if x := headers["content-length"]; x != "" {
		v, e := strconv.Atoi(x)
		if e != nil || v < 0 || v > 65536 {
			return c6r4.ObservedRequest{}, fmt.Errorf("content length")
		}
		cl = v
	}
	body := make([]byte, cl)
	if cl > 0 {
		if _, err := io.ReadFull(br, body); err != nil {
			return c6r4.ObservedRequest{}, err
		}
	}
	return c6r4.ObservedRequest{Method: parts[0], RawURI: parts[1], Host: headers["host"], ContentLength: cl, XC6Pad: headers["x-c6-pad"], Body: body}, nil
}
