import hashlib,json,pathlib,sys
import numpy as np
W=pathlib.Path(sys.argv[1]); out=W/'output'
a=np.load(out/'P7_SCIENTIFIC_ARRAYS.npz',allow_pickle=False)
ep=np.asarray(a['ensemble'],dtype=np.float64); y=np.asarray(a['y'],dtype=np.float64)
fam=np.asarray(a['family']); nu=np.asarray(a['nuisance'],dtype=np.float64)
seeds=[np.asarray(a[f'seed{i}'],dtype=np.float64) for i in range(5)]
reported=json.loads((out/'P7_RESULT.json').read_text())

def brier(p,z): return np.mean(np.square(p-z),dtype=np.float64)
def gain(p,z): return np.float64(.25)-brier(p,z)
gp=gain(ep,y); gf1=gain(ep[fam=='F1'],y[fam=='F1']); gf2=gain(ep[fam=='F2'],y[fam=='F2'])
sg=[gain(p,y) for p in seeds]; gn=gain(nu,y)

literal=b"C6-R3-COMPETENCE-BOOTSTRAP-V1"
if hashlib.sha256(literal).hexdigest()!='d8ce649224ae98d5d91e73191b18caafee685d7b3c5ff6fdeb9e23a42c48d0c4':
    raise SystemExit("P8_BOOT_LITERAL")
seed=int.from_bytes(hashlib.sha256(literal).digest()[:8],'big')%2147483647
if seed!=1447780860: raise SystemExit("P8_BOOT_SEED")
rng=np.random.Generator(np.random.PCG64(seed)); gs=np.empty(10000,dtype=np.float64)
strata=[(ep[(fam==f)&(y==l)],y[(fam==f)&(y==l)]) for f,l in (('F1',0.),('F1',1.),('F2',0.),('F2',1.))]
for r in range(10000):
    ps=[]; ys=[]
    for p,z in strata:
        if len(p)!=64: raise SystemExit("P8_STRATUM")
        ix=rng.integers(0,64,size=64,endpoint=False,dtype=np.int64)
        ps.append(p[ix]); ys.append(z[ix])
    gs[r]=gain(np.concatenate(ps),np.concatenate(ys))
lb=float(np.quantile(gs,0.05,method='linear'))
pos=sum(float(x)>0.0 for x in sg); med=float(np.median(np.asarray(sg,dtype=np.float64)))

conds={
 "01_exact_256":len(y)==256,
 "02_64_each":all(int(((fam==f)&(y==l)).sum())==64 for f in ('F1','F2') for l in (0.,1.)),
 "03_zero_cross_partition_overlap":'ZERO_FORBIDDEN_CROSS_PARTITION_OVERLAP=PASS' in (out/'05_PREEXEC_CERT.txt').read_text(),
 "04_model_freeze":'MODEL_CALIBRATION_ARTIFACTS_FROZEN_BEFORE_R5_ELIG=PASS' in (out/'05_PREEXEC_CERT.txt').read_text(),
 "05_G_POOL_ge_0p01":float(gp)>=0.01,
 "06_G_LB95_gt_0":lb>0.0,
 "07_G_F1_gt_0":float(gf1)>0.0,
 "08_G_F2_gt_0":float(gf2)>0.0,
 "09_positive_seeds_ge_4":pos>=4,
 "10_median_seed_G_gt_0":med>0.0,
 "11_G_NUISANCE_lt_0p01":float(gn)<0.01,
}
metrics={"G_POOL":float(gp),"G_LB95":lb,"G_F1":float(gf1),"G_F2":float(gf2),
"SEED_G":[float(x) for x in sg],"POSITIVE_SEEDS":pos,"MEDIAN_SEED_G":med,"G_NUISANCE":float(gn)}
for k in ("G_POOL","G_LB95","G_F1","G_F2","MEDIAN_SEED_G","G_NUISANCE"):
    if not np.isclose(float(reported[k]),float(metrics[k]),rtol=0,atol=1e-15):
        raise SystemExit("P8_REPORTED_METRIC_MISMATCH_"+k)
if reported["POSITIVE_SEEDS"]!=pos: raise SystemExit("P8_POSITIVE_SEEDS")
if not np.allclose(np.asarray(reported["SEED_G"]),np.asarray(metrics["SEED_G"]),rtol=0,atol=1e-15):
    raise SystemExit("P8_SEED_G")
passed=all(conds.values())
review={"conditions":conds,"metrics":metrics,"PASS":passed,
"DECISION":"PASS_C6_R5_P8_INDEPENDENT_COMPETENCE_ADJUDICATION_PRIMARY_TEST_STILL_SEALED" if passed
else "FAIL_C6_R5_P8_COMPETENCE_PRIMARY_TEST_REMAINS_SEALED"}
(out/'P8_INDEPENDENT_ADJUDICATION.json').write_text(json.dumps(review,sort_keys=True,separators=(',',':'))+'\n')
(out/'FINAL_DECISION.txt').write_text(
 f"P7_EXECUTED=YES\nP7_PASS={'YES' if bool(reported['PASS']) else 'NO'}\n"
 f"P8_EXECUTED=YES\nP8_INDEPENDENT_PASS={'YES' if passed else 'NO'}\n"
 f"FINAL_DECISION={review['DECISION']}\n"
 "PRIMARY_TEST_OPENED=NO\nP9_PRIMARY_TEST_RELEASE_EXECUTED=NO\n"
 "ADAPT=SEALED\nTEST=SEALED\nC1=SEALED\n")
print(json.dumps(review,sort_keys=True,indent=2))
