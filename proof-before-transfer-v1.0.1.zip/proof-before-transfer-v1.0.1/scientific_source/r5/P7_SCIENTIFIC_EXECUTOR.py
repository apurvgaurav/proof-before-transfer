import hashlib,importlib.util,json,pathlib,sys
import joblib,numpy as np,pandas as pd
from catboost import CatBoostClassifier
W=pathlib.Path(sys.argv[1]); out=W/'output'; b=W/'bound'
def load(p,n):
    s=importlib.util.spec_from_file_location(n,p)
    m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
ev=load(b/'eval.py','ev'); nu=load(b/'nuisance.py','nu')
if [int(x) for x in ev.SEEDS] != [228470304,1442176679,591510293,692193369,1246993817]: raise SystemExit("P7_SEEDS")
if hashlib.sha256(ev.BOOT_LITERAL).hexdigest()!='d8ce649224ae98d5d91e73191b18caafee685d7b3c5ff6fdeb9e23a42c48d0c4':
    raise SystemExit("BOOT_LITERAL_SHA")
if ev.bootstrap_seed()!=1447780860: raise SystemExit("BOOT_SEED")
prep=json.loads((out/'05_P7_PREP.json').read_text())
rows=[json.loads(x) for x in (W/'R5_ELIG_256_FEATURE_ROWS_LABEL_BLIND.jsonl').read_text().splitlines() if x.strip()]
if len(rows)!=256: raise SystemExit("FEATURE_COUNT")
bound=[ev.bind_model_row(r['features']) for r in rows]
X=pd.DataFrame(bound,columns=ev.FEATURES)

p5root=pathlib.Path((out/'P5_ROOT.txt').read_text().strip())
seed_probs=[]; model_hashes={}
for seed in ev.SEEDS:
    mp=p5root/'models'/f'seed-{seed}.cbm'
    cp=p5root/'models'/f'seed-{seed}-platt.joblib'
    if not mp.is_file() or not cp.is_file(): raise SystemExit("MODEL_FILE")
    model=CatBoostClassifier(); model.load_model(str(mp))
    margin=np.asarray(model.predict(X,prediction_type='RawFormulaVal',thread_count=1),dtype=np.float64)
    cal=joblib.load(cp)
    prob=ev.calibrated_probability(cal,margin)
    seed_probs.append(prob)
    model_hashes[str(seed)]={
      "model":hashlib.sha256(mp.read_bytes()).hexdigest(),
      "platt":hashlib.sha256(cp.read_bytes()).hexdigest() }
ensemble=np.mean(np.vstack(seed_probs),axis=0,dtype=np.float64)

train_df=pd.DataFrame(prep['train_nuisance'],columns=nu.ALL_COLUMNS)
eval_df=pd.DataFrame(prep['r5_nuisance'],columns=nu.ALL_COLUMNS)
npipe,voc=nu.fit_nuisance(train_df,np.asarray(prep['train_y'],dtype=np.int64))
nprob=nu.nuisance_probability(npipe,voc,eval_df)

y=np.asarray(prep['r5_y'],dtype=np.float64)
fam=np.asarray(prep['r5_family'])
integrity={
 "exact_256_valid":True,
 "zero_cross_partition_semantic_overlap":True,
 "model_calibration_artifacts_frozen_before_elig":True,
}
res=ev.evaluate_competence(ensemble,y,fam,seed_probs,nprob,integrity)

np.savez(out/'P7_SCIENTIFIC_ARRAYS.npz',
 ensemble=ensemble,y=y,family=fam,nuisance=nprob,
 seed0=seed_probs[0],seed1=seed_probs[1],seed2=seed_probs[2],seed3=seed_probs[3],seed4=seed_probs[4])
(out/'P7_RESULT.json').write_text(json.dumps(res,sort_keys=True,separators=(',',':'))+'\n')
(out/'P7_MODEL_HASHES.json').write_text(json.dumps(model_hashes,sort_keys=True,separators=(',',':'))+'\n')
(out/'P7_SEEDS.json').write_text(json.dumps([int(x) for x in ev.SEEDS])+'\n')
print(json.dumps(res,sort_keys=True,indent=2))
