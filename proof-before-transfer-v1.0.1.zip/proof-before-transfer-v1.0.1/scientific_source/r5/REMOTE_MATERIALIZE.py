import csv, hashlib, importlib.util, json, math, pathlib, platform, sys
root=pathlib.Path(sys.argv[1]); out=pathlib.Path(sys.argv[2]); out.mkdir(parents=True,exist_ok=False)
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
EXP={
 'src/C6_R3_REAL_PCAP_24FEATURE_ADAPTER_V1.py':'e41464cb533e164983601077297339e7c7b6afe89662c566b514a3bddfb7ce67',
 'src/C6_RAW24_VALUE_MATERIALIZER_STATIC_QUALIFICATION_v4.py':'be32578cb8392f57ae22b448ae4a28efabbe20f31c5e01dee0c01945a48b13b5',
 'src/C6_24FEATURE_EXTRACTOR_v1.py':'eac451f6665b0734f4c5bed7fed8f0abc5440960b8547a439770a62fe8a978c7',
 'src/02_HISTORICAL_REPRESENTATION_CONTRACT.json':'2b0d1d106cecc5a1acf31e0993827fa0a6f980719da269a490a8ef713eaf3082'}
for rel,h in EXP.items():
    if sha(root/rel)!=h: raise SystemExit('HOLD_SOURCE_HASH_'+rel)
if platform.python_version()!='3.13.15': raise SystemExit('HOLD_PYTHON_VERSION_'+platform.python_version())
if platform.machine() not in ('x86_64','AMD64'): raise SystemExit('HOLD_MACHINE_'+platform.machine())
if sha(pathlib.Path(sys.executable))!='70258db9e01a57d23357f78f68afaa2c1c3edcc2c8e73df52adafa20319b4f46': raise SystemExit('HOLD_FROZEN_PYTHON_BINARY_SHA')
ad=load(root/'src/C6_R3_REAL_PCAP_24FEATURE_ADAPTER_V1.py','c6_adapter')
mat=load(root/'src/C6_RAW24_VALUE_MATERIALIZER_STATIC_QUALIFICATION_v4.py','c6_mat')
contract=json.loads((root/'src/02_HISTORICAL_REPRESENTATION_CONTRACT.json').read_text())
selfdir=out/'selftest'; ad.selftest(selfdir,mat,contract)
(out/'03_ADAPTER_SELFTEST.txt').write_text('PCAPNG_ADAPTER_SELFTEST=PASS\n')
rows=list(csv.DictReader((root/'R5_ROW_PCAP_LABEL_BLIND_INDEX.tsv').open(encoding='utf-8'),delimiter='\t'))
if len(rows)!=256: raise SystemExit('HOLD_INDEX_ROWS')
features_dir=out/'features'; features_dir.mkdir()
consolidated=out/'R5_ELIG_256_FEATURE_ROWS_LABEL_BLIND.jsonl'
lines=[]
def finite(v):
    if isinstance(v,float): return math.isfinite(v)
    if isinstance(v,list): return all(finite(x) for x in v)
    if isinstance(v,dict): return all(finite(x) for x in v.values())
    return True
for i,r in enumerate(rows,1):
    if int(r['execution_ordinal'])!=i: raise SystemExit(f'HOLD_INDEX_ORDER_{i}')
    p=root/'pcaps'/f'row-{i:04d}.pcapng'
    if not p.is_file() or sha(p)!=r['pcap_sha256']: raise SystemExit(f'HOLD_PCAP_BIND_{i}')
    feat=ad.derive_features(p,contract,mat)
    if set(feat)!=set(ad.FEATURES) or len(feat)!=24 or not finite(feat): raise SystemExit(f'HOLD_FEATURE_SCHEMA_{i}')
    canon=json.dumps(feat,sort_keys=True,separators=(',',':'),allow_nan=False)
    (features_dir/f'row-{i:04d}.json').write_text(canon+'\n',encoding='utf-8')
    rec={'execution_ordinal':i,'features':feat,'pcap_sha256':r['pcap_sha256'],'reconciled_row_archive_sha256':r['reconciled_row_archive_sha256']}
    lines.append(json.dumps(rec,sort_keys=True,separators=(',',':'),allow_nan=False))
consolidated.write_text('\n'.join(lines)+'\n',encoding='utf-8')
fh=sha(consolidated)
(out/'04_FEATURE_FREEZE.txt').write_text(
    'R5_24FEATURE_ROWS_VALID=256/256\n'
    'LABELS_ACCESSED_BEFORE_FEATURE_FREEZE=NO\n'
    f'R5_ELIG_256_FEATURE_ROWS_LABEL_BLIND_SHA256={fh}\n',encoding='utf-8')
(out/'05_GATE_SEALS.txt').write_text(
    'P7_EXECUTED=NO\nP8_EXECUTED=NO\nPRIMARY_TEST_OPENED=NO\nADAPT=SEALED\nTEST=SEALED\nC1=SEALED\n',encoding='utf-8')
(out/'00_RUNTIME.txt').write_text(f'PYTHON_VERSION={platform.python_version()}\nPYTHON_EXECUTABLE={sys.executable}\nPYTHON_BINARY_SHA256={sha(pathlib.Path(sys.executable))}\nMACHINE={platform.machine()}\n',encoding='utf-8')
(out/'FINAL_DECISION.txt').write_text('FINAL_DECISION=PASS_C6_R5_LABEL_BLIND_24FEATURE_REMOTE_MATERIALIZATION_V5\n',encoding='utf-8')
print('PCAPNG_ADAPTER_SELFTEST=PASS')
print('R5_24FEATURE_ROWS_VALID=256/256')
print('LABELS_ACCESSED_BEFORE_FEATURE_FREEZE=NO')
print('R5_ELIG_256_FEATURE_ROWS_LABEL_BLIND_SHA256='+fh)
print('P7_EXECUTED=NO')
print('FINAL_DECISION=PASS_C6_R5_LABEL_BLIND_24FEATURE_REMOTE_MATERIALIZATION_V5')
