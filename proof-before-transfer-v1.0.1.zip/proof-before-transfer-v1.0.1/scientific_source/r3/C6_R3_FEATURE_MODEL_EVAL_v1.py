#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,math,warnings,numpy as np

FEATURES=[
"clear_handshake_type","clear_handshake_length","clear_handshake_order_index",
"supported_vector_count","supported_vector_encoded_length","key_share_vector_count","key_share_vector_encoded_length",
"tcp_segment_count_per_tls_record","first_segment_length_per_tls_record","last_segment_length_per_tls_record","packet_count","ack_count",
"retransmission_indicator","out_of_order_indicator","burst_indicator","residual_record_coalescing_count",
"residual_record_sizing_sequence","frontend_message_order_sequence","tcp_option_signature","tcp_window_sequence","ttl_sequence",
"ipid_delta_sequence","residual_packetization_sequence","residual_timing_sequence"]
CATEGORICAL=["clear_handshake_type","clear_handshake_length","clear_handshake_order_index","frontend_message_order_sequence",
"ipid_delta_sequence","residual_packetization_sequence","residual_record_sizing_sequence","residual_timing_sequence",
"tcp_option_signature","tcp_window_sequence","ttl_sequence"]
CONTINUOUS=[x for x in FEATURES if x not in CATEGORICAL]
FORBIDDEN_IDENTITY_KEYS={"label","U_ID","u_id","partition","partition_tag","candidate_id","candidate_ordinal","semantic_seed_sha256",
"treatment","treatment_arm","negotiated_group","environment","environment_id","implementation_id","network_condition","surface_id",
"surface_nonce","target_identifiers","parameter_tokens","parser_branch_sequence","payload_hash_sequence","semantic_record_sha256",
"session_id","global_r2_session_index","global_r3_session_index","logical_slot_id","logical_slot_ordinal","reserve_status",
"reserve_candidate_id","repair_key_sha256","activation_record_sha256","block_id","collection_block_index","execution_position",
"objective","security_action_sequence","plaintext","request_target","request_sequence","expected_response_sequence","dev_role"}

def canonical_cat(v):
    if isinstance(v,str):
        o=json.loads(v);c=json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False)
        if c!=v:raise ValueError("noncanonical categorical")
        return v
    return json.dumps(v,sort_keys=True,separators=(",",":"),ensure_ascii=False)
def validate_feature_row(r):
    if set(r)!=set(FEATURES):raise ValueError("feature schema")
    if len(CATEGORICAL)!=11 or len(CONTINUOUS)!=13:raise RuntimeError("type count")
    for k in CATEGORICAL:canonical_cat(r[k])
    for k in CONTINUOUS:
        if isinstance(r[k],bool):raise ValueError("boolean continuous")
        if not math.isfinite(float(r[k])):raise ValueError("nonfinite")
    return True
def bind_model_row(src):
    bad=FORBIDDEN_IDENTITY_KEYS.intersection(k for k in src if k not in FEATURES)
    if bad:raise ValueError("forbidden identity fields="+",".join(sorted(bad)))
    r={k:src[k] for k in FEATURES};validate_feature_row(r)
    return {k:(canonical_cat(r[k]) if k in CATEGORICAL else float(r[k])) for k in FEATURES}

SEEDS=[228470304,1442176679,591510293,692193369,1246993817]
BASE_PARAMS=dict(loss_function="Logloss",boosting_type="Ordered",depth=4,iterations=800,learning_rate=0.03,l2_leaf_reg=10.0,
random_strength=0.0,bootstrap_type="No",rsm=1.0,max_ctr_complexity=1,one_hot_max_size=2,leaf_estimation_iterations=1,
auto_class_weights=None,scale_pos_weight=1.0,task_type="CPU",thread_count=1,allow_writing_files=False,verbose=False)
def params_for_seed(seed):
    if seed not in SEEDS:raise ValueError("unfrozen seed")
    return dict(BASE_PARAMS,random_seed=seed)
def construct_model(seed):
    from catboost import CatBoostClassifier
    return CatBoostClassifier(**params_for_seed(seed))
def brier(p,y):
    p=np.asarray(p,dtype=np.float64);y=np.asarray(y,dtype=np.float64)
    if p.shape!=y.shape or p.ndim!=1 or not np.all(np.isfinite(p)) or np.any((p<0)|(p>1)) or not np.all(np.isin(y,[0.,1.])):raise ValueError("brier")
    return np.mean(np.square(p-y),dtype=np.float64)
def select_iteration(staged,y,patience=40,max_iter=800):
    best=None;bi=None;non=0;seen=0
    for i,p in enumerate(staged,1):
        if i>max_iter:break
        seen=i;v=float(brier(p,y))
        if best is None or v<best:best,bi,non=v,i,0
        else:
            non+=1
            if non>=patience:break
    if bi is None or seen<bi:raise RuntimeError("stopping")
    return bi,best
def train_and_stop(X,y,Xs,ys,seed):
    y=np.asarray(y,dtype=np.int64);ys=np.asarray(ys,dtype=np.float64)
    if len(y)!=512 or len(ys)!=64:raise ValueError("counts")
    m=construct_model(seed);m.fit(X,y,cat_features=[FEATURES.index(x) for x in CATEGORICAL],verbose=False)
    staged=(np.asarray(x,dtype=np.float64)[:,1] for x in m.staged_predict_proba(Xs,ntree_start=0,ntree_end=0,eval_period=1,thread_count=1))
    bi,bb=select_iteration(staged,ys);m.shrink(ntree_end=bi,ntree_start=0)
    if int(m.tree_count_)!=bi:raise RuntimeError("tree count")
    return m,bi,bb

BOOT_LITERAL=b"C6-R3-COMPETENCE-BOOTSTRAP-V1";BOOT_SEED=1447780860
def bootstrap_seed():
    v=int.from_bytes(hashlib.sha256(BOOT_LITERAL).digest()[:8],"big")%2147483647
    if v!=BOOT_SEED:raise RuntimeError("bootstrap seed")
    return v
def stratified_bootstrap_g(strata):
    if len(strata)!=4:raise ValueError("strata")
    rng=np.random.Generator(np.random.PCG64(bootstrap_seed()));gs=np.empty(10000,dtype=np.float64)
    for r in range(10000):
        ps=[];ys=[]
        for p,y in strata:
            p=np.asarray(p,dtype=np.float64);y=np.asarray(y,dtype=np.float64)
            if len(p)!=64 or len(y)!=64:raise ValueError("64")
            ix=rng.integers(0,64,size=64,endpoint=False,dtype=np.int64);ps.append(p[ix]);ys.append(y[ix])
        gs[r]=np.float64(.25)-brier(np.concatenate(ps),np.concatenate(ys))
    return gs,np.float64(np.quantile(gs,q=.05,method="linear"))

def fit_platt(margin,y):
    from sklearn.linear_model import LogisticRegression
    from sklearn.exceptions import ConvergenceWarning
    X=np.asarray(margin,dtype=np.float64).reshape(-1,1);yy=np.asarray(y,dtype=np.int64)
    if len(yy)!=64:raise ValueError("DEV-CAL")
    e=LogisticRegression(penalty=None,solver="lbfgs",fit_intercept=True,max_iter=1000,tol=1e-8,class_weight=None,random_state=None,n_jobs=1)
    with warnings.catch_warnings(record=True) as ws:
        warnings.simplefilter("always");e.fit(X,yy)
        if any(issubclass(x.category,ConvergenceWarning) for x in ws):raise RuntimeError("cal convergence")
    return e
def calibrated_probability(e,margin):
    p=np.asarray(e.predict_proba(np.asarray(margin,dtype=np.float64).reshape(-1,1))[:,1],dtype=np.float64)
    if not np.all(np.isfinite(p)) or np.any((p<0)|(p>1)):raise RuntimeError("cal p")
    return p

def evaluate_competence(ep,y,family,seed_probs,nuisance_p,integrity):
    ep=np.asarray(ep,dtype=np.float64);yy=np.asarray(y,dtype=np.float64);fam=np.asarray(family);npv=np.asarray(nuisance_p,dtype=np.float64)
    if len(ep)!=256 or len(yy)!=256 or len(fam)!=256 or len(npv)!=256 or len(seed_probs)!=5:raise ValueError("elig count")
    for f in ("F1","F2"):
        for l in (0.,1.):
            if int(((fam==f)&(yy==l)).sum())!=64:raise ValueError("stratum")
    for k in ("exact_256_valid","zero_cross_partition_semantic_overlap","model_calibration_artifacts_frozen_before_elig"):
        if integrity.get(k) is not True:raise RuntimeError("integrity")
    gain=lambda p,z:np.float64(.25)-brier(p,z)
    gp=gain(ep,yy);gf1=gain(ep[fam=="F1"],yy[fam=="F1"]);gf2=gain(ep[fam=="F2"],yy[fam=="F2"])
    sg=[gain(np.asarray(p,dtype=np.float64),yy) for p in seed_probs];gn=gain(npv,yy)
    strata=[(ep[(fam==f)&(yy==l)],yy[(fam==f)&(yy==l)]) for f,l in (("F1",0.),("F1",1.),("F2",0.),("F2",1.))]
    bg,lb=stratified_bootstrap_g(strata);pos=sum(float(x)>0 for x in sg);med=float(np.median(np.asarray(sg)))
    passed=float(gp)>=.01 and float(lb)>0 and float(gf1)>0 and float(gf2)>0 and pos>=4 and med>0 and float(gn)<.01
    return {"G_POOL":float(gp),"G_LB95":float(lb),"G_F1":float(gf1),"G_F2":float(gf2),"SEED_G":[float(x) for x in sg],
            "POSITIVE_SEEDS":pos,"MEDIAN_SEED_G":med,"G_NUISANCE":float(gn),"BOOTSTRAP_COUNT":int(bg.size),"PASS":bool(passed),
            "DECISION":"PASS_R3_COMPETENCE_GATE_PENDING_INDEPENDENT_REVIEW" if passed else "FAIL_R3_COMPETENCE_GATE_PRIMARY_TEST_REMAINS_SEALED"}
