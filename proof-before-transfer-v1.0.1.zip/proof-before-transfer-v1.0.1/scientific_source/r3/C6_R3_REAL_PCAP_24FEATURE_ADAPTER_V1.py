#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, hashlib, importlib.util, json, math, pathlib, struct, sys

FEATURES=[
"clear_handshake_type","clear_handshake_length","clear_handshake_order_index",
"supported_vector_count","supported_vector_encoded_length","key_share_vector_count","key_share_vector_encoded_length",
"tcp_segment_count_per_tls_record","first_segment_length_per_tls_record","last_segment_length_per_tls_record","packet_count","ack_count",
"retransmission_indicator","out_of_order_indicator","burst_indicator","residual_record_coalescing_count",
"residual_record_sizing_sequence","frontend_message_order_sequence","tcp_option_signature","tcp_window_sequence","ttl_sequence",
"ipid_delta_sequence","residual_packetization_sequence","residual_timing_sequence"]

def sha256_file(p):
    h=hashlib.sha256()
    with open(p,"rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""): h.update(b)
    return h.hexdigest()

def canonical(obj):
    return json.dumps(obj,sort_keys=True,separators=(",",":"),ensure_ascii=False)

def load_module(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

def _options(buf,endian):
    i=0; out={}
    while i+4<=len(buf):
        code,ln=struct.unpack(endian+"HH",buf[i:i+4]); i+=4
        if code==0: break
        if i+ln>len(buf): raise ValueError("pcapng option overflow")
        out.setdefault(code,[]).append(buf[i:i+ln]); i+=(ln+3)&~3
    return out

def read_pcapng(path):
    data=pathlib.Path(path).read_bytes()
    if len(data)<28 or data[:4]!=b"\x0a\x0d\x0d\x0a":
        raise ValueError("not pcapng")
    pos=0; endian=None; ifaces=[]; packets=[]
    while pos<len(data):
        if pos+12>len(data): raise ValueError("truncated pcapng block")
        btype_raw=data[pos:pos+4]
        if btype_raw==b"\x0a\x0d\x0d\x0a":
            bom=data[pos+8:pos+12]
            if bom==b"\x4d\x3c\x2b\x1a": endian="<"
            elif bom==b"\x1a\x2b\x3c\x4d": endian=">"
            else: raise ValueError("pcapng bad byte order magic")
            blen=struct.unpack(endian+"I",data[pos+4:pos+8])[0]
            if blen<28 or pos+blen>len(data): raise ValueError("bad SHB length")
            if struct.unpack(endian+"I",data[pos+blen-4:pos+blen])[0]!=blen: raise ValueError("SHB trailer")
            ifaces=[]
            pos+=blen
            continue
        if endian is None: raise ValueError("pcapng section missing")
        btype=struct.unpack(endian+"I",btype_raw)[0]
        blen=struct.unpack(endian+"I",data[pos+4:pos+8])[0]
        if blen<12 or (blen%4) or pos+blen>len(data): raise ValueError("bad block length")
        if struct.unpack(endian+"I",data[pos+blen-4:pos+blen])[0]!=blen: raise ValueError("block trailer")
        body=data[pos+8:pos+blen-4]
        if btype==1:
            if len(body)<8: raise ValueError("short IDB")
            linktype,reserved,snaplen=struct.unpack(endian+"HHI",body[:8])
            opts=_options(body[8:],endian)
            resol=1e-6
            if 9 in opts:
                v=opts[9][0]
                if len(v)!=1: raise ValueError("bad if_tsresol")
                x=v[0]; resol=(2.0**-(x&0x7f)) if (x&0x80) else (10.0**-x)
            ifaces.append({"linktype":linktype,"snaplen":snaplen,"resol":resol})
        elif btype==6:
            if len(body)<20: raise ValueError("short EPB")
            iid,hi,lo,caplen,origlen=struct.unpack(endian+"IIIII",body[:20])
            if iid>=len(ifaces): raise ValueError("EPB interface")
            pad=(caplen+3)&~3
            if 20+pad>len(body): raise ValueError("EPB caplen")
            frame=body[20:20+caplen]
            ts=((hi<<32)|lo)*ifaces[iid]["resol"]
            packets.append((iid,float(ts),frame))
        elif btype==3:
            raise ValueError("simple packet block unsupported: timestamps required")
        pos+=blen
    if len(ifaces)!=1 or ifaces[0]["linktype"]!=1:
        raise ValueError("exactly one Ethernet interface required")
    if not packets: raise ValueError("no EPB packets")
    return packets

def _seq(v):
    if isinstance(v,str): return json.loads(v)
    return v

def derive_historical_contract(rows_path,out_path):
    rows=[]
    with open(rows_path,encoding="utf-8") as f:
        for line in f:
            if line.strip(): rows.append(json.loads(line))
    if len(rows)!=1151: raise ValueError(f"authoritative C0 row count {len(rows)} != 1151")
    feats=[]
    for r in rows:
        x=r.get("features",r)
        if not all(k in x for k in FEATURES): raise ValueError("C0 rows missing frozen feature")
        feats.append({k:_seq(x[k]) for k in FEATURES})
    order_base=None
    for base in (0,1):
        if all(list(x["clear_handshake_order_index"])==list(range(base,base+len(x["clear_handshake_order_index"]))) for x in feats):
            order_base=base; break
    if order_base is None: raise ValueError("cannot recover frozen clear_handshake_order_index convention")
    def all_relation(k,delta):
        return all(len(list(x[k]))==int(x["packet_count"])+delta for x in feats)
    contract={
      "source":"C6_CONTROLLED_C0_REFERENCE_24FEATURE_MATERIALIZATION_V2",
      "clear_handshake_order_base":order_base,
      "tcp_option_signature_outer_len_equals_packet_count":all_relation("tcp_option_signature",0),
      "tcp_window_sequence_len_equals_packet_count":all_relation("tcp_window_sequence",0),
      "ttl_sequence_len_equals_packet_count":all_relation("ttl_sequence",0),
      "ipid_delta_sequence_len_equals_packet_count_minus_1":all_relation("ipid_delta_sequence",-1),
      "residual_timing_sequence_len_equals_packet_count_minus_1":all_relation("residual_timing_sequence",-1),
      "clear_handshake_triplet_lengths_equal":all(
          len(list(x["clear_handshake_type"]))==len(list(x["clear_handshake_length"]))==len(list(x["clear_handshake_order_index"])) for x in feats),
      "rows_checked":len(feats),
    }
    required=[k for k,v in contract.items() if k.endswith(("packet_count","minus_1","lengths_equal")) and v is not True]
    if required: raise ValueError("historical representation relation mismatch: "+",".join(required))
    pathlib.Path(out_path).write_text(canonical(contract)+"\n",encoding="utf-8")
    return contract

def parse_packets(pcap,mat):
    raw=read_pcapng(pcap)
    out=[]
    for cap_idx,(iid,ts,frame) in enumerate(raw):
        p=mat.parse_ipv4_tcp_frame(frame)
        if int(p["sport"])!=10443 and int(p["dport"])!=10443:
            raise ValueError("non-10443 packet survived frozen capture")
        p["timestamp"]=float(ts); p["capture_index"]=cap_idx
        out.append(p)
    if not out: raise ValueError("empty TCP flow")
    endpoints=set()
    for p in out:
        endpoints.add((p["src"],int(p["sport"])))
        endpoints.add((p["dst"],int(p["dport"])))
    if len(endpoints)!=2: raise ValueError("not one bidirectional 4-tuple")
    return out

def clear_handshakes(packets,mat):
    records=mat.locate_tls_records_with_segments(packets)
    hs=[]
    for item in records:
        if int(item["record"]["content_type"])!=22: continue
        for h in mat.parse_tls_handshakes(item["record"]["body"]):
            hs.append(h)
    if not hs: raise ValueError("clear TLS handshakes missing")
    return hs

def derive_features(pcap,contract,mat):
    p=parse_packets(pcap,mat)
    hs=clear_handshakes(p,mat)
    types=[int(h["type"]) for h in hs]
    lens=[int(h["length"]) for h in hs]
    base=int(contract["clear_handshake_order_base"])
    order=list(range(base,base+len(hs)))
    ch=next((h for h in hs if int(h["type"])==1),None)
    if ch is None: raise ValueError("ClientHello missing")
    exts=mat.parse_client_hello_extensions(ch["body"])
    if 10 not in exts or 51 not in exts: raise ValueError("required ClientHello extensions missing")
    sgc,sgl=mat.supported_groups_metrics(exts[10])
    ksc,ksl=mat.key_share_metrics(exts[51])
    retrans,ooo=mat.seq_analysis(p)
    feature={
      "clear_handshake_type":types,
      "clear_handshake_length":lens,
      "clear_handshake_order_index":order,
      "supported_vector_count":sgc,
      "supported_vector_encoded_length":sgl,
      "key_share_vector_count":ksc,
      "key_share_vector_encoded_length":ksl,
      "tcp_segment_count_per_tls_record":mat.derive_tcp_segment_count_per_tls_record(p),
      "first_segment_length_per_tls_record":mat.derive_first_segment_length_per_tls_record(p),
      "last_segment_length_per_tls_record":mat.derive_last_segment_length_per_tls_record(p),
      "packet_count":len(p),
      "ack_count":sum(int(x["ack_flag"]) for x in p),
      "retransmission_indicator":int(retrans),
      "out_of_order_indicator":int(ooo),
      "burst_indicator":int(mat.burst_indicator_structural(p)),
      "residual_record_coalescing_count":mat.derive_residual_record_coalescing_count(p),
      "residual_record_sizing_sequence":mat.derive_residual_record_sizing_sequence(p),
      "frontend_message_order_sequence":mat.derive_frontend_message_order_sequence(p),
      "tcp_option_signature":[mat.parse_tcp_options(x["tcp_options_raw"]) for x in p],
      "tcp_window_sequence":[int(x["window"]) for x in p],
      "ttl_sequence":[int(x["ttl"]) for x in p],
      "ipid_delta_sequence":mat.ipid_deltas([int(x["ipid"]) for x in p]),
      "residual_packetization_sequence":mat.derive_residual_packetization_sequence(p),
      "residual_timing_sequence":mat.timing_deltas([float(x["timestamp"]) for x in p]),
    }
    if set(feature)!=set(FEATURES): raise RuntimeError("feature schema")
    if len(feature["tcp_option_signature"])!=feature["packet_count"]: raise RuntimeError("option shape")
    if len(feature["tcp_window_sequence"])!=feature["packet_count"]: raise RuntimeError("window shape")
    if len(feature["ttl_sequence"])!=feature["packet_count"]: raise RuntimeError("ttl shape")
    if len(feature["ipid_delta_sequence"])!=feature["packet_count"]-1: raise RuntimeError("ipid shape")
    if len(feature["residual_timing_sequence"])!=feature["packet_count"]-1: raise RuntimeError("timing shape")
    return feature

def _write_pcapng(path,frames,timestamps):
    e="<"
    def block(t,body):
        pad=(-len(body))%4; body=body+b"\0"*pad
        ln=12+len(body)
        return struct.pack(e+"II",t,ln)+body+struct.pack(e+"I",ln)
    shb=struct.pack(e+"IHHq",0x1A2B3C4D,1,0,-1)
    # tsresol option code=9 len=1 value=9, then end option.
    idb=struct.pack(e+"HHI",1,0,262144)+struct.pack(e+"HHB",9,1,9)+b"\0"*3+struct.pack(e+"HH",0,0)
    data=block(0x0A0D0D0A,shb)+block(1,idb)
    for frame,ts in zip(frames,timestamps):
        ticks=int(round(ts*1_000_000_000))
        body=struct.pack(e+"IIIII",0,(ticks>>32)&0xffffffff,ticks&0xffffffff,len(frame),len(frame))+frame
        data+=block(6,body)
    pathlib.Path(path).write_bytes(data)

def selftest(work,mat,contract):
    work=pathlib.Path(work); work.mkdir(parents=True,exist_ok=True)
    hs=mat.make_client_hello_handshake(); rec=mat.make_tls_record(hs)
    f1=bytearray(mat.make_ipv4_tcp_frame(1000,rec[:20],10))
    f2=bytearray(mat.make_ipv4_tcp_frame(1020,rec[20:],11))
    # The historical qualification helper intentionally defaults to TCP/443.
    # R3 acquisition is frozen on server port 10443. Retarget ONLY this
    # synthetic self-test fixture; no real R3 PCAP bytes are modified.
    f1[36:38]=struct.pack("!H",10443)
    f2[36:38]=struct.pack("!H",10443)
    f1=bytes(f1); f2=bytes(f2)
    p=work/"adapter-selftest.pcapng"; _write_pcapng(p,[f1,f2],[1.0,1.0005])
    feat=derive_features(p,contract,mat)
    assert feat["clear_handshake_type"]==[1]
    assert feat["clear_handshake_length"]==[len(hs)-4]
    assert feat["clear_handshake_order_index"]==[int(contract["clear_handshake_order_base"])]
    assert feat["packet_count"]==2
    assert feat["ipid_delta_sequence"]==[1]
    assert feat["residual_timing_sequence"]==[0.0005]
    assert feat["tcp_segment_count_per_tls_record"]>=1
    (work/"adapter-selftest-result.json").write_text(canonical({"PASS":True,"features":feat})+"\n")
    return True

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--materializer",required=True)
    sp=ap.add_subparsers(dest="cmd",required=True)
    c=sp.add_parser("contract"); c.add_argument("--c0-rows",required=True); c.add_argument("--out",required=True)
    s=sp.add_parser("selftest"); s.add_argument("--contract",required=True); s.add_argument("--work",required=True)
    m=sp.add_parser("materialize"); m.add_argument("--contract",required=True); m.add_argument("--pcap",required=True); m.add_argument("--out",required=True)
    a=ap.parse_args()
    mat=load_module(a.materializer,"c6_raw24_v4")
    if a.cmd=="contract":
        derive_historical_contract(a.c0_rows,a.out); print("HISTORICAL_REPRESENTATION_CONTRACT=PASS")
    elif a.cmd=="selftest":
        contract=json.load(open(a.contract)); selftest(a.work,mat,contract); print("PCAPNG_ADAPTER_SELFTEST=PASS")
    else:
        contract=json.load(open(a.contract)); feat=derive_features(a.pcap,contract,mat)
        pathlib.Path(a.out).write_text(canonical(feat)+"\n",encoding="utf-8")
if __name__=="__main__": main()
