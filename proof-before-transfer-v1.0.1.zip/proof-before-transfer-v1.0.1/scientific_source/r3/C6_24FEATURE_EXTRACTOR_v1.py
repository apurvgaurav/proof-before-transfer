#!/usr/bin/env python3
from __future__ import annotations
import copy, hashlib, json

FEATURES = [
"clear_handshake_type","clear_handshake_length","clear_handshake_order_index",
"supported_vector_count","supported_vector_encoded_length","key_share_vector_count",
"key_share_vector_encoded_length",
"tcp_segment_count_per_tls_record","first_segment_length_per_tls_record",
"last_segment_length_per_tls_record","packet_count","ack_count",
"retransmission_indicator","out_of_order_indicator","burst_indicator",
"residual_record_coalescing_count","residual_record_sizing_sequence",
"frontend_message_order_sequence","tcp_option_signature","tcp_window_sequence",
"ttl_sequence","ipid_delta_sequence","residual_packetization_sequence",
"residual_timing_sequence"
]

FAMILY = {
"P": FEATURES[0:7],
"MT": FEATURES[7:15],
"MQ": [],
"I": FEATURES[15:24],
"R": []
}

SCALAR_INT = {
"clear_handshake_length","clear_handshake_order_index","supported_vector_count",
"supported_vector_encoded_length","key_share_vector_count","key_share_vector_encoded_length",
"tcp_segment_count_per_tls_record","first_segment_length_per_tls_record",
"last_segment_length_per_tls_record","packet_count","ack_count",
"retransmission_indicator","out_of_order_indicator","burst_indicator",
"residual_record_coalescing_count"
}
SEQUENCE = {
"residual_record_sizing_sequence","frontend_message_order_sequence","tcp_option_signature",
"tcp_window_sequence","ttl_sequence","ipid_delta_sequence",
"residual_packetization_sequence","residual_timing_sequence"
}
CATEGORICAL = {"clear_handshake_type"}

def canonical_json(x):
    return json.dumps(x,sort_keys=True,separators=(",",":"),ensure_ascii=False)

def feature_schema():
    return {
        "feature_count": len(FEATURES),
        "features": list(FEATURES),
        "families": copy.deepcopy(FAMILY),
        "types": {
            f: ("categorical" if f in CATEGORICAL else
                "sequence" if f in SEQUENCE else "integer")
            for f in FEATURES
        }
    }

def validate_normalized_input(rec):
    if not isinstance(rec,dict):
        raise TypeError("normalized input must be dict")
    missing=[f for f in FEATURES if f not in rec]
    extra=[k for k in rec.keys() if k not in FEATURES]
    if missing:
        raise ValueError("missing required features: "+",".join(sorted(missing)))
    if extra:
        raise ValueError("unexpected features: "+",".join(sorted(extra)))
    out={}
    for f in FEATURES:
        v=rec[f]
        if f in CATEGORICAL:
            if not isinstance(v,str) or not v:
                raise ValueError("invalid categorical "+f)
        elif f in SEQUENCE:
            if not isinstance(v,(list,tuple)):
                raise ValueError("invalid sequence "+f)
            v=list(v)
            for x in v:
                if not isinstance(x,(int,float,str,bool)):
                    raise ValueError("invalid sequence element "+f)
        else:
            if not isinstance(v,int) or isinstance(v,bool):
                raise ValueError("invalid integer "+f)
        out[f]=v
    return out

def extract_from_normalized_wire_record(rec):
    return validate_normalized_input(rec)

def jid_canonicalize_identity(meta):
    out=copy.deepcopy(meta)
    for k in ("literal_group_code","literal_group_name","group_code","group_name"):
        if k in out:
            out[k]="__CANONICAL_GROUP__"
    return out

def row_hash(row):
    return hashlib.sha256(canonical_json(row).encode()).hexdigest()
