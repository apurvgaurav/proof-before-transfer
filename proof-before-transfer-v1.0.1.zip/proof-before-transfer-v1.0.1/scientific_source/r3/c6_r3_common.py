from __future__ import annotations
import hashlib, json, math
from pathlib import Path
def sha256_bytes(b:bytes)->str: return hashlib.sha256(b).hexdigest()
def sha256_file(p:Path)->str:
    h=hashlib.sha256()
    with Path(p).open("rb") as f:
        for c in iter(lambda:f.read(1<<20),b""): h.update(c)
    return h.hexdigest()
def canonical_json_bytes(o)->bytes:
    return json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode("utf-8")
def require(c:bool,m:str):
    if not c: raise RuntimeError(m)
