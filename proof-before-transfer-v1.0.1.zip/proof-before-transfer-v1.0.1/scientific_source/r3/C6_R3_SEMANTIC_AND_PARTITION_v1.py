#!/usr/bin/env python3
from __future__ import annotations
import hashlib
from collections import defaultdict
from c6_r3_common import canonical_json_bytes,sha256_bytes

STRATA=(("F1",0),("F1",1),("F2",0),("F2",1))
PARTITIONS=("TRAIN","DEV","ELIG")
PRIMARY={"TRAIN":(1,128),"DEV":(145,176),"ELIG":(181,244)}
RESERVE={"TRAIN":(129,144),"DEV":(177,180),"ELIG":(245,252)}
SLOT_COUNTS={"TRAIN":128,"DEV":32,"ELIG":64}
BLOCK_COUNTS={"TRAIN":32,"DEV":8,"ELIG":16}
PARTTAG={"TRAIN":"R3TR","DEV":"R3DV","ELIG":"R3EL"}
WIRETAG={"TRAIN":"r3tr","DEV":"r3dv","ELIG":"r3el"}

def H(s:str)->str: return hashlib.sha256(s.encode("utf-8")).hexdigest()
def candidate_id(family,label,k):
    if family not in ("F1","F2") or label not in (0,1) or not 1<=int(k)<=252: raise ValueError("candidate")
    return f"C6-R3-CAND-{family}-{'B' if label==0 else 'M'}-{int(k):03d}"
def enumerate_candidate_ids():
    return [candidate_id(f,l,k) for f,l in STRATA for k in range(1,253)]
def semantic_seed(family,label,cid): return H(f"C6|R3|SEMGEN|v1|{family}|{label}|{cid}")
def derive(seed,label): return H(f"C6|R3|MAT|v1|{seed}|{label}")
def candidate(family,label,k):
    cid=candidate_id(family,label,k); s=semantic_seed(family,label,cid); vb=int(derive(s,"variant")[:8],16)
    return {
      "schema_version":"C6-R3-CAND-v1","candidate_id":cid,"family":family,"label":int(label),"candidate_ordinal":int(k),
      "semantic_seed_sha256":s,"surface_nonce":derive(s,"surface")[:16],"variant_sequence":[(vb+j)%4 for j in range(4)],
      "objective":"authorized nested-path retrieval" if family=="F1" and label==0 else
                  "attempted traversal to protected logical object" if family=="F1" else
                  "public-only lookup" if label==0 else "attempted protected-scope query",
      "security_action_sequence":["ALLOW"]*4 if label==0 else ["DENY"]*4,
      "account_token":"r3a_"+derive(s,"account")[:16],"public_token":"r3pub_"+derive(s,"public")[:16],
      "secure_token":"r3sec_"+derive(s,"secure")[:16],"value_token":"r3v_"+derive(s,"value")[:16],
      "tag_token":"r3t_"+derive(s,"tag")[:16],"record_token":"r3r_"+derive(s,"record")[:16],
      "partition_assignment_version":"C6-R3-PARTITION-V1"}
def generate_all_stage_a_candidates():
    return [candidate(f,l,k) for f,l in STRATA for k in range(1,253)]
def stratum(c): return f"{c['family']}|{int(c['label'])}"
def k_r3(c):
    return hashlib.sha256(b"C6-R3-PARTITION-V1"+stratum(c).encode()+canonical_json_bytes(c)).hexdigest()
def ranked_by_stratum(cands):
    g=defaultdict(list)
    for c in cands:g[(c["family"],int(c["label"]))].append((k_r3(c),c["candidate_id"],c))
    if set(g)!=set(STRATA): raise ValueError("strata")
    out={}
    for s in STRATA:
        rows=sorted(g[s],key=lambda x:(x[0],x[1]))
        if len(rows)!=252: raise ValueError("252")
        out[s]=rows
    return out
def logical_slot_id(p,f,l,i):
    if p not in PARTITIONS or f not in ("F1","F2") or l not in (0,1) or not 1<=i<=SLOT_COUNTS[p]: raise ValueError("slot")
    return f"C6-R3-SLOT-{p}-{f}-{'B' if l==0 else 'M'}-{i:03d}"
def slot(p,f,l,i):
    return {"logical_slot_id":logical_slot_id(p,f,l,i),"partition":p,"family":f,"label":l,"logical_slot_ordinal":i,
            "size_profile":(i-1)%4,"block_id":f"C6-R3-{p}-BLK-{(i-1)//4+1:03d}",
            "dev_role":("DEV-STOP" if i<=16 else "DEV-CAL") if p=="DEV" else ""}
def all_slots(): return [slot(p,f,l,i) for p in PARTITIONS for f,l in STRATA for i in range(1,SLOT_COUNTS[p]+1)]
def queues(ranked):
    prim,res={},{}
    for s in STRATA:
        for p in PARTITIONS:
            a,b=PRIMARY[p]; prim[(p,s)]=ranked[s][a-1:b]
            a,b=RESERVE[p]; res[(p,s)]=ranked[s][a-1:b]
    return prim,res
def f1_path(c,v):
    a,p,s,val=c["account_token"],c["public_token"],c["secure_token"],c["value_token"]
    B=[f"/home/{a}/docs/{p}",f"/home/{a}/docs/./{p}",f"/home/{a}/docs/sub/../{p}",f"/home/{a}/docs/{val}/../{p}"]
    M=[f"/home/{a}/docs/../protected/{s}",f"/home/{a}/docs/%2e%2e/protected/{s}",f"/home/{a}/docs/.%2e/protected/{s}",f"/home/{a}/docs/%2e./protected/{s}"]
    return (B if c["label"]==0 else M)[v]
def f2_expr(c,v):
    val,tag,rec=c["value_token"],c["tag_token"],c["record_token"]
    B=[f'owner == "{val}" AND class == "public"',f'tag == "{tag}" AND class == "public"',
       f'owner == "{val}" AND tag == "{tag}" AND class == "public"',f'id == "{rec}" AND class == "public"']
    M=[f'owner == "{val}" OR class == "protected"',f'tag == "{tag}" OR class == "protected"',
       f'(owner == "{val}") OR protected == true',f'id == "{rec}" OR class == "protected"']
    return (B if c["label"]==0 else M)[v]
def _pad(pre,suf,n):
    k=n-len(pre)-len(suf)
    if k<0: raise ValueError("size")
    return pre+b"x"*k+suf
def canonical_request(c,sl,j,v,target):
    tag=WIRETAG[sl["partition"]]; nonce=c["surface_nonce"]
    if c["family"]=="F1":
        rt=f"/lab/{tag}/f1/{nonce}{f1_path(c,v)}"
        pre=(f"GET {rt} HTTP/1.1\r\nHost: c6-lab\r\nConnection: keep-alive\r\nContent-Length: 0\r\nX-C6-Pad: ").encode()
        return _pad(pre,b"\r\n\r\n",target),rt,"GET",""
    rt=f"/lab/{tag}/f2/{nonce}/query"; body=f2_expr(c,v).encode()
    pre=(f"POST {rt} HTTP/1.1\r\nHost: c6-lab\r\nConnection: keep-alive\r\nContent-Type: text/x-c6-query\r\nContent-Length: {len(body)}\r\nX-C6-Pad: ").encode()
    return _pad(pre,b"\r\n\r\n"+body,target),rt,"POST",body.decode()
def canonical_response(c,target):
    if c["family"]=="F1" and c["label"]==0:
        base=f"family=F1\nresult=ALLOW\nobject={c['public_token']}\nbody={derive(c['semantic_seed_sha256'],'public-body')}\nstate=NO_MUTATION\npad="
    elif c["family"]=="F1": base="family=F1\nresult=DENY\nobject=NONE\nbody=DENIED\nstate=NO_MUTATION\npad="
    elif c["label"]==0: base=f"family=F2\nresult=ALLOW\nrecord={c['record_token']}\nstate=NO_MUTATION\npad="
    else: base="family=F2\nresult=DENY\nrecord=NONE\nstate=NO_MUTATION\npad="
    b=base.encode(); k=target-len(b)
    if k<0: raise ValueError("size")
    return b+b"x"*k
def semantic_unit(c,sl):
    cls="B" if c["label"]==0 else "M"; uid=f"C6-R3-UNIT-{c['family']}-{cls}-{c['candidate_ordinal']:03d}"
    reqs=[];resps=[];rhs=[];shs=[];ph=[];branches=[];targets=[]
    for j,v in enumerate(c["variant_sequence"],1):
        rb=512+128*sl["size_profile"]+32*(j-1); sb=768+128*sl["size_profile"]+32*(j-1)
        req,rt,m,body=canonical_request(c,sl,j,v,rb); resp=canonical_response(c,sb)
        br=f"BR-R3-{PARTTAG[sl['partition']]}-{c['family']}-V{v}"
        qh=sha256_bytes(req); ah=sha256_bytes(resp)
        reqs.append({"ordinal":j,"variant":v,"parser_branch_id":br,"method":m,"request_target":rt,"dsl_expression":body,
                     "request_target_bytes":rb,"canonical_request_sha256":qh})
        resps.append({"ordinal":j,"response_body_target_bytes":sb,"canonical_response_body_sha256":ah,
                      "response_class":200 if c["label"]==0 else 403,"security_disposition":"ALLOW" if c["label"]==0 else "DENY",
                      "application_state_transition":"NO_MUTATION"})
        rhs.append(qh);shs.append(ah);ph.append(sha256_bytes(req+b"\0"+resp));branches.append(br);targets.append(rt)
    return {"schema_version":"C6-R3-SEM-v1","wire_format_version":"C6-R3-WIRE-v1","candidate_id":c["candidate_id"],
            "candidate_record_sha256":sha256_bytes(canonical_json_bytes(c)),"U_ID":uid,"logical_slot_id":sl["logical_slot_id"],
            "partition":"R3-"+sl["partition"],"family":c["family"],"label":c["label"],"candidate_ordinal":c["candidate_ordinal"],
            "logical_slot_ordinal":sl["logical_slot_ordinal"],"size_profile":sl["size_profile"],"block_id":sl["block_id"],
            "dev_role":sl["dev_role"],"semantic_seed_sha256":c["semantic_seed_sha256"],
            "surface_id":f"ST-R3-{PARTTAG[sl['partition']]}-{c['family']}-{cls}-{c['candidate_ordinal']:03d}-{c['surface_nonce']}",
            "surface_nonce":c["surface_nonce"],"request_sequence":reqs,"expected_response_sequence":resps,
            "security_action_sequence":list(c["security_action_sequence"]),"parser_branch_sequence":branches,
            "parameter_tokens":[c["account_token"],c["public_token"],c["secure_token"],c["value_token"],c["tag_token"],c["record_token"]],
            "target_identifiers":targets,"canonical_request_sha256_sequence":rhs,"canonical_response_body_sha256_sequence":shs,
            "payload_hash_sequence":ph,"expected_state_transition":"NO_MUTATION",
            "expected_security_disposition":"ALLOW" if c["label"]==0 else "DENY"}
if __name__=="__main__": raise SystemExit("HOLD: P1 release required")
