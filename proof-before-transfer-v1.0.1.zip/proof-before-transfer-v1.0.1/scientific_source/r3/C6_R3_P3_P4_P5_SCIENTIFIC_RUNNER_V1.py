#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,hashlib,importlib.util,json,os,pathlib,pickle,platform,shutil,subprocess,sys,tarfile
import numpy as np

FEATURES=[
"clear_handshake_type","clear_handshake_length","clear_handshake_order_index",
"supported_vector_count","supported_vector_encoded_length","key_share_vector_count","key_share_vector_encoded_length",
"tcp_segment_count_per_tls_record","first_segment_length_per_tls_record","last_segment_length_per_tls_record","packet_count","ack_count",
"retransmission_indicator","out_of_order_indicator","burst_indicator","residual_record_coalescing_count",
"residual_record_sizing_sequence","frontend_message_order_sequence","tcp_option_signature","tcp_window_sequence","ttl_sequence",
"ipid_delta_sequence","residual_packetization_sequence","residual_timing_sequence"]

def sha(p):
    h=hashlib.sha256()
    with open(p,"rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""): h.update(b)
    return h.hexdigest()
def canon(o): return json.dumps(o,sort_keys=True,separators=(",",":"),ensure_ascii=False)
def load(path,name):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def writej(p,o): pathlib.Path(p).write_text(canon(o)+"\n",encoding="utf-8")
def find_exact_sha(root,expected):
    hits=[]
    prune={"elig","test","adapt","primary_test","primary-test","c1"}
    for dp,dns,fns in os.walk(root):
        parts={x.lower() for x in pathlib.Path(dp).parts}
        if parts & prune:
            dns[:]=[]; continue
        dns[:]=[d for d in dns if d.lower() not in prune]
        for fn in fns:
            low=fn.lower()
            if not (low.endswith((".jsonl",".json",".tsv",".txt")) or "row" in low or "feature" in low or "material" in low):
                continue
            p=os.path.join(dp,fn)
            try:
                if os.path.getsize(p)>100_000_000: continue
                if sha(p)==expected: hits.append(p)
            except OSError: pass
    return sorted(set(hits))
def package_manifest(root,out):
    root=pathlib.Path(root)
    with open(out,"w",encoding="utf-8") as f:
        for p in sorted(x for x in root.rglob("*") if x.is_file() and x!=pathlib.Path(out)):
            f.write(f"{sha(p)}  {p.relative_to(root)}\n")
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",required=True)
    a=ap.parse_args(); root=pathlib.Path(a.root)
    inp=root/"input"; src=root/"src"; fr=root/"frozen"; out=root/"output"; out.mkdir(exist_ok=True)
    decision=out/"FINAL_DECISION.txt"
    def hold(reason):
        decision.write_text("\n".join([
          "STUDY=C6-IC-SQITS","REALIZATION=C6-R3","GATE=P3_P4_P5_CONSOLIDATED_SCIENTIFIC_EXECUTION_V1",
          "FINAL_DECISION=HOLD_R3_P3_P4_P5_CONSOLIDATED_SCIENTIFIC_EXECUTION_V1",
          f"HOLD_REASON={reason}","R3_ELIG_OPEN_AUTHORIZED=NO","PRIMARY_TEST_OPEN_AUTHORIZED=NO",
          "ADAPT=SEALED","TEST=SEALED","C1=SEALED"])+"\n")
        print("FINAL_DECISION=HOLD_R3_P3_P4_P5_CONSOLIDATED_SCIENTIFIC_EXECUTION_V1")
        print("HOLD_REASON="+reason); raise SystemExit(2)
    try:
        # Runtime must be the exact frozen scientific environment.
        import catboost,sklearn,scipy,pandas
        versions={"python":platform.python_version(),"catboost":catboost.__version__,"sklearn":sklearn.__version__,
                  "numpy":np.__version__,"scipy":scipy.__version__,"pandas":pandas.__version__}
        writej(out/"00_RUNTIME.json",versions)
        required={"python":"3.13.15","catboost":"1.2.10","sklearn":"1.9.0","numpy":"2.5.2","scipy":"1.18.1"}
        if any(versions[k]!=v for k,v in required.items()): hold("FROZEN_RUNTIME_VERSION_MISMATCH")
        if hasattr(sys,"_is_gil_enabled") and not sys._is_gil_enabled(): hold("FREE_THREADED_PYTHON_NOT_ALLOWED")

        # Exact frozen source bindings.
        expected={
          "C6_RAW24_VALUE_MATERIALIZER_STATIC_QUALIFICATION_v4.py":"be32578cb8392f57ae22b448ae4a28efabbe20f31c5e01dee0c01945a48b13b5",
          "C6_24FEATURE_EXTRACTOR_v1.py":"eac451f6665b0734f4c5bed7fed8f0abc5440960b8547a439770a62fe8a978c7",
          "C6_R3_FEATURE_MODEL_EVAL_v1.py":"3101c0dab3fd83161f2ec7481bd4d6ce22cd3598b708bbf0d86d6e8eb159a638",
          "C6_R3_REQUIREMENTS_LOCK.txt":"a114bb6174931627a1169d85982f0c15775e15d4f45002eaa27de6b2d20584a9",
        }
        for n,h in expected.items():
            if sha(fr/n)!=h: hold("FROZEN_SOURCE_SHA_"+n)
        fm=load(fr/"C6_R3_FEATURE_MODEL_EVAL_v1.py","fm")
        adapter=load(src/"C6_R3_REAL_PCAP_24FEATURE_ADAPTER_V1.py","adapter")
        if fm.FEATURES!=FEATURES or len(fm.CATEGORICAL)!=11 or len(fm.CONTINUOUS)!=13: hold("FEATURE_CONTRACT")

        # Recover authoritative historical representation contract before opening R3 PCAP content.
        staged_c0=inp/"C0_AUTHORITY_ROWS_REFERENCE.jsonl"
        if staged_c0.is_file() and sha(staged_c0)=="f6327556ba14090c43f4d4a4cb359718475c9b9e3e5933681e814c57e4f044ee":
            c0hits=[str(staged_c0)]
            c0path=str(staged_c0)
        else:
            c0hits=find_exact_sha("/home/linuxuser","f6327556ba14090c43f4d4a4cb359718475c9b9e3e5933681e814c57e4f044ee")
            if not c0hits: hold("AUTHORITATIVE_C0_MATERIALIZATION_ROWS_NOT_FOUND")
            c0path=c0hits[0]
        shutil.copy2(c0path,out/"01_C0_AUTHORITY_ROWS_REFERENCE.jsonl")
        contract=adapter.derive_historical_contract(c0path,out/"02_HISTORICAL_REPRESENTATION_CONTRACT.json")
        adapter.selftest(out/"adapter-selftest",load(fr/"C6_RAW24_VALUE_MATERIALIZER_STATIC_QUALIFICATION_v4.py","mat"),contract)
        writej(out/"03_PRE_R3_PREFLIGHT.json",{
          "c0_authority_sha256":sha(c0path),"c0_matches":c0hits,
          "representation_contract":contract,"adapter_selftest":"PASS",
          "r3_feature_values_opened_before_this_point":False})

        # Authority and semantic inputs.
        idx=list(csv.DictReader(open(inp/"01_EXPECTED_FROZEN_ROW_INDEX.tsv",encoding="utf-8"),delimiter="\t"))
        inv=list(csv.DictReader(open(inp/"04_REMOTE_R3_PCAP_INVENTORY.tsv",encoding="utf-8"),delimiter="\t"))
        sched=list(csv.DictReader(open(inp/"C6_R3_TRAIN_DEV_SCHEDULE_640.tsv",encoding="utf-8"),delimiter="\t"))
        if len(idx)!=640 or len(sched)!=640: hold("ROW_COUNT_AUTHORITY")
        iby={int(r["row"]):r for r in idx}
        if set(iby)!=set(range(1,641)): hold("FROZEN_INDEX_RANGE")
        invby={int(r["row"]):r for r in inv}
        if set(invby)!=set(range(1,641)): hold("PCAP_INVENTORY_RANGE")
        for r in sched:
            n=int(r["global_r3_session_index"]); z=iby[n]
            if r["U_ID"]!=z["U_ID"] or r["logical_slot_id"]!=z["logical_slot_id"]: hold("SCHEDULE_INDEX_BINDING")
        # Verify staged PCAPs byte-for-byte before parsing.
        pcdir=inp/"pcaps"
        for n in range(1,641):
            p=pcdir/f"row-{n:04d}.pcapng"
            if not p.is_file() or sha(p)!=iby[n]["pcap_sha256"]: hold(f"PCAP_SHA_ROW_{n:04d}")
        print("P3_AUTHORITY_AND_640_PCAP_SHA=PASS")

        # P3: label-blind feature materialization. No semantic row/label is accessed in this loop.
        mat=load(fr/"C6_RAW24_VALUE_MATERIALIZER_STATIC_QUALIFICATION_v4.py","mat_real")
        feature_path=out/"R3_TRAIN_DEV_640_FEATURE_ROWS_LABEL_BLIND.jsonl"
        with open(feature_path,"w",encoding="utf-8") as f:
            for n in range(1,641):
                z=iby[n]; p=pcdir/f"row-{n:04d}.pcapng"
                feat=adapter.derive_features(p,contract,mat)
                fm.validate_feature_row({k:(fm.canonical_cat(v) if k in fm.CATEGORICAL else float(v)) for k,v in feat.items()})
                row={"row":n,"U_ID":z["U_ID"],"logical_slot_id":z["logical_slot_id"],
                     "pcap_sha256":z["pcap_sha256"],"features":feat}
                f.write(canon(row)+"\n")
        feature_sha=sha(feature_path)
        features=[json.loads(x) for x in open(feature_path,encoding="utf-8") if x.strip()]
        if len(features)!=640: hold("P3_FEATURE_CARDINALITY")
        print("P3_LABEL_UNOPENED_MATERIALIZATION=PASS")
        print("P3_FEATURE_ROWS_SHA256="+feature_sha)

        # Only now, after all 640 label-unopened feature rows are immutable, open
        # the already-frozen TRAIN/DEV semantic records to join labels for P4.
        semrows=[json.loads(x) for x in open(inp/"C6_R3_TRAIN_DEV_PRIMARY_640.jsonl",encoding="utf-8") if x.strip()]
        sem={(r["U_ID"],r["logical_slot_id"]):r for r in semrows}
        if len(sem)!=640: hold("SEMANTIC_CARDINALITY")
        writej(out/"P3_LABEL_FIREWALL.json",{
          "feature_rows_sha256":feature_sha,
          "feature_rows_count":640,
          "r3_labels_opened_during_feature_materialization":False,
          "semantic_label_join_opened_only_after_p3_freeze":True,
          "status":"PASS"})
        joined=[]
        for x in features:
            s=sem.get((x["U_ID"],x["logical_slot_id"]))
            if s is None: hold("SEMANTIC_JOIN")
            if s["partition"] not in ("R3-TRAIN","R3-DEV"): hold("PARTITION")
            joined.append({"row":x["row"],"family":s["family"],"label":int(s["label"]),
                           "partition":s["partition"],"dev_role":s.get("dev_role",""),
                           "U_ID":x["U_ID"],"logical_slot_id":x["logical_slot_id"],"features":x["features"]})
        train=[r for r in joined if r["partition"]=="R3-TRAIN"]
        stop=[r for r in joined if r["partition"]=="R3-DEV" and r["dev_role"]=="DEV-STOP"]
        cal=[r for r in joined if r["partition"]=="R3-DEV" and r["dev_role"]=="DEV-CAL"]
        if (len(train),len(stop),len(cal))!=(512,64,64): hold("P4_SPLIT_COUNTS")
        def strata(rows):
            from collections import Counter
            return dict(Counter((r["family"],r["label"]) for r in rows))
        if any(v!=128 for v in strata(train).values()) or set(strata(train))!={("F1",0),("F1",1),("F2",0),("F2",1)}: hold("TRAIN_STRATA")
        if any(v!=16 for v in strata(stop).values()) or any(v!=16 for v in strata(cal).values()): hold("DEV_STRATA")

        import pandas as pd, joblib
        def X(rows):
            bound=[fm.bind_model_row(r["features"]) for r in rows]
            return pd.DataFrame(bound,columns=fm.FEATURES)
        Xtr,Xs,Xc=X(train),X(stop),X(cal)
        ytr=np.asarray([r["label"] for r in train],dtype=np.int64)
        ys=np.asarray([r["label"] for r in stop],dtype=np.int64)
        yc=np.asarray([r["label"] for r in cal],dtype=np.int64)

        modeldir=out/"models"; modeldir.mkdir()
        summaries=[]
        cal_probs=[]
        for seed in fm.SEEDS:
            m,bi,bb=fm.train_and_stop(Xtr,ytr,Xs,ys,seed)
            margin=np.asarray(m.predict(Xc,prediction_type="RawFormulaVal",thread_count=1),dtype=np.float64)
            e=fm.fit_platt(margin,yc)
            p=fm.calibrated_probability(e,margin)
            mp=modeldir/f"seed-{seed}.cbm"; m.save_model(str(mp))
            cp=modeldir/f"seed-{seed}-platt.joblib"; joblib.dump(e,cp,compress=0)
            params={"seed":seed,"selected_tree_count":int(bi),"dev_stop_brier":float(bb),
                    "platt_coef":[float(x) for x in e.coef_.ravel()],
                    "platt_intercept":[float(x) for x in e.intercept_.ravel()],
                    "classes":[int(x) for x in e.classes_.tolist()],
                    "model_sha256":sha(mp),"calibrator_sha256":sha(cp)}
            writej(modeldir/f"seed-{seed}-freeze.json",params)
            summaries.append(params); cal_probs.append(p)
        if len(summaries)!=5: hold("FIVE_SEED_ARTIFACTS")
        ensemble=np.mean(np.vstack(cal_probs),axis=0,dtype=np.float64)
        if ensemble.shape!=(64,) or not np.all(np.isfinite(ensemble)): hold("ENSEMBLE_INTEGRITY")
        writej(out/"04_P4_TRAINING_SUMMARY.json",{
          "seeds":summaries,
          "ensemble_rule":"ARITHMETIC_MEAN_OF_ALL_FIVE_SEPARATELY_PLATT_CALIBRATED_SEED_PROBABILITIES",
          "seed_weighting":"NONE","seed_dropping":"PROHIBITED",
          "dev_cal_predictions_integrity_only_not_competence_claim":True,
          "dev_cal_ensemble_min":float(ensemble.min()),"dev_cal_ensemble_max":float(ensemble.max())})
        print("P4_FIVE_SEED_TRAIN_STOP_CALIBRATE=PASS")

        # P5 immutable artifact freeze.
        writej(out/"05_P5_FREEZE_BINDINGS.json",{
          "study":"C6-IC-SQITS","realization":"C6-R3",
          "p3_feature_rows_sha256":feature_sha,
          "train_count":512,"dev_stop_count":64,"dev_cal_count":64,
          "feature_count":24,"structured_categorical":11,"continuous":13,
          "seeds":list(fm.SEEDS),
          "model_family":"CatBoostClassifier","boosting_type":"Ordered",
          "ensemble_rule":"equal arithmetic mean of five separately Platt-calibrated seed probabilities",
          "r3_elig_opened":False,"primary_test_opened":False,"adapt":"SEALED","test":"SEALED","c1":"SEALED",
          "runtime":versions,"source_hashes":expected,
          "historical_representation_contract_sha256":sha(out/"02_HISTORICAL_REPRESENTATION_CONTRACT.json")})
        package_manifest(out,out/"P5_ARTIFACT_MANIFEST.sha256")
        manifest_sha=sha(out/"P5_ARTIFACT_MANIFEST.sha256")
        decision.write_text("\n".join([
          "STUDY=C6-IC-SQITS","REALIZATION=C6-R3","GATE=P3_P4_P5_CONSOLIDATED_SCIENTIFIC_EXECUTION_V1",
          "P3_FEATURE_MATERIALIZATION=PASS","P3_FEATURE_ROWS=640","P3_FEATURE_ROWS_SHA256="+feature_sha,
          "P4_FIVE_SEED_TRAINING_STOPPING_CALIBRATION=PASS","P5_IMMUTABLE_ARTIFACT_FREEZE=PASS",
          "P5_ARTIFACT_MANIFEST_SHA256="+manifest_sha,
          "R3_ELIG_OPENED=NO","PRIMARY_TEST_OPENED=NO","ADAPT=SEALED","TEST=SEALED","C1=SEALED",
          "FINAL_DECISION=PASS_R3_P3_P4_P5_CONSOLIDATED_SCIENTIFIC_EXECUTION_V1",
          "NEXT=P6_SEPARATE_ONE_TIME_ELIG_RELEASE_AND_ACQUISITION"])+"\n")
        print("P5_IMMUTABLE_ARTIFACT_FREEZE=PASS")
        print("FINAL_DECISION=PASS_R3_P3_P4_P5_CONSOLIDATED_SCIENTIFIC_EXECUTION_V1")
        print("R3_ELIG_OPENED=NO")
        print("PRIMARY_TEST_OPENED=NO")
    except SystemExit:
        raise
    except Exception as e:
        hold(type(e).__name__+":"+str(e).replace("\n"," ")[:500])
if __name__=="__main__": main()
